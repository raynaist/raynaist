import os
import random

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

import mnist_v2_cfg as cfg


def data_sampling():
    files = os.listdir(cfg.IMG_SAVE_PATH)

    train_dataset = set()
    for _ in range(len(files)):
        idx = random.randint(0, len(files) - 1)  # 随机下标
        train_dataset.add(files[idx])  # 添加到不重复的set中

    test_dataset = set(files) - train_dataset  # 总数据集，与已经采样出来的训练集，求差集，作为测试集
    train_dataset = list(train_dataset)

    print("训练数据采样占比", round(len(train_dataset) / 70000 * 100, 2), "%")
    print("测试数据采样占比", round((1 - len(train_dataset) / 70000) * 100, 2), "%")

    # 将列表保存为 txt 文件
    with open(cfg.TRAIN_DATA_SAMPLING_TXT_PATH, 'w') as f:
        for item in train_dataset:
            f.write(os.path.join(cfg.IMG_SAVE_PATH, str(item)) + '\n')
    f.close()

    print("训练数据采样TXT保存成功", len(train_dataset))

    with open(cfg.TEST_DATA_SAMPLING_TXT_PATH, 'w') as f:
        for item in test_dataset:
            f.write(os.path.join(cfg.IMG_SAVE_PATH, str(item)) + '\n')
    f.close()

    print("测试数据采样TXT保存成功", len(test_dataset))


# 图片处理
img_transforms = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.1307], std=[0.3081])  # 单通道图像标准化
])


class MnistDataset(Dataset):

    def __init__(self, data_txt_path):
        super(MnistDataset, self).__init__()

        # 打开并读取文本文件
        with open(data_txt_path, 'r') as f:
            lines = f.readlines()

        # 去除每行末尾的换行符并创建列表
        self.dataset = [line.strip() for line in lines]
        self.data_num = len(self.dataset)

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        img_path = self.dataset[index]
        img_data = img_transforms(Image.open(img_path))

        img_label = img_path.split(".")[2]
        label_one_hot = np.zeros(10)
        label_one_hot[int(img_label)] = 1
        label_one_hot = torch.Tensor(label_one_hot)

        return img_data, label_one_hot


if __name__ == '__main__':
    # data_sampling()

    mnist_dataset = MnistDataset()
    dataloader = DataLoader(dataset=mnist_dataset, batch_size=64, shuffle=False)
    for i, (img_data, img_label) in enumerate(dataloader):
        img = img_data
        label = img_label

        a = 0
