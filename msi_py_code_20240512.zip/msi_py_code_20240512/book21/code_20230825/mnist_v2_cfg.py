import os

# _______________________ 参数定义 _______________________


DATA_PATH = os.path.join(os.getcwd(), "data")

FILE_MARK = ["train", "test"]

IMG_PATH = [os.path.join(DATA_PATH, "MNIST", "raw", "train-images-idx3-ubyte"),
            os.path.join(DATA_PATH, "MNIST", "raw", "t10k-images-idx3-ubyte")]

LABEL_PATH = [os.path.join(DATA_PATH, "MNIST", "raw", "train-labels-idx1-ubyte"),
              os.path.join(DATA_PATH, "MNIST", "raw", "t10k-labels-idx1-ubyte")]

IMG_SAVE_PATH = os.path.join(DATA_PATH, "mnist_img")

TRAIN_DATA_SAMPLING_TXT_PATH = os.path.join(DATA_PATH, "train_data_sampling.txt")
TEST_DATA_SAMPLING_TXT_PATH = os.path.join(DATA_PATH, "test_data_sampling.txt")

WEIGHT_PATH = os.path.join(DATA_PATH, "MNIST_v2_weigth.pt")

if __name__ == '__main__':
    print(IMG_PATH)
