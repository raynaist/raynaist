import os
import mnist_v2_cfg as cfg

import torch
from torch.utils.data import DataLoader

from mnist_v2_dataset import MnistDataset, data_sampling
from mnist_v2_model import MnistNet
from mnist_v1 import Net


class Trainer:

    def __init__(self, epoch, weight_path, batch_size):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net = MnistNet().to(self.device)
        # self.net = Net().to(self.device)
        self.epoch = epoch
        self.weight_path = weight_path
        self.train_data = MnistDataset(cfg.TRAIN_DATA_SAMPLING_TXT_PATH)
        self.batch_size = batch_size
        self.train_loader = DataLoader(dataset=self.train_data, batch_size=self.batch_size, shuffle=True)
        self.optimzer = torch.optim.Adam(self.net.parameters())
        self.loss = torch.nn.CrossEntropyLoss()
        if os.path.exists(self.weight_path):
            self.net.load_state_dict(torch.load(self.weight_path))
            print("成功加载预训练权重")

    def train(self):
        for epoch in range(0, self.epoch):
            self.net.train()
            running_loss = 0.0
            for i, (data, label) in enumerate(self.train_loader):

                img_data = data.to(self.device)
                img_label = label.to(self.device)

                net_out = self.net(img_data)

                loss = self.loss(net_out, img_label)

                self.optimzer.zero_grad()
                loss.backward()
                self.optimzer.step()

                running_loss = running_loss + loss.item()

                if i % 5 == 0 and i != 0:
                    print('[%d, %5d] loss: %.3f' % (epoch + 1, i + 1, running_loss))
                    # print('[%d, %5d] loss: %.3f' % (epoch + 1, i + 1, running_loss / i + 1))
                    running_loss = 0.0

                # if i * self.batch_size % 200 == 0:
                #     torch.save(self.net.state_dict(), self.weight_path)
                #     print("权重保存成功")

            torch.save(self.net.state_dict(), self.weight_path)
            print("权重保存成功")


if __name__ == '__main__':
    # data_sampling()
    trainer = Trainer(epoch=10, weight_path=cfg.WEIGHT_PATH, batch_size=512)
    trainer.train()

 # TODO 2023年8月23日19:20:53
 # 宝石分类中 进度条
 # tensorboard

