import os
import struct

import numpy as np
from PIL import Image
from torchvision import datasets

import mnist_v2_cfg as cfg


# _______________________ 下载MNIST数据集 _______________________

def download_dataset():
    train_datasets = datasets.MNIST(root=cfg.DATA_PATH, train=True)
    test_datasets = datasets.MNIST(root=cfg.DATA_PATH, train=False)

    print(train_datasets)
    print(test_datasets)


# _______________________ 保存图片 _______________________

def save_img():
    for i in range(len(cfg.FILE_MARK)):

        img_file_path, label_file_path, file_mark = cfg.IMG_PATH[i], cfg.LABEL_PATH[i], cfg.FILE_MARK[i]

        # 打开标签二进制文件
        with open(label_file_path, 'rb') as label_file:
            _, _ = struct.unpack(">II", label_file.read(8))
            labels_data = np.fromfile(label_file, dtype=np.uint8)

        # 打开图片二进制文件
        with open(img_file_path, 'rb') as img_file:
            _, num_img, rows, cols = struct.unpack(">IIII", img_file.read(16))
            imgs_data = np.fromfile(img_file, dtype=np.uint8).reshape(num_img, rows, cols)

        # m = 0
        for idx, (labels, imgs) in enumerate(zip(labels_data, imgs_data)):
            img = Image.fromarray(imgs)
            new_img_name = os.path.join(cfg.IMG_SAVE_PATH, f"{i}.{idx}.{labels}.png")
            img.save(new_img_name)

            # m = m + 1
            # if m > 300:
            #     break

        print("图片保存完成", img_file_path, file_mark)


if __name__ == '__main__':
    download_dataset()
    # save_img()
