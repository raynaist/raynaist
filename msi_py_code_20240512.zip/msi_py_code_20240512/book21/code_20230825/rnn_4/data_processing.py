from __future__ import unicode_literals, print_function, division

import glob  # path 读取指定路径下的特有格式的文件
import os
import string
import unicodedata
from io import open

all_letters = string.ascii_letters + " .,;'-"
n_letters = len(all_letters) + 1  # Plus EOS marker


# 统一 成 英文
def unicodeToAscii(s):
    return ''.join(
        c for c in unicodedata.normalize('NFD', s)
        if unicodedata.category(c) != 'Mn'
        and c in all_letters
    )


print(unicodeToAscii("O'Néàl"))


def readLines(filename):
    lines = open(filename, encoding='utf-8').read().strip().split('\n')  # strip 去掉前后空格
    return [unicodeToAscii(line) for line in lines]  # 语法糖


# → index
category_lines = {}
all_categories = []


def findFiles(path): return glob.glob(path)


for filename in findFiles(r'D:\PycharmProjects\book21\rnn_4\names\*.txt'):
    category = os.path.splitext(os.path.basename(filename))[0]
    all_categories.append(category)
    lines = readLines(filename)
    category_lines[category] = lines

n_categories = len(all_categories)
print('# categories:', n_categories, all_categories)
