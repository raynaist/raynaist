import torch
import torch.nn as nn


class MnistNet(nn.Module):
    def __init__(self):
        super(MnistNet, self).__init__()

        self.conv_layer = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=8, kernel_size=3, bias=False),
            nn.PReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(in_channels=8, out_channels=32, kernel_size=3, bias=False),
            nn.PReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        self.linear_layer = nn.Sequential(
            nn.Linear(in_features=32 * 5 * 5, out_features=128),  # torch.Size([5, 32, 4, 4])
            nn.PReLU(),
            nn.Linear(in_features=128, out_features=64),
            nn.PReLU(),
            nn.Linear(in_features=64, out_features=10)
        )

    def forward(self, x):
        out = self.conv_layer(x)
        out = out.reshape(-1, 32 * 5 * 5)
        out = self.linear_layer(out)
        return out
        # return self.conv_layer(x)


if __name__ == '__main__':
    data = torch.randn(5, 1, 28, 28)
    net = MnistNet()
    out = net(data)
    print(out.shape)
