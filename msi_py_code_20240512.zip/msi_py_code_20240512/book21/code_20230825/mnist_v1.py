import os

import matplotlib.pyplot as plt
import numpy as np
import torch.nn as nn
import torch.utils.data
import torchvision.utils
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torchvision import datasets
from torchvision.transforms import transforms


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()

        # 输入图片是1 channel输出是6 channel 利用5x5的核大小
        self.conv1 = nn.Conv2d(1, 6, 5)
        self.conv2 = nn.Conv2d(6, 64, 5)

        # 全连接 从16 * 4 * 4的维度转成120
        self.fc1 = nn.Linear(64 * 4 * 4, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

        self.relu = nn.ReLU()
        self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2)

    def forward(self, x):
        x = self.maxpool(self.relu(self.conv1(x)))
        x = self.maxpool(self.relu(self.conv2(x)))  # (2,2)也可以直接写成数字2

        x = x.view(-1, 1024)

        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))

        x = self.fc3(x)

        return x

    # def num_flat_features(self, x):
    #     size = x.size()[1:]  # 第一个维度batch不考虑
    #     num_features = 1
    #     for s in size:
    #         num_features *= s
    #     return num_features


def imshow(train_loader):
    dataiter = iter(train_loader)
    imges, _ = next(dataiter)
    img = torchvision.utils.make_grid(imges)
    img = img / 2 + 0.5
    np_img = img.numpy()
    plt.imshow(np.transpose(np_img, (1, 2, 0)))  # CHW --> HWC
    plt.show()


def data_loader(data_path):
    train_loader = torch.utils.data.DataLoader(
        datasets.MNIST(
            root=data_path,
            train=True,
            download=True,
            transform=transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.1307,), (0.3081,))
            ])
        ),
        shuffle=True,
        batch_size=64
    )

    test_loader = torch.utils.data.DataLoader(
        datasets.MNIST(
            root=data_path,
            train=False,
            transform=transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.1307,), (0.3081,))
            ])
        ),
        batch_size=64,
        shuffle=True
    )
    return train_loader, test_loader


def train(epoch, net, train_loader, model_weight_path):
    optimizer = optim.SGD(net.parameters(), lr=0.01)  # lr代表学习率
    criterion = nn.CrossEntropyLoss()

    net.train()  # 设置为training模式

    writer = SummaryWriter()  # tensorboard --logdir runs  http://localhost:6006/

    for epo in range(epoch):
        ep_loss = []  # tensorboard
        running_loss = 0.0
        for i, data in enumerate(train_loader):
            # 得到输入 和 标签
            inputs, labels = data
            inputs = inputs.to("cuda")
            labels = labels.to("cuda")
            # 梯度清空
            optimizer.zero_grad()
            # 前向传播 计算损失 后向传播 更新参数
            outputs = net(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            ep_loss.append(loss)  # tensorboard
            # 打印日志
            running_loss = running_loss + loss.item()
            if i % 100 == 0:  # 每100个batch打印一次
                print('[%d, %5d] loss: %.3f' % (epo + 1, i + 1, running_loss / 100))
                running_loss = 0.0

        torch.save(net.state_dict(), model_weight_path)

        writer.add_scalars(  # tensorboard
            'loss',
            {'train': ep_loss[-1]},
            global_step=epo)
        writer.close()  # tensorboard


def predict(net, test_loader):
    correct = 0
    total = 0

    class_correct = list(0. for i in range(10))  # 10个0
    class_total = list(0. for i in range(10))  # 10个0
    classes = [i for i in range(10)]  # 0-9

    with torch.no_grad():  # 或者model.eval()
        for data in test_loader:
            images, labels = data

            images = images.to("cuda")
            labels = labels.to("cuda")
            net.to("cuda")
            outputs = net(images)
            _, predicted = torch.max(outputs.data, dim=1)  # dim=0 列最大值  dim=1 行最大值

            c = (predicted == labels).squeeze()
            for i in range(len(labels)):
                lab = labels[i]
                class_correct[lab] = class_correct[lab] + c[i].item()
                class_total[lab] = class_total[lab] + 1

            total = total + labels.size(0)  # 预测的总数
            pre_val = (predicted == labels).sum().item()  # 两个tensor相等的数量有多少  predicted == labels
            correct = correct + pre_val

    for i in range(10):
        print('Accuracy of %5s : %2d %%' % (classes[i], 100 * class_correct[i] / class_total[i]))

    print('Accuracy of the network on the epoch test images: %d %%' % (100 * correct / total))


if __name__ == '__main__':
    data_path = os.path.join(os.getcwd(), "data")
    model_weight_path = os.path.join(os.getcwd(), "data", "MNIST_weight.pt")

    train_loader, test_loader = data_loader(data_path)

    # 显示测试图片
    imshow(train_loader)
    device = torch.device("cuda")

    net = Net()

    net.to(device)

    if os.path.exists(model_weight_path):
        try:
            net.load_state_dict(torch.load(model_weight_path))

            print("加载预训练权重成功")
        except RuntimeError:
            os.remove(model_weight_path)
            print("加载预训练权重失败，删除权重文件")
    else:
        print("无权重文件")

    # 调用训练
    # train(1, net, train_loader, model_weight_path)
    predict(net, test_loader)
