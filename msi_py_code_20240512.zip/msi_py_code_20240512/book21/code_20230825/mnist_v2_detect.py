import torch

import mnist_v2_cfg as cfg
from torch.utils.data import DataLoader
from mnist_v2_dataset import MnistDataset
from mnist_v2_model import MnistNet
from mnist_v1 import Net

if __name__ == '__main__':
    net = MnistNet()
    # net = Net()
    net.to("cuda")
    net.eval()
    dataset = MnistDataset(cfg.TEST_DATA_SAMPLING_TXT_PATH)
    dataloader = DataLoader(dataset=dataset, batch_size=512, shuffle=True)
    sum_score = 0.0
    test_num = 0
    for i, (data, label) in enumerate(dataloader):
        img_data = data.to("cuda")
        img_label = label.to("cuda")
        net_out = net(img_data)
        predicted = torch.argmax(net_out, dim=1)
        label_idx = torch.argmax(img_label, dim=1)
        score = torch.sum(torch.eq(predicted, label_idx).float())

        sum_score = sum_score + score.item()
    avg_score = sum_score / 1024
    print(avg_score)
