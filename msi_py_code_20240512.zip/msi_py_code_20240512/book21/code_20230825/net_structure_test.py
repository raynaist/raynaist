import torch
from torch import nn


class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=16, kernel_size=3)
        self.relu1 = nn.ReLU()
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3)
        self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.linear1 = nn.Linear(in_features=32 * 12 * 12, out_features=64)
        self.linear2 = nn.Linear(in_features=64, out_features=10)

    def forward(self, x):
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.conv2(x)
        x = self.maxpool(x)
        x = x.reshape(-1, 32 * 12 * 12)
        x = self.linear1(x)
        x = self.linear2(x)
        return x


if __name__ == '__main__':
    data = torch.randn(1, 3, 28, 28)
    net = Net()
    out = net(data)
    print(out.shape)

    # 保存网络结构
    torch.jit.save(torch.jit.script(net), "net_structure_test.pt")
