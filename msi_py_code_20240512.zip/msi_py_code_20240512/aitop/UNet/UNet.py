import torch
import torch.nn as nn
import torch.nn.functional as F


# 双卷积
class CNN_Block(nn.Module):
    def __init__(self, c_in, c_out):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Conv2d(in_channels=c_in, out_channels=c_out, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(c_out),
            # 激活函数
            nn.LeakyReLU(),
            nn.Dropout(0.2),
            nn.Conv2d(in_channels=c_out, out_channels=c_out, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(c_out),
            nn.LeakyReLU(),
            nn.Dropout(0.2)
        )

    def forward(self, x):
        return self.layer(x)


# 下采样
class DownSampling(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.layer = nn.Sequential(
            # 池化
            nn.MaxPool2d(2),
            # 双卷积
            CNN_Block(c, c)
        )

    def forward(self, x):
        return self.layer(x)


# 上采样
class UpSampling(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.layer = nn.Sequential(
            # 通道减半
            nn.Conv2d(in_channels=c, out_channels=c // 2, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(c // 2),
            nn.LeakyReLU(),
            nn.Dropout(0.2)
        )

    def forward(self, x, r):
        # 上采样：插值法
        out = F.interpolate(x, scale_factor=2, mode="nearest")
        # 卷积：通道减半
        out = self.layer(out)
        # 信息补全：路由
        # NCHW
        return torch.cat((out, r), dim=1)
        # return out + r


# UNet
class UNet(nn.Module):
    def __init__(self):
        super().__init__()
        # 下采样，编码
        self.conv1 = CNN_Block(3, 64)
        self.down1 = DownSampling(64)
        self.conv2 = CNN_Block(64, 128)
        self.down2 = DownSampling(128)
        self.conv3 = CNN_Block(128, 256)
        self.down3 = DownSampling(256)
        self.conv4 = CNN_Block(256, 512)
        self.down4 = DownSampling(512)
        self.conv5 = CNN_Block(512, 1024)
        # 上采样，解码
        # C // 2        HW * 2
        self.up1 = UpSampling(1024)
        self.conv6 = CNN_Block(1024, 512)
        self.up2 = UpSampling(512)
        self.conv7 = CNN_Block(512, 256)
        self.up3 = UpSampling(256)
        self.conv8 = CNN_Block(256, 128)
        self.up4 = UpSampling(128)
        self.conv9 = CNN_Block(128, 64)
        # 输出层
        self.out = nn.Conv2d(in_channels=64, out_channels=3, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        o1 = self.conv1(x)
        o2 = self.conv2(self.down1(o1))
        o3 = self.conv3(self.down2(o2))
        o4 = self.conv4(self.down3(o3))
        o5 = self.conv5(self.down4(o4))
        # 信息补全
        o6 = self.conv6(self.up1(o5, o4))
        o7 = self.conv7(self.up2(o6, o3))
        o8 = self.conv8(self.up3(o7, o2))
        o9 = self.conv9(self.up4(o8, o1))
        return self.out(o9)

# if __name__ == '__main__':
#     # HW
#     data = torch.randn(1, 3, 256, 256)
#     net = UNet()
#     data = net(data)
#     print(data.shape)
