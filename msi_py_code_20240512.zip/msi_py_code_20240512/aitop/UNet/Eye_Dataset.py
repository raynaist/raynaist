import torch
from torch.utils.data import Dataset
import os
from torchvision import transforms
from PIL import Image
from torchvision.utils import save_image


class Eye_Dataset(Dataset):
    def __init__(self):
        super().__init__()
        self.data_path = r"eye/training/images"
        self.label_path = r"eye/training/1st_manual"

    def __len__(self):
        return len(os.listdir(self.data_path))

    def __getitem__(self, index):
        # 尺寸resize，等比例，背景图
        # 数据、标签都做等比例压缩
        # 粘贴在背景图上
        bg1 = transforms.ToPILImage()(torch.zeros(3, 512, 512))
        bg2 = transforms.ToPILImage()(torch.zeros(3, 512, 512))
        # 数据名集合
        datas = os.listdir(self.data_path)
        # 标签名集合
        labels = os.listdir(self.label_path)
        # 构建数据完整路径
        data_path = os.path.join(self.data_path, datas[index])
        # 标签的完整路径
        label_path = os.path.join(self.label_path, labels[index])
        img1 = Image.open(data_path)
        img2 = Image.open(label_path)
        # 等比例压缩，长宽比
        img_size = torch.Tensor(img1.size)
        # 压缩比例，求最大边长
        scale = 512 / img1.size[img_size.argmax()]
        # 压缩之后的尺寸
        size = (img_size * scale).long()
        # 压缩
        img1 = img1.resize(size)
        img2 = img2.resize(size)
        # 粘贴
        bg1.paste(img1)
        bg2.paste(img2)

        transform = transforms.Compose([
            transforms.ToTensor()
        ])

        # Tensor()
        return transform(bg1), transform(bg2), datas[index]


# if __name__ == '__main__':
#     ds = Eye_Dataset()
#     i = 0
#     for (a, b) in ds:
#         save_image(a, f"img/{i}.jpg", nrow=1)
#         i += 1
#         save_image(b, f"img/{i}.jpg", nrow=1)
#         i += 1
