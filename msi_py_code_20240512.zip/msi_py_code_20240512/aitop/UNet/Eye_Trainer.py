import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from torchvision import datasets
from torchvision.transforms import transforms
import os
from torchvision.utils import save_image
from UNet import UNet
from Eye_Dataset import Eye_Dataset

if __name__ == '__main__':
    net = UNet().to("cuda")
    dataloader = DataLoader(dataset=Eye_Dataset(), batch_size=2, shuffle=True)
    # 加载预训练模型
    if os.path.exists("eye.pt"):
        net.load_state_dict(torch.load("eye.pt"))
        print("加载预训练模型成功")
    loss = nn.MSELoss()
    opt = torch.optim.Adam(net.parameters())
    k = 1

    writer = SummaryWriter()  # tensorboard --logdir runs  http://localhost:6006/

    for epoch in range(1, 10000):
        ep_loss = []  # tensorboard
        for i, (img, label, data_path) in enumerate(dataloader):
            img, label = img.cuda(), label.cuda()
            out = net(img)
            l = loss(out, label)
            opt.zero_grad()
            l.backward()
            opt.step()
            ep_loss.append(l)  # tensorboard
            if i % 10 == 0:
                print(f"损失{l}")
                # out shape==NCHW
                save_image(out[0].detach(), f"eye_image/{epoch}{data_path}.jpg", nrow=1)

        writer.add_scalars(  # tensorboard
            'loss',
            {'train': ep_loss[-1]},
            global_step=epoch)
        writer.close()  # tensorboard

        torch.save(net.state_dict(), "eye.pt")
