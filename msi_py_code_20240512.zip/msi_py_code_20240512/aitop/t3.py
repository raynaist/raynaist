import torch
from torchvision import models

ep_loss = [{'a'},{'b'},{'c'},{'d'},{'e'},{'f'}]

l1 = ep_loss[-1]
l2 = ep_loss[-2]
print(l1)
print(l2)