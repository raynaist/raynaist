from PIL import Image
import numpy as np
import cv2

img1 = np.array(Image.open(r"D:\PycharmProjects\aitop\data\ILSVRC2012_test_00000105.jpg").convert("RGB"))
img2 = np.array(Image.open(r"D:\PycharmProjects\aitop\data\ILSVRC2012_test_00000105.png").convert("RGB"))

h, w, c = img1.shape

for i in range(h):
    for j in range(w):
        for k in range(c):
            # if img2[i][j][k] == 0:
            if img2[i][j][k] < 120:
                img1[i][j][k] = 0
            # else:
            #     img1[i][j][k] = img1[i][j][k] * 1

img = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)
cv2.imwrite("mask.jpg", img)
