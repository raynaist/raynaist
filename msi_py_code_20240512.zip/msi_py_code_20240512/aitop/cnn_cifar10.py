# 卷积神经网络实现CAFAR10训练
import torch
import torch.nn as nn
from torch import optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import os

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class Net_V1(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv_layer = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=12, kernel_size=3, stride=1), nn.MaxPool2d(2),
            nn.BatchNorm2d(12),

            nn.ReLU(),
            nn.Conv2d(in_channels=12, out_channels=24, kernel_size=3, stride=1),

            nn.MaxPool2d(2), nn.ReLU(),
            nn.Conv2d(in_channels=24, out_channels=48, kernel_size=3, stride=1), nn.ReLU(),
            nn.Conv2d(in_channels=48, out_channels=96, kernel_size=3, stride=1)  # , nn.ReLU(),
            # nn.Conv2d(in_channels=96, out_channels=192, kernel_size=3, stride=1)
        )

        self.out_layer = nn.Sequential(
            # self.conv_layer层的输出：torch.Size([1, 192, 22, 22])  torch.Size([1, 400, 12, 12])  400 * 12 * 12
            nn.Linear(in_features=96 * 2 * 2, out_features=10)
        )

    def forward(self, x):
        out = self.conv_layer(x)
        out = out.reshape(-1, 96 * 2 * 2)  # NCHW --> NV
        return self.out_layer(out)

        # return self.conv_layer(x)


class Trainer:
    def __init__(self):
        super().__init__()
        # 数据集CIFAR10
        self.train_dataset = datasets.CIFAR10(root="data", train=True, transform=transforms.ToTensor(), download=True)
        self.test_dataset = datasets.CIFAR10(root="data", train=False, transform=transforms.ToTensor(), download=True)
        self.train_dataloader = DataLoader(self.train_dataset, batch_size=2048, shuffle=True)
        self.test_dataloader = DataLoader(self.test_dataset, batch_size=100, shuffle=True)
        # 网络 --> cuda
        self.net = Net_V1().to(DEVICE)
        # 预训练权重（迁移学习）
        if os.path.exists("data/parameters/cnn_cifar10.pt"):
            self.net.load_state_dict(torch.load(r"data/parameters/cnn_cifar10.pt"))
            print("加载预训练权重成功")
        self.loss = nn.CrossEntropyLoss()  # 损失函数   CrossEntropyLoss() 会自动加上Softmax()
        self.opt = optim.Adam(self.net.parameters())  # 优化器

    def train_test(self):
        for epoch in range(1, 10000):
            sum_loss = 0

            for i, (img, tag) in enumerate(self.train_dataloader):
                self.net.train()
                # 数据和标签放入cuda
                img, tag = img.to(DEVICE), tag.to(DEVICE)

                out = self.net(img)
                train_loss = self.loss(out, tag)
                self.opt.zero_grad()  # 优化器梯度清空
                train_loss.backward()  # 损失反向传播
                self.opt.step()  # 执行单个优化步骤（参数更新）
                sum_loss += train_loss.item()

            avg_loss = round(sum_loss / len(self.train_dataloader), 6)
            print(f"第{epoch}轮次的损失{avg_loss}")

            # 测试
            for i, (img, tag) in enumerate(self.test_dataloader):
                self.net.eval()
                img, tag = img.to(DEVICE), tag.to(DEVICE)
                out = self.net(img)
                test_loss = self.loss(out, tag)
                pre = torch.argmax(out, dim=1)
                score = torch.mean(torch.eq(pre, tag).float())
            print(f"第{epoch}轮次测试得分{round(score.item() * 100, 6)}  测试损失{test_loss}")
            torch.save(self.net.state_dict(), "data/parameters/cnn_cifar10.pt")


if __name__ == '__main__':
    print(DEVICE)
    trainer = Trainer()
    trainer.train_test()

    # data = torch.randn(1, 3, 32, 32)
    # nv1 = Net_V1()
    # y = nv1(data)
    # print(y.shape)
