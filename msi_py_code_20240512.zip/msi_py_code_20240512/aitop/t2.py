import torch.nn as nn
from torchvision import datasets, transforms

cifar10_train = datasets.CIFAR10(root="data", train=True, transform=transforms.ToTensor(), download=True)
cifar10_test = datasets.CIFAR10(root="data", train=False, transform=transforms.ToTensor(), download=True)

print(cifar10_train.data[0].shape)
print(cifar10_train.targets[0])
print(cifar10_train.classes)
img = transforms.ToPILImage()(cifar10_train.data[2])
img = transforms.ToPILImage()(cifar10_train.data[2])




img.show()

print(cifar10_train)

print(cifar10_train)
img = transforms.ToPILImage()(cifar10_train.data[2])
img = transforms.ToPILImage()(cifar10_train.data[2])
img = transforms.ToPILImage()(cifar10_train.data[2])
img.show()
img = transforms.ToPILImage()(cifar10_train.data[2])

