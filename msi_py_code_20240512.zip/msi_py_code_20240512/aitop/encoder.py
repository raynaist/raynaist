import os
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import transforms
from torchvision.utils import save_image


class Encoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_features=28 * 28, out_features=512), nn.BatchNorm1d(512), nn.ReLU(),
            nn.Linear(in_features=512, out_features=256), nn.BatchNorm1d(256), nn.ReLU(),
            nn.Linear(in_features=256, out_features=128), nn.BatchNorm1d(128), nn.ReLU(),
            nn.Linear(in_features=128, out_features=64), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Linear(in_features=64, out_features=10), nn.BatchNorm1d(10), nn.ReLU()
        )

    def forward(self, x):
        return self.layer(x)


class Decoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_features=10, out_features=64), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Linear(in_features=64, out_features=128), nn.BatchNorm1d(128), nn.ReLU(),
            nn.Linear(in_features=128, out_features=256), nn.BatchNorm1d(256), nn.ReLU(),
            nn.Linear(in_features=256, out_features=512), nn.BatchNorm1d(512), nn.ReLU(),
            nn.Linear(in_features=512, out_features=784), nn.BatchNorm1d(784), nn.ReLU()
        )

    def forward(self, x):
        return self.layer(x)


class NetV1(nn.Module):
    def __init__(self):
        super(NetV1, self).__init__()
        self.encoder = Encoder()
        self.decoder = Decoder()

    def forward(self, x):
        x = x.reshape(-1, 784)
        out = self.encoder(x)
        out = self.decoder(out)
        return out


if __name__ == '__main__':
    net = NetV1().to("cuda")
    dataset = datasets.MNIST(root=r"data/MNIST", train=True, transform=transforms.ToTensor(), download=True)
    dataloader = DataLoader(dataset=dataset, batch_size=100, shuffle=True)
    # 加载预训练模型
    if os.path.exists("en_de.pt"):
        net.load_state_dict(torch.load("en_de.pt"))
        print("加载预训练模型成功")
    loss = nn.MSELoss()
    opt = torch.optim.Adam(net.parameters())
    k = 1
    for epoch in range(1, 10000):
        for i, (img, _) in enumerate(dataloader):
            img = img.cuda()
            out = net(img)
            # out：NV --> NCHW
            # img：NCHW
            out = out.reshape(-1, 1, 28, 28)
            l = loss(out, img)
            opt.zero_grad()
            l.backward()
            opt.step()
            if i % 10 == 0:
                print(f"损失{l}", l)
                # out gpu --> cpu
                out = out.detach()

                save_image(out, f"img.jpg", nrow=10)

                k += 1
            torch.save(net.state_dict(), f"en_de.pt")
