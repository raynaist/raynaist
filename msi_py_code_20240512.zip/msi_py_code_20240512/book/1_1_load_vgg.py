import numpy as np
import json
from PIL import Image
import matplotlib.pyplot as plt

import torch
import torchvision
from torchvision import models, transforms

print("PyTorch Version: ", torch.__version__)
print("Torchvision Version: ", torchvision.__version__)

use_pretrained = True
net = models.vgg16(pretrained=use_pretrained)
net.eval()

print(net)


# 对输入图片进行预处理的类
class BaseTransform():
    """
    调整图片的尺寸，并对颜色进行规范化。

    Attributes
    ----------
    resize : int
       指定调整尺寸后图片的大小
    mean : (R, G, B)
       各个颜色通道的平均值
    std : (R, G, B)
       各个颜色通道的标准偏差
    """

    def __init__(self, resize, mean, std):
        self.base_transform = transforms.Compose([
            transforms.Resize(resize),  # 将较短边的长度作为resize的大小
            transforms.CenterCrop(resize),  # 从图片中央截取resize × resize大小的区域
            transforms.ToTensor(),  # 转换为Torch张量
            transforms.Normalize(mean, std)  # 颜色信息的正规化
        ])

    def __call__(self, img):
        return self.base_transform(img)


# 1. 读取图片
image_file_path = r"D:\PycharmProjects\book\data\goldenretriever-3724972_640.jpg"
img = Image.open(image_file_path)  # [高度][宽度][颜色RGB]

# 2.  显示处理前的图片示
plt.imshow(img)
plt.show()

# 3. 同时显示预处理前后的图片
resize = 224
mean = (0.485, 0.456, 0.406)
std = (0.229, 0.224, 0.225)
transform = BaseTransform(resize, mean, std)
img_transformed = transform(img)  # torch.Size([3, 224, 224])

# 将 ( 颜色、高度、宽度 ) 转换为 ( 高度、宽度、颜色 )，并将取值范围限制在0~1
img_transformed = img_transformed.numpy().transpose((1, 2, 0))
img_transformed = np.clip(img_transformed, 0, 1)
print(img_transformed)
plt.imshow(img_transformed)
plt.show()


# 根据输出结果对标签进行预测的后处理类
class ILSVRCPredictor():
    """
    根据ILSVRC数据，从模型的输出结果计算出分类标签

    Attributes
    ----------
    class_index : dictionary
           将类的index与标签名关联起来的字典型变量
    """

    def __init__(self, class_index):
        self.class_index = class_index

    def predict_max(self, out):
        """
        获得概率最大的ILSVRC分类标签名

        Parameters
        ----------
        out : torch.Size([1, 1000])
            从Net中输出结果

        Returns
        -------
        predicted_label_name : str
            预测概率最高的分类标签的名称
        """
        maxid = np.argmax(out.detach().numpy())
        predicted_label_name = self.class_index[str(maxid)][1]

        return predicted_label_name


# 载入ILSVRC的标签信息，并生成字典型变量
ILSVRC_class_index = json.load(open(r"D:\PycharmProjects\book\data\imagenet_class_index.json", 'r'))

# 生成ILSVRCPredictor的实例
predictor = ILSVRCPredictor(ILSVRC_class_index)

# 读取输入的图像
image_file_path = r"D:\PycharmProjects\book\data\goldenretriever-3724972_640.jpg"
img = Image.open(image_file_path)  # [ 高度 ][ 宽度 ][ 颜色RGB]

# 完成预处理后，添加批次尺寸的维度
transform = BaseTransform(resize, mean, std)  # 创建预处理类
img_transformed = transform(img)  # torch.Size([3, 224, 224])
inputs = img_transformed.unsqueeze(0)  # torch.Size([1, 3, 224, 224])

# 输入数据到模型中，并将模型的输出转换为标签
out = net(inputs)  # torch.Size([1, 1000])
result = predictor.predict_max(out)

# 输出预测结果
print("输入图像的预测结果：", result)
