# 导入软件包
import glob
import os.path as osp
import random
import numpy as np
import json
from PIL import Image
from tqdm import tqdm
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as data
import torchvision
from torchvision import models, transforms

# 设置随机数的种子
torch.manual_seed(1234)
np.random.seed(1234)
random.seed(1234)


# 输入图像的预处理类
# 训练时和推测时采用不同的处理方式


class ImageTransform:
    """
    图像的预处理类。训练时和推测时采用不同的处理方式
    对图像的大小进行调整，并将颜色信息标准化
    训练时采用 RandomResizedCrop 和 RandomHorizontalFlip 进行数据增强处理


    Attributes
    ----------
    resize : int
       指定调整后图像的尺寸
    mean : (R, G, B)
        各个颜色通道的平均值
    std : (R, G, B)
        各个颜色通道的标准偏差
    """

    def __init__(self, resize, mean, std):
        self.data_transform = {
            'train': transforms.Compose([
                transforms.RandomResizedCrop(resize, scale=(0.5, 1.0)),  # 数据增强处理
                transforms.RandomHorizontalFlip(),  # 数据增强处理
                transforms.ToTensor(),  # 转换为张量
                transforms.Normalize(mean, std)  # 归一化
            ]),
            'val': transforms.Compose([
                transforms.Resize(resize),  # 调整大小
                transforms.CenterCrop(resize),  # 从图像中央截取resize×resize大小的区域
                transforms.ToTensor(),  # 转换为张量
                transforms.Normalize(mean, std)  # 归一化
            ])
        }

    def __call__(self, img, phase='train'):
        """
        Parameters
        ----------
        phase : 'train' or 'val'
            指定预处理所使用的模式
        """
        return self.data_transform[phase](img)


# 对训练时的图像预处理操作进行确认
# 对训练时的图像预处理操作进行确认

# 1. 读入图像文件
image_file_path = r"D:\PycharmProjects\book\data\goldenretriever-3724972_640.jpg"
img = Image.open(image_file_path)  # [高度][宽度][颜色RGB]

# 2. 显示原图像
plt.imshow(img)
plt.show()

# 3. 显示预处理前和处理完毕后的图像
size = 224
mean = (0.485, 0.456, 0.406)
std = (0.229, 0.224, 0.225)

transform = ImageTransform(size, mean, std)
img_transformed = transform(img, phase="train")  # torch.Size([3, 224, 224])

# 将（颜色、高度、宽度）转换为（高度、宽度、颜色），取值限制在 0~1，并显示
img_transformed = img_transformed.numpy().transpose((1, 2, 0))
img_transformed = np.clip(img_transformed, 0, 1)
plt.imshow(img_transformed)
plt.show()


#  创建用于保存蚂蚁和蜜蜂的图片的文件路径的列表变量


def make_datapath_list(phase="train"):
    """
    创建用于保存数据路径的列表

    Parameters
    ----------
    phase : 'train' or 'val'
        指定是训练数据还是验证数据

    Returns
    -------
    path_list : list
       保存了数据路径的列表
    """

    rootpath = r"D:\PycharmProjects\book\data"
    target_path = osp.join(rootpath + phase + '/**/*.jpg')
    print(target_path)

    path_list = []  # 保存到这里

    #  使用 glob 取得包括示例目录的文件路径
    for path in glob.glob(target_path):
        path_list.append(path)

    return path_list


#  执行
train_list = make_datapath_list(phase="train")
val_list = make_datapath_list(phase="val")


# 创建由蚂蚁和蜜蜂的图片组成的Dataset


class HymenopteraDataset(data.Dataset):
    """
    蚂蚁和蜜蜂图片的Dataset类，继承自PyTorch的Dataset类

    Attributes
    ----------
    file_list : 列表
        列表中保存了图片路径
    transform : object
        预处理类的实例
    phase : 'train' or 'test'
        指定是学习还是验证
    """

    def __init__(self, file_list, transform=None, phase='train'):
        self.file_list = file_list  # 文件路径列表
        self.transform = transform  # 预处理类的实例
        self.phase = phase  # 指定是train 还是val

    def __len__(self):
        """返回图片张数"""
        return len(self.file_list)

    def __getitem__(self, index):
        """
        获取预处理完毕的图片的张量数据和标签
        """

        # 载入第index张图片
        img_path = self.file_list[index]
        img = Image.open(img_path)  # [高度][宽度][颜色RGB]

        # 对图片进行预处理
        img_transformed = self.transform(img, self.phase)  # torch.Size([3, 224, 224])

        # 从文件名中抽取图片的标签
        if self.phase == "train":
            label = img_path[30:34]
        elif self.phase == "val":
            label = img_path[28:32]

        # 将标签转换为数字
        if label == "ants":
            label = 0
        elif label == "bees":
            label = 1

        return img_transformed, label


# 执行
train_dataset = HymenopteraDataset(
    file_list=train_list, transform=ImageTransform(size, mean, std), phase='train')

val_dataset = HymenopteraDataset(
    file_list=val_list, transform=ImageTransform(size, mean, std), phase='val')

# 确认执行结果
index = 0
print(train_dataset.__getitem__(index)[0].size())
print(train_dataset.__getitem__(index)[1])
