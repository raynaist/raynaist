#!/usr/bin/env python
# coding: utf-8

# 2.6 损失函数的实现
# 
# 本节将对 SSD 模型的损失函数进行定义。
# 

# # 2.6 学习目标
# 
# 1.	理解运用了 jaccard 系数的 match 函数的行为。
# 2.	理解什么是难分样本挖掘。
# 3.	理解两种损失函数（SmoothL1Loss 函数、交叉熵误差函数）的行为
# 

# # 事前准备
# 
# 
# 使用“utils”的match.py

# In[1]:


# 导入软件包
import torch.nn as nn
import torch.nn.functional as F
import torch

# 从描述walda“utils”中的函数match的match.py import
from utils.match import match


# # SSD 损失函数MultiBoxLoss类的实现

# In[3]:


class MultiBoxLoss(nn.Module):
    """SSD的损失函数的类"""

    def __init__(self, jaccard_thresh=0.5, neg_pos=3, device='cpu'):
        super(MultiBoxLoss, self).__init__()
        self.jaccard_thresh = jaccard_thresh  # 0.5，match函数的jaccard系数的阈值
        self.negpos_ratio = neg_pos  # 3:1，难分样本挖掘的正负比例
        self.device = device  # 指定使用CPU或GPU进行计算

    def forward(self, predictions, targets):
        """
       损失函数的计算

        Parameters
        ----------
        predictions : SSD网络训练时的输出 ( 元组 )
            (loc=torch.Size([num_batch, 8732, 4]), conf=torch.Size([num_batch, 8732, 21]), dbox_list=torch.Size [8732,4])。

        targets : [num_batch, num_objs, 5]
            5表示正确答案的标注信息[xmin, ymin, xmax, ymax, label_ind]

        Returns
        -------
        loss_l :  张量
           loc的损失值
        loss_c : 张量
           conf的损失值

        """

        # 由于SSD模型的输出数据类型是元组，因此要将其分解
        loc_data, conf_data, dbox_list = predictions

        # 把握元素的数量
        num_batch = loc_data.size(0)  # 小批量的尺寸
        num_dbox = loc_data.size(1)  # DBox的数量 = 8732
        num_classes = conf_data.size(2)  # 分类数量 = 21

        # 创建变量，用于保存损失计算中使用的对象
        # conf_t_label ：将最接近正确答案的BBox的标签保存到各个DBox中
        # loc_t:将最接近正确答案的BBox的位置信息保存到各个DBox中
        conf_t_label = torch.LongTensor(num_batch, num_dbox).to(self.device)
        loc_t = torch.Tensor(num_batch, num_dbox, 4).to(self.device)

        # 在loc_t和conf_t_label中保存
        # 经过match处理的DBox和正确答案标注targets的结果
        for idx in range(num_batch):  # 以小批量为单位进行循环

            # 获取当前的小批量的正确答案标注的BBox和标签
            truths = targets[idx][:, :-1].to(self.device)  # BBox
            # 标签[物体1的标签, 物体2的标签, …]
            labels = targets[idx][:, -1].to(self.device)

            # 用新的变量初始化DBox变量n            dbox = dbox_list.to(self.device)

            # 执行match函数，更新loc_t和conf_t_label的内容
            # （详细）
            # loc_t:保存各个DBox中最接近正确答案的BBox的位置信息
            # conf_t_label ：保存各个DBox中最接近正确答案的BBox的标签
            # 但是，如果与最接近的BBox之间的jaccard重叠小于0.5
            # 将正确答案BBox的标签conf_t_label设置为背景分类0
            variance = [0.1, 0.2]
            # 这个variance是从DBox转换到BBox的修正计算公式中的系数
            match(self.jaccard_thresh, truths, dbox,
                  variance, labels, loc_t, conf_t_label, idx)

        # ----------
        # 位置的损失 ：计算loss_l
        # 使用Smooth L1函数计算损失。这里只计算那些发现了物体的DBox的位移
        # ----------
        # 生成用于获取检测到物体的BBox的掩码
        pos_mask = conf_t_label > 0  # torch.Size([num_batch, 8732])

        # 将pos_mask的尺寸转换为loc_data
        pos_idx = pos_mask.unsqueeze(pos_mask.dim()).expand_as(loc_data)

        # 获取Positive DBox的loc_data和监督数据loc_t
        loc_p = loc_data[pos_idx].view(-1, 4)
        loc_t = loc_t[pos_idx].view(-1, 4)

        # 对发现了物体的Positive DBox的位移信息loc_t进行损失（误差）计算
        loss_l = F.smooth_l1_loss(loc_p, loc_t, reduction='sum')

        # ----------
        # 分类预测的损失 ：计算loss_c
        # #使用交叉熵误差函数进行损失计算。但是，由于绝大多数 DBox 的正确答案为背景分类，
        # 因此要进行难分样本挖掘处理，将发现物体的 DBox 和背景分类 DBox 的比例调整为1:3
        # 然后，从预测为背景分类的DBox中，将损失值小的那些从分类预测的损失中去除
        # ----------
        batch_conf = conf_data.view(-1, num_classes)

        ##计算分类预测的损失函数(设置reduction='none'，不进行求和计算，不改变维度)
        loss_c = F.cross_entropy(
            batch_conf, conf_t_label.view(-1), reduction='none')

        # -----------------
        # 现在开始创建Negative DBox中，用于计算难分样本挖掘处理抽出数据的掩码
        # -----------------

        # 将发现了物体的Positive DBox的损失设置为0n        #注意 ：物体标签大于1，标签0是背景
        num_pos = pos_mask.long().sum(1, keepdim=True)  # 以小批量为单位，对物体分类进行预测的数量
        loss_c = loss_c.view(num_batch, -1)  # torch.Size([num_batch, 8732])
        loss_c[pos_mask] = 0  # 将发现了物体的 DBox 的损失设置为 0

        # 开始进行难分样本挖掘处理
        # 计算用于对每个DBox的损失值大小loss_c进行排序的idx_rank
        _, loss_idx = loss_c.sort(1, descending=True)
        _, idx_rank = loss_idx.sort(1)

        # （注释）
        # 这里的实现代码比较特殊，不容易直观理解
        # 上面两行代码是对每个DBox的损失值的大小的顺序，
        # 用变量idx_rank来表示，这样就可以进行快速的访问。
        #
        # 将DBox的损失值按降序排列，并将DBox的降序的index保存到loss_idx中。
        # 计算用于对损失值大小loss_c进行排序用的idx_rank。
        # 在这里，
        # 如果要将按降序排列的索引数组loss_idx转换为从0到8732升序排列，
        # 应该使用loss_idx的第几个索引值呢？idx_rank表示的就是该索引值。
        # 例如，
        # 要求idx_rank的第0个元素= idx_rank[0]，loss_idx的值为0的元素，
        # 即loss_idx[?}=0，?表示要求取的是第几位。在这里就是? = idx_rank[0]。
        # 这里，loss_idx[?]=0中的0表示原有的loss_c的第0个元素。
        # 也就是说，?表示的是，求取原有的loss_c第0位的元素，在按降序排列的
        # loss_idx中是第几位这一结果
        # ? = idx_rank[0] 表示loss_c的第0位元素，如果按降序排列是第几位

        # 决定背景的DBox数量num_neg。通过难分样本挖掘处理后，
        # 设为发现了物体的DBox的数量num_pos的三倍（self.negpos_ratio倍）。
        # 但是，如果超过了DBox的数量，就将DBox数量作为上限值。
        num_neg = torch.clamp(num_pos * self.negpos_ratio, max=num_dbox)

        # idx_rank表示每个DBox的损失值按从大到小的顺序是第几位
        # 生成用于读取比背景的DBox数num_neg排位更低的DBox
        # torch.Size([num_batch, 8732])
        neg_mask = idx_rank < (num_neg).expand_as(idx_rank)

        # -----------------
        # （结束）现在开始创建从Negative DBox中，用于求取难分样本挖掘抽出的数据的掩码
        # -----------------

        # 转换掩码的类型，合并到conf_data中
        # pos_idx_mask是获取Positive DBox的conf的掩码
        # neg_idx_mask是获取使用难分样本挖掘提取的Negative DBox的conf的掩码
        # pos_mask：torch.Size([num_batch, 8732])→pos_idx_mask：torch.Size([num_batch, 8732, 21])
        pos_idx_mask = pos_mask.unsqueeze(2).expand_as(conf_data)
        neg_idx_mask = neg_mask.unsqueeze(2).expand_as(conf_data)

        # 从conf_data中将pos和neg取出，保存到conf_hnm中。类型是torch.Size([num_pos+num_neg, 21])
        conf_hnm = conf_data[(pos_idx_mask + neg_idx_mask).gt(0)].view(-1, num_classes)
        # （注释）gt是greater than (>)的简写。这样就能取出mask为1的index。
        # 虽然pos_idx_mask+neg_idx_mask是加法运算，但是只是对给index的mask进行集中
        # 也就是说，无论是pos还是neg，只要是掩码为1就进行加法运算，合并成一个列表，这使用gt取得

        # 同样地，从作为监督数据的conf_t_label中取出pos和neg，放到conf_t_label_hnm中
        # 类型是torch.Size([pos+neg])
        conf_t_label_hnm = conf_t_label[(pos_mask + neg_mask).gt(0)]

        # confidence的损失函数的计算（求元素的总和=sum）
        loss_c = F.cross_entropy(conf_hnm, conf_t_label_hnm, reduction='sum')

        # 使用发现了物体的BBox的数量N（整个小批量的合计）对损失进行除法运算
        N = num_pos.sum()
        loss_l /= N
        loss_c /= N

        return loss_l, loss_c

# 以上
