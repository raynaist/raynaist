#!/usr/bin/env python
# coding: utf-8

# # 2.2 Dataset的实现、 2.3 DataLoader的实现
# 
# 在本文件中，制作用于SSD等物体检测算法的Dataset和Dataloader。
# 
# VOC2012データセットを対象とします。
# 

# # 2.2 学习目标
# 
# 1.	学习创建用于物体检测的 Dataset 类。
# 2.	理解在 SSD 学习中使用的数据增强具体做了哪些处理。
# 
# 

# # 2.3 学习目标
# 
# 1.	掌握创建用于物体检测的 DataLoader 类的方法
# 
# 

# # 事前准备
# 
# 
# OpenCV的安装
# 
# - pip install opencv-python
# 
# 根据本书的指示下载VOC2010数据集
# 
# - http://host.robots.ox.ac.uk/pascal/VOC/voc2012/
# 
# 


# 包装的import
import os
import os.path as osp
import numpy as np
import cv2
import random

# 从文件和文本中读取、加工、保存XML的库
import xml.etree.ElementTree as ET

import torch
import torch.utils.data as data

import matplotlib.pyplot as plt

# 设定随机数的种子，
torch.manual_seed(1234)
np.random.seed(1234)
random.seed(1234)


# # 制作到图像数据、标注数据的文件路径列表


##创建学习、验证用图像数据和标注数据的文件路径列表


def make_datapath_list(rootpath):
    """
    创建用于保存指向数据路径的列表

    Parameters
    ----------
    rootpath : str
        数据文件夹的路径

    Returns
    -------
    ret : train_img_list, train_anno_list, val_img_list, val_anno_list
        用于保存数据路径的列表
    """

    # 创建图像文件与标注文件的路径模板
    imgpath_template = osp.join(rootpath, 'JPEGImages', '%s.jpg')
    annopath_template = osp.join(rootpath, 'Annotations', '%s.xml')

    # 分别取得训练和验证用的文件的ID
    train_id_names = osp.join(rootpath, 'ImageSets', 'Main', 'train.txt')
    val_id_names = osp.join(rootpath, 'ImageSets', 'Main', 'val.txt')

    # 创建训练数据的图像文件与标注文件的路径列表
    train_img_list = list()
    train_anno_list = list()

    for line in open(train_id_names):
        file_id = line.strip()  # 删除空格和换行符
        img_path = (imgpath_template % file_id)  # 图像的路径
        anno_path = (annopath_template % file_id)  # 标注的路径
        train_img_list.append(img_path)  # 添加到列表中
        train_anno_list.append(anno_path)  # 添加到列表中

    # #创建验证数据的图像文件和标注文件的路径列表
    val_img_list = list()
    val_anno_list = list()

    for line in open(val_id_names):
        file_id = line.strip()  # #删除空格和换行符
        img_path = (imgpath_template % file_id)  # 图像的路径
        anno_path = (annopath_template % file_id)  # 标注的路径
        val_img_list.append(img_path)  # 添加到列表中
        val_anno_list.append(anno_path)  # 添加到列表中

    return train_img_list, train_anno_list, val_img_list, val_anno_list


# 创建文件路径列表
rootpath = os.path.join(os.getcwd(), "data", "VOCdevkit", "VOC2012")
train_img_list, train_anno_list, val_img_list, val_anno_list = make_datapath_list(rootpath)

# 确认执行结果
print(train_img_list[0])


# # 将xml格式的标注转换为列表形式的类


# 将“XML格式的标注”转换为列表格式的类


class Anno_xml2list(object):
    """
    使用图像的尺寸信息，对每一张图像包含的xml格式的标注数据进行正规化处理，并保存到列表中

    Attributes
    ----------
    classes : 列表
        用于保存VOC分类名的列表
    """

    def __init__(self, classes):

        self.classes = classes

    def __call__(self, xml_path, width, height):
        """
       使用图像的尺寸信息，对每一张图像包含的xml格式的标注数据进行正规化处理，并保存到列表中

        Parameters
        ----------
        xml_path : str
            xml文件路径。
        width : int
            对象图像宽度。
        height : int
            对象图像高度。

        Returns
        -------
        ret : [[xmin, ymin, xmax, ymax, label_ind], ... ]
            用于保存物体的标注数据的列表。列表元素数量与图像内包含的物体数量相同。
        """

        # 将图像内包含的所有物体的标注保存到该列表中
        ret = []

        # 读取xml文件
        xml = ET.parse(xml_path).getroot()

        # 将图像内包含的物体数量作为循环次数进行迭代
        for obj in xml.iter('object'):

            # 将标注中注明检测难度为difficult的对象剔除
            difficult = int(obj.find('difficult').text)
            if difficult == 1:
                continue

            # 用于保存每个物体的标注信息的列表
            bndbox = []

            name = obj.find('name').text.lower().strip()  # 物体名
            bbox = obj.find('bndbox')  # 包围盒的信息

            # 获取标注的xmin、ymin、xmax、ymax，并正规化为0~1的值
            pts = ['xmin', 'ymin', 'xmax', 'ymax']

            for pt in (pts):
                # VOC的原点从(1,1)开始，因此将其减1变为（0, 0）
                cur_pixel = int(bbox.find(pt).text) - 1

                # 使用宽度和高度进行正规化
                if pt == 'xmin' or pt == 'xmax':  # x方向时用宽度除
                    cur_pixel /= width
                else:  # y方向时用高度除
                    cur_pixel /= height

                bndbox.append(cur_pixel)

            # 取得标注的分类名的index并添加
            label_idx = self.classes.index(name)
            bndbox.append(label_idx)

            # 将res加[xmin, ymin, xmax, ymax, label_ind]
            ret += [bndbox]

        return np.array(ret)  # [[xmin, ymin, xmax, ymax, label_ind], ... ]


# 确认执行结果　
voc_classes = ['aeroplane', 'bicycle', 'bird', 'boat',
               'bottle', 'bus', 'car', 'cat', 'chair',
               'cow', 'diningtable', 'dog', 'horse',
               'motorbike', 'person', 'pottedplant',
               'sheep', 'sofa', 'train', 'tvmonitor']

transform_anno = Anno_xml2list(voc_classes)

# 使用OpenCV读取图像
ind = 1
image_file_path = train_img_list[ind]
img = cv2.imread(image_file_path)  # [ 高度 ][ 宽度 ][ 颜色BGR]
height, width, channels = img.shape  # 获取图像的尺寸

# 以列表形式表示标注
transform_anno(val_anno_list[ind], width, height)

# # 创建类DataTransform，预处理图像和标注


# 从utils文件夹中导入data_augumentation.py
# 对输入图像进行预处理的类
from utils.data_augumentation import Compose, ConvertFromInts, ToAbsoluteCoords, PhotometricDistort, Expand, RandomSampleCrop, RandomMirror, \
    ToPercentCoords, Resize, SubtractMeans


class DataTransform():
    """
    图像和标注的预处理类。训练和推测时分别采用不同的处理
    将图像尺寸调整为 300 像素 ×300 像素
    学习时进行数据增强处理


    Attributes
    ----------
    input_size : int
        需要调整的图像大小。
    color_mean : (B, G, R)
        各个颜色通道的平均值。
    """

    def __init__(self, input_size, color_mean):
        self.data_transform = {
            'train': Compose([
                ConvertFromInts(),  # 将int转换为float32
                ToAbsoluteCoords(),  # 返回正规化后的标注数据
                PhotometricDistort(),  # 随机地调整图像的色调
                Expand(color_mean),  # 扩展图像的画布尺寸
                RandomSampleCrop(),  # 随机地截取图像内的部分内容
                RandomMirror(),  # 对图像进行翻转
                ToPercentCoords(),  # 将标注数据进行规范化，使其值在0~1的范围内
                Resize(input_size),  # 将图像尺寸调整为input_size×input_size
                SubtractMeans(color_mean)  # 将图像尺寸调整为input_size×input_size
            ]),
            'val': Compose([
                ConvertFromInts(),  # 将int转换为float
                Resize(input_size),  # 将图像尺寸调整为input_size×input_size
                SubtractMeans(color_mean)  # 减去BGR的颜色平均值
            ])
        }

    def __call__(self, img, phase, boxes, labels):
        """
        Parameters
        ----------
        phase : 'train' or 'val'
            指定预处理的模式
        """
        return self.data_transform[phase](img, boxes, labels)


# 确认执行结果

# 1.读取图像
image_file_path = train_img_list[0]
img = cv2.imread(image_file_path)  # [ 高度 ][ 宽度 ][ 颜色BGR]
height, width, channels = img.shape  # 获取图像的尺寸

# 2.将标注放入列表中
transform_anno = Anno_xml2list(voc_classes)
anno_list = transform_anno(train_anno_list[0], width, height)

# 3.显示原图像
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.show()

# 4.创建预处理类
color_mean = (104, 117, 123)  # (BGR)颜色的平均值
input_size = 300  # 将图像的input尺寸转换为300像素×300像素
transform = DataTransform(input_size, color_mean)

# 5.显示train图像
phase = "train"
img_transformed, boxes, labels = transform(
    img, phase, anno_list[:, :4], anno_list[:, 4])
plt.imshow(cv2.cvtColor(img_transformed, cv2.COLOR_BGR2RGB))
plt.show()

# 6.显示val图像
phase = "val"
img_transformed, boxes, labels = transform(
    img, phase, anno_list[:, :4], anno_list[:, 4])
plt.imshow(cv2.cvtColor(img_transformed, cv2.COLOR_BGR2RGB))
plt.show()


# #创建Dataset


# 创建VOC2012的Dataset


class VOCDataset(data.Dataset):
    """
    创建VOC2012的Dataset的类，继承自PyTorch的Dataset类

    Attributes
    ----------
    img_list : 列表
        保存图像路径的列表
    anno_list : リスト
       保存标注数据路径的列表
    phase : 'train' or 'test'
        用于指定是进行学习还是训练
    transform : object
       预处理类的实例
    transform_anno : object
        将xml格式的标注转换为列表的实例
    """

    def __init__(self, img_list, anno_list, phase, transform, transform_anno):
        self.img_list = img_list
        self.anno_list = anno_list
        self.phase = phase  # 指定train或val
        self.transform = transform  # 图像的变形处理
        self.transform_anno = transform_anno  # 将xml的标注转换为列表

    def __len__(self):
        '''返回图像的张数'''
        return len(self.img_list)

    def __getitem__(self, index):
        '''
        获取经过预处理的图像的张量形式的数据和标注
        '''
        im, gt, h, w = self.pull_item(index)
        return im, gt

    def pull_item(self, index):
        '''经过预处理的图像的张量格式的数据、标注数据，获取图像的高度和宽度'''

        # 1.读入图像
        image_file_path = self.img_list[index]
        img = cv2.imread(image_file_path)  # [ 高度 ][ 宽度 ][ 颜色BGR]
        height, width, channels = img.shape  # 获取图像的尺寸

        # 2.将xml格式的标注信息转换为列表
        anno_file_path = self.anno_list[index]
        anno_list = self.transform_anno(anno_file_path, width, height)

        # 3.实施预处理
        img, boxes, labels = self.transform(
            img, self.phase, anno_list[:, :4], anno_list[:, 4])

        # 由于颜色通道的顺序是BGR，因此需要转换为RGB的顺序
        # 然后将（高度、宽度、颜色通道）的顺序变为（颜色通道、高度、宽度）的顺序
        img = torch.from_numpy(img[:, :, (2, 1, 0)]).permute(2, 0, 1)

        # 创建由BBox和标签组合而成的np.array，变量名gt是ground truth（答案）的简称
        gt = np.hstack((boxes, np.expand_dims(labels, axis=1)))

        return img, gt, height, width


# 确认执行结果
color_mean = (104, 117, 123)  # (BGR)颜色的平均值
input_size = 300  # 将图像的input尺寸转换为300像素×300像素

train_dataset = VOCDataset(train_img_list, train_anno_list, phase="train", transform=DataTransform(
    input_size, color_mean), transform_anno=Anno_xml2list(voc_classes))

val_dataset = VOCDataset(val_img_list, val_anno_list, phase="val", transform=DataTransform(
    input_size, color_mean), transform_anno=Anno_xml2list(voc_classes))

# 取出第一个数据
print(val_dataset.__getitem__(1))


# # DataLoader的实现


def od_collate_fn(batch):
    """
   从Dataset中取出的标注数据的尺寸，对于每幅图像都是不同的
    如果图像内的物体数量为两个，尺寸就是(2, 5) ；如果是三个，就会变成（3, 5）
    要创建能够处理这种不同的DataLoader，就需要对collate_fn进行定制
    collate_fn是PyTorch中从列表创建小批次数据的函数
    在保存了小批次个列表变量batch的前面加入指定小批次的编号，将两者作为一个列表对象输出
    """

    targets = []
    imgs = []
    for sample in batch:
        imgs.append(sample[0])  # sample[0]是图像img
        targets.append(torch.FloatTensor(sample[1]))  # sample[1]是标注gt

    # imgs是小批次大小的列表
    # 列表的元素是torch.Size([3, 300, 300])
    # 将该列表变成torch.Size([batch_num, 3, 300, 300])的张量
    imgs = torch.stack(imgs, dim=0)

    # targets是标注数据的正解gt的列表
    # 列表的大小与小批次的大小一样
    # 列表targets的元素为[n, 5]
    # n对于每幅图像都是不同的，表示每幅图像中包含的物体数量
    # 5是[xmin, ymin, xmax, ymax, class_index]

    return imgs, targets


# 创建DataLoader

batch_size = 4

train_dataloader = data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=od_collate_fn)

val_dataloader = data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False, collate_fn=od_collate_fn)

# 集中到字典型变量中
dataloaders_dict = {"train": train_dataloader, "val": val_dataloader}

# 确认执行结果
batch_iterator = iter(dataloaders_dict["val"])  # 转换为迭代器
images, targets = next(batch_iterator)  # 取出列表中的第一个数据
print(images.size())  # torch.Size([4, 3, 300, 300])
print(len(targets))
print(targets[1].size())  # 小批次的尺寸的列表，每个元素为[n, 5]，其中n是物体数量

print(train_dataset.__len__())
print(val_dataset.__len__())
