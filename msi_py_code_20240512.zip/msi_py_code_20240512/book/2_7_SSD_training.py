#!/usr/bin/env python
# coding: utf-8

# 2.7 学习和检测的实现
# 
# 本节将使用在前几节中编写的 SSD 模型的代码进行学习和验证。
# - p2.xlarge大约需要6个小时。
# 

# # 学习目标
# 
# 1.	实现 SSD 的学习和检测。

# # 事前准备
# 
# 使用AWS EC2的GPU实例。
# 1-文件夹“utils”的ssd模型.py

# In[19]:


# 包装的import
import os

import cv2
import numpy as np
import os.path as osp
import time
import random
import pandas as pd

import torch
import torch.utils.data as data
import torch.nn as nn
import torch.nn.init as init
import torch.optim as optim

# In[20]:


# 设定随机数的种子，
torch.manual_seed(1234)
np.random.seed(1234)
random.seed(1234)

# In[21]:


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("使用设备：", device)

# # Dataset和DataLoader在创建

# In[22]:


from utils.ssd_model import make_datapath_list, VOCDataset, DataTransform, Anno_xml2list, od_collate_fn

# 取得文件路径的列表
rootpath = os.path.join(os.getcwd(), "data", "VOCdevkit", "VOC2012")
train_img_list, train_anno_list, val_img_list, val_anno_list = make_datapath_list(rootpath)

# 创建Dataset
voc_classes = ['aeroplane', 'bicycle', 'bird', 'boat',
               'bottle', 'bus', 'car', 'cat', 'chair',
               'cow', 'diningtable', 'dog', 'horse',
               'motorbike', 'person', 'pottedplant',
               'sheep', 'sofa', 'train', 'tvmonitor']
color_mean = (104, 117, 123)  # (BGR)的颜色平均值
input_size = 300  # 将图像的input尺寸设置为300像素×300像素

train_dataset = VOCDataset(train_img_list, train_anno_list, phase="train", transform=DataTransform(
    input_size, color_mean), transform_anno=Anno_xml2list(voc_classes))

val_dataset = VOCDataset(val_img_list, val_anno_list, phase="val", transform=DataTransform(
    input_size, color_mean), transform_anno=Anno_xml2list(voc_classes))

# 创建DataLoader
batch_size = 32

train_dataloader = data.DataLoader(
    train_dataset, batch_size=batch_size, shuffle=True, collate_fn=od_collate_fn)

val_dataloader = data.DataLoader(
    val_dataset, batch_size=batch_size, shuffle=False, collate_fn=od_collate_fn)

# 集中保存到字典型变量中
dataloaders_dict = {"train": train_dataloader, "val": val_dataloader}

# # 创建网络模型

# In[24]:


from utils.ssd_model import SSD

# 设置SSD300
ssd_cfg = {
    'num_classes': 21,  # 包含背景分类的总分类数
    'input_size': 300,  # 图像的输入尺寸
    'bbox_aspect_num': [4, 6, 6, 6, 4, 4],  # 输出的DBox的宽高比的种类
    'feature_maps': [38, 19, 10, 5, 3, 1],  # 各个source的图像的尺寸
    'steps': [8, 16, 32, 64, 100, 300],  # 设置DBox的大小
    'min_sizes': [30, 60, 111, 162, 213, 264],  # 设置DBox的大小
    'max_sizes': [60, 111, 162, 213, 264, 315],  # 设置DBox的大小
    'aspect_ratios': [[2], [2, 3], [2, 3], [2, 3], [2], [2]],
}

# SSD网络模型
net = SSD(phase="train", cfg=ssd_cfg)

# SSD网络模型
# 将权重载入SSD的vgg部分
vgg_weights = torch.load(os.path.join(os.getcwd(), 'data', 'vgg16_reducedfc.pth'))
net.vgg.load_state_dict(vgg_weights)


# SSD的其他网络权重使用He的初始值进行初始化


def weights_init(m):
    if isinstance(m, nn.Conv2d):
        init.kaiming_normal_(m.weight.data)
        if m.bias is not None:  # 存在偏差的情况下
            nn.init.constant_(m.bias, 0.0)


# 用He的初始值进行设置
net.extras.apply(weights_init)
net.loc.apply(weights_init)
net.conf.apply(weights_init)

# 确认是否可以使用GPU
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("所使用设备：", device)

print('网络设置完毕 ：学习完毕的权重已加载完成。')

# # 定义损失函数与设置最优化算法

# In[25]:


from utils.ssd_model import MultiBoxLoss

# 定义损失函数
criterion = MultiBoxLoss(jaccard_thresh=0.5, neg_pos=3, device=device)

# 设置最优化算法
optimizer = optim.SGD(net.parameters(), lr=1e-3,
                      momentum=0.9, weight_decay=5e-4)


# # 执行学习与检测

# In[31]:


# 创建用于训练模型的函数


def train_model(net, dataloaders_dict, criterion, optimizer, num_epochs):
    # 确认是否可以使用GPU
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("所使用的设备：", device)

    # 将网络放入GPU中
    net.to(device)

    # 当网络在一定程度上稳定下来时，开启高速运算
    torch.backends.cudnn.benchmark = True

    # 设置迭代计数器
    iteration = 1
    epoch_train_loss = 0.0  # epoch的损失值总和
    epoch_val_loss = 0.0  # epoch的损失值总和
    logs = []

    # epoch的循环
    for epoch in range(num_epochs + 1):

        # 保存开始时间
        t_epoch_start = time.time()
        t_iter_start = time.time()

        print('-------------')
        print('Epoch {}/{}'.format(epoch + 1, num_epochs))
        print('-------------')

        # 以epoch为单位进行训练和验证循环
        for phase in ['train', 'val']:
            if phase == 'train':
                net.train()  # 将模型设置为训练模式
                print('（train）')
            else:
                if ((epoch + 1) % 10 == 0):
                    net.eval()  # 将模型设置为验证模式
                    print('-------------')
                    print('（val）')
                else:
                    # 每10轮进行一次验证
                    continue

            # 从数据加载器中将小批量一个个取出并进行循环处理
            for images, targets in dataloaders_dict[phase]:

                # 如果GPU能用，则将数据输送到GPU中
                images = images.to(device)
                targets = [ann.to(device) for ann in targets]  # 将列表的各个元素的张量传输到GPU

                # 初始化optimizer
                optimizer.zero_grad()

                # 正向传播计算
                with torch.set_grad_enabled(phase == 'train'):

                    # 正向传播计算
                    outputs = net(images)

                    # 计算损失
                    loss_l, loss_c = criterion(outputs, targets)
                    loss = loss_l + loss_c

                    # 训练时的反向传播
                    if phase == 'train':
                        loss.backward()  # 计算梯度

                        # 如果梯度太大，计算会变得不稳定，因此用clip将梯度固定在2.0以下n
                        nn.utils.clip_grad_value_(net.parameters(), clip_value=2.0)

                        optimizer.step()  # 更新参数

                        if (iteration % 10 == 0):  # 每10次迭代显示一次loss
                            t_iter_finish = time.time()
                            duration = t_iter_finish - t_iter_start
                            print('迭代 {} || Loss: {:.4f} || 10iter: {:.4f} sec.'.format(
                                iteration, loss.item(), duration))
                            t_iter_start = time.time()

                        epoch_train_loss += loss.item()
                        iteration += 1

                    # 验证时
                    else:
                        epoch_val_loss += loss.item()

        # 以epoch的phase为单位的loss和准确率
        t_epoch_finish = time.time()
        print('-------------')
        print('epoch {} || Epoch_TRAIN_Loss:{:.4f} ||Epoch_VAL_Loss:{:.4f}'.format(
            epoch + 1, epoch_train_loss, epoch_val_loss))
        print('timer:  {:.4f} sec.'.format(t_epoch_finish - t_epoch_start))
        t_epoch_start = time.time()

        # 保存日志
        log_epoch = {'epoch': epoch + 1, 'train_loss': epoch_train_loss, 'val_loss': epoch_val_loss}
        logs.append(log_epoch)
        df = pd.DataFrame(logs)
        df.to_csv(os.path.join(os.getcwd(), "data", "log_output.csv"))

        epoch_train_loss = 0.0  # epoch的损失值总和
        epoch_val_loss = 0.0  # epoch的损失值总和

        # 保存网络
        if ((epoch + 1) % 10 == 0):
            torch.save(net.state_dict(), os.path.join(os.getcwd(), "data", 'ssd300_' + str(epoch + 1) + '.pth'))


# In[8]:


# 执行学习和验证
num_epochs = 50
train_model(net, dataloaders_dict, criterion, optimizer, num_epochs=num_epochs)

# 以上
