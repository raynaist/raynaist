#!/usr/bin/env python
# coding: utf-8

# #2.8推理实施的附录。在学习和验证的DataLoader中实施
# 
# 本节将使用在 2.7 节中训练好的 SSD 模型对图像进行物体检测操作。
# 
# 
# 对VOC2012的训练数据集和验证数据集进行已学习SSD的推论，并同时显示推论结果和正确答案的标注数据的文件。
# 
# 想确认学习的SSD模型与正确的标注数据有多接近的情况下，也请使用这个。
# 

# # 事先准备
# 
# -请确认文件夹“utils”中是否有集中了2.3 ~ 2.7实现的内容的ssd_model.py
# -准备学习的权重参数

# In[ ]:
import os

import torch
import cv2  # OpenCV库
import numpy as np

import matplotlib.pyplot as plt


# # 创建用于推理的函数和类

# In[ ]:


def ssd_predict(img_index, img_list, dataset, net=None, dataconfidence_level=0.5):
    """
    ·SSD预测函数。

    Parameters
    ----------
    img_index:  int
        数据集中预测对象图像的索引。
    img_list: list
        图像的文件路径列表
    dataset: PyTorchのDataset
        Dataset图像
    net: PyTorchのNetwork
        固态硬盘网络
    dataconfidence_level: float
        预测发现的确信度的斗值

    Returns
    -------
    rgb_img, true_bbox, true_label_index, predict_bbox, pre_dict_label_index, scores
    """

    # 获取rqb的图像数据
    image_file_path = img_list[img_index]
    img = cv2.imread(image_file_path)  # [高度][宽度][颜色BGR]
    height, width, channels = img.shape  # 获取图像的尺寸
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # 获取正确答案BBox
    im, gt = dataset.__getitem__(img_index)
    true_bbox = gt[:, 0:4] * [width, height, width, height]
    true_label_index = gt[:, 4].astype(int)

    # SSD预测
    net.eval()  # 将网络转换为推理模式
    x = im.unsqueeze(0)  # ミニバッチ化：torch.Size([1, 3, 300, 300])
    detections = net(x)
    # detectionsの形は、torch.Size([1, 21, 200, 5])  ※200是top_k的値

    # confidence_level取出基准以上
    predict_bbox = []
    pre_dict_label_index = []
    scores = []
    detections = detections.cpu().detach().numpy()

    # 提取条件以上的值
    find_index = np.where(detections[:, 0:, :, 0] >= dataconfidence_level)
    detections = detections[find_index]
    for i in range(len(find_index[1])):  # 把提取的物体循环几分钟
        if (find_index[1][i]) > 0:  # 非背景类的东西
            sc = detections[i][0]  # 确信度
            bbox = detections[i][1:] * [width, height, width, height]
            lable_ind = find_index[1][i] - 1  # find_index是迷你批次数量、类别、top的tuple
            # （注释）
            # 背景类是0，减去1く

            # 添加到返回值列表
            predict_bbox.append(bbox)
            pre_dict_label_index.append(lable_ind)
            scores.append(sc)

    return rgb_img, true_bbox, true_label_index, predict_bbox, pre_dict_label_index, scores


# In[ ]:


def vis_bbox(rgb_img, bbox, label_index, scores, label_names):
    """
    用图像显示物体检测的预测结果的函数。

    Parameters
    ----------
    rgb_img:rgb的图像
        对象的图像数据
    bbox: list
        物体的BBox列表
    label_index: list
        对物体标签的索引
    scores: list
        物体的确信度
    label_names: list
        标签名的排列

    Returns
    -------
    没有。显示在rgb_img中加入了物体检测结果的图像。
    """

    # 边框颜色的设定
    num_classes = len(label_names)  # 班级数(背景)
    colors = plt.cm.hsv(np.linspace(0, 1, num_classes)).tolist()

    # 图像的显示
    plt.figure(figsize=(10, 10))
    plt.imshow(rgb_img)
    currentAxis = plt.gca()

    # BBox的循环
    for i, bb in enumerate(bbox):

        # 标签名
        label_name = label_names[label_index[i]]
        color = colors[label_index[i]]  # 给每个面赋予不同颜色的框

        # 枠添加在框上的标签例:person;0.72　
        if scores is not None:
            sc = scores[i]
            display_txt = '%s: %.2f' % (label_name, sc)
        else:
            display_txt = '%s: ans' % (label_name)

        # 框的坐标
        xy = (bb[0], bb[1])
        width = bb[2] - bb[0]
        height = bb[3] - bb[1]

        # 画长方形
        currentAxis.add_patch(plt.Rectangle(
            xy, width, height, fill=False, edgecolor=color, linewidth=2))

        # 在长方形框的左上角画标签
        currentAxis.text(xy[0], xy[1], display_txt, bbox={
            'facecolor': color, 'alpha': 0.5})


# In[ ]:


class SSDPredictShow():
    """集中进行SSD上的预测和图像的显示的类"""

    def __init__(self, img_list, dataset, eval_categories, net=None, dataconfidence_level=0.6):
        self.img_list = img_list
        self.dataset = dataset
        self.net = net
        self.dataconfidence_level = dataconfidence_level
        self.eval_categories = eval_categories

    def show(self, img_index, predict_or_ans):
        """
        用于预测和表示物体检测的函数。

        Parameters
        ----------
        img_index:  int
            数据集中预测对象图像的索引。
        predict_or_ans: text
            '用precit'或'ans'指定显示BBox的预测还是正确答案

        Returns
        -------
        没有。显示在rgb_img中加入了物体检测结果的图像。
        """
        rgb_img, true_bbox, true_label_index, predict_bbox, pre_dict_label_index, scores = ssd_predict(img_index, self.img_list,
                                                                                                       self.dataset,
                                                                                                       self.net,
                                                                                                       self.dataconfidence_level)

        if predict_or_ans == "predict":
            vis_bbox(rgb_img, bbox=predict_bbox, label_index=pre_dict_label_index,
                     scores=scores, label_names=self.eval_categories)

        elif predict_or_ans == "ans":
            vis_bbox(rgb_img, bbox=true_bbox, label_index=true_label_index,
                     scores=None, label_names=self.eval_categories)


# # 执行推论

# In[ ]:


from utils.ssd_model import make_datapath_list, VOCDataset, DataTransform, Anno_xml2list, od_collate_fn

# 获取文件路径的列表
rootpath = os.path.join(os.getcwd(), "data", "VOCdevkit", "VOC2012")
train_img_list, train_anno_list, val_img_list, val_anno_list = make_datapath_list(rootpath)

#  创建Dataset
voc_classes = ['aeroplane', 'bicycle', 'bird', 'boat',
               'bottle', 'bus', 'car', 'cat', 'chair',
               'cow', 'diningtable', 'dog', 'horse',
               'motorbike', 'person', 'pottedplant',
               'sheep', 'sofa', 'train', 'tvmonitor']
color_mean = (104, 117, 123)  # (BGR)颜色的平均值
input_size = 300  # 将图像的input大小设为300×300

train_dataset = VOCDataset(train_img_list, train_anno_list, phase="val", transform=DataTransform(
    input_size, color_mean), transform_anno=Anno_xml2list(voc_classes))

val_dataset = VOCDataset(val_img_list, val_anno_list, phase="val", transform=DataTransform(
    input_size, color_mean), transform_anno=Anno_xml2list(voc_classes))

# In[ ]:


from utils.ssd_model import SSD

# 设置SSD300
ssd_cfg = {
    'num_classes': 21,  # 包含背景分类的总分类数
    'input_size': 300,  # 图像的输入尺寸
    'bbox_aspect_num': [4, 6, 6, 6, 4, 4],  # 用于输出的DBox的纵横比例的种类
    'feature_maps': [38, 19, 10, 5, 3, 1],  # 各个source的图像尺寸
    'steps': [8, 16, 32, 64, 100, 300],  # 确定DBox的大小
    'min_sizes': [30, 60, 111, 162, 213, 264],  # 确定DBox的大小
    'max_sizes': [60, 111, 162, 213, 264, 315],  # 确定DBox的大小
    'aspect_ratios': [[2], [2, 3], [2, 3], [2, 3], [2], [2]],
}

# SSD网络模型
net = SSD(phase="inference", cfg=ssd_cfg)
net.eval()

# 设置学习完毕的SSD的权重
net_weights = torch.load(os.path.join(os.getcwd(), "data", "ssd300_30.pth"), map_location={'cuda:0': 'cpu'})

# net_weights = torch.load('./weights/ssd300_mAP_77.43_v2.pth',
#                         map_location={'cuda:0': 'cpu'})

net.load_state_dict(net_weights)

# 确认是否可以使用GPU
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("使用设备：", device)

print('网络设置完毕 ：已成功载入学习完毕的权重。')

# In[ ]:


# 结果的绘制
ssd = SSDPredictShow(img_list=train_img_list, dataset=train_dataset, eval_categories=voc_classes,
                     net=net, dataconfidence_level=0.6)
img_index = 0
ssd.show(img_index, "predict")
ssd.show(img_index, "ans")

plt.show()
# 以上
