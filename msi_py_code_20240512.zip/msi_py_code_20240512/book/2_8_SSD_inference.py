#!/usr/bin/env python
# coding: utf-8

# # 2.8 推测的施行
# 
# -本节将使用在 2.7 节中训练好的 SSD 模型对图像进行物体检测操作。
# 

# # 学习目标
# 
# 1.	掌握 SSD 推测的实现方法。

# # 事前准备
# 
# -准备学习的权重参数
# -使用文件夹utis的ssd predict show.py

# In[1]:
import os

import cv2  # OpenCVライブラリ
import matplotlib.pyplot as plt
import numpy as np
import torch

# # 推测的施行

# In[2]:


from utils.ssd_model import SSD

voc_classes = ['aeroplane', 'bicycle', 'bird', 'boat',
               'bottle', 'bus', 'car', 'cat', 'chair',
               'cow', 'diningtable', 'dog', 'horse',
               'motorbike', 'person', 'pottedplant',
               'sheep', 'sofa', 'train', 'tvmonitor']

# 设置SSD300
ssd_cfg = {
    'num_classes': 21,  # 包含背景分类的总分类数
    'input_size': 300,  # 图像的输入尺寸
    'bbox_aspect_num': [4, 6, 6, 6, 4, 4],  # 用于输出的DBox的纵横比例的种类
    'feature_maps': [38, 19, 10, 5, 3, 1],  # 各个source的图像尺寸
    'steps': [8, 16, 32, 64, 100, 300],  # 确定DBox的大小
    'min_sizes': [30, 60, 111, 162, 213, 264],  # 确定DBox的大小
    'max_sizes': [60, 111, 162, 213, 264, 315],  # 确定DBox的大小
    'aspect_ratios': [[2], [2, 3], [2, 3], [2, 3], [2], [2]],
}

# #SSD网络模型
net = SSD(phase="inference", cfg=ssd_cfg)

# 设置学习完毕的SSD的权重
# net_weights = torch.load('./weights/ssd300_50.pth', map_location={'cuda:0': 'cpu'})

net_weights = torch.load(os.path.join(os.getcwd(), "data", "ssd300_mAP_77.43_v2.pth"), map_location={'cuda:0': 'cpu'})
# net_weights = torch.load(os.path.join(os.getcwd(), "data", "ssd300_40.pth"), map_location={'cuda:0': 'cpu'})

net.load_state_dict(net_weights)

print('网络设置完毕 ：已成功载入学习完毕的权重。')

# In[3]:


from utils.ssd_model import DataTransform

# 1.读入图像数据
image_file_path = os.path.join(os.getcwd(), "data", "cowboy-757575_640.jpg")

img = cv2.imread(image_file_path)  # [高度][宽度][颜色BGR]
height, width, channels = img.shape  # 取得图像的尺寸

# 2.显示原有的图像
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.show()

# 3.创建预处理类
color_mean = (104, 117, 123)  # (BGR)颜色的平均值
input_size = 300  # 设置图像的input尺寸为300像素×300像素
transform = DataTransform(input_size, color_mean)

# 4. 预处理
phase = "val"
img_transformed, boxes, labels = transform(img, phase, "", "")  # 因为不能存在标注，所以设置为 ""
img = torch.from_numpy(img_transformed[:, :, (2, 1, 0)]).permute(2, 0, 1)

# 5.使用SSD 进行预测
net.eval()  # 将网络设置为推测模式
x = img.unsqueeze(0)  # 小批量化：torch.Size([1, 3, 300, 300])
detections = net(x)

# print(detections.shape)
# print(detections)

# output : torch.Size([batch_num, 21, 200, 5])
# =（batch_num，分类，conf的top200，格式化后的BBox信息）
# 格式化后的BBox信息（置信度，xmin, ymin, xmax, ymax）

# In[4]:

# 对图像进行预测
from utils.ssd_predict_show import SSDPredictShow

# 文件路径
# image_file_path = "./data/cowboy-757575_640.jpg"

# 将预测和预测结果绘制在图像上
ssd = SSDPredictShow(eval_categories=voc_classes, net=net)
ssd.show(image_file_path, data_confidence_level=0.6)
plt.show()
# 以上
