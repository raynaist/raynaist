import torch
import os

vgg_weights_path = os.path.join(os.getcwd(), "vgg16_reducedfc.pth")

# print(vgg_weights_path)

print((2 == 2))
