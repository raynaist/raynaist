#!/usr/bin/env python
# coding: utf-8

# # 2.4 网络模型的实现、2.5 正向传播函数的实现
# 
# 在本文件中，创建SSD的网络模型和顺序传播forward函数。
# 

# # 2.4 学習目標
# 
# 1.	SSDのネットワークモデルを構築している4つのモジュールを把握する
# 2.	SSDのネットワークモデルを作成できるようになる
# 3.	SSDで使用する様々な大きさのデフォルトボックスの実装方法を理解する
# 
# 

# # 2.5 学习目标
# 
# 1.	理解 SSD 网络模型是由哪四个模块构成的。
# 2.	掌握构建 SSD 网络模型的方法。
# 3.	理解如何实现 SSD 中使用的各种大小不同的 DBox。
# 

# # 事前准备
# 
# 
# 没有特别

# In[1]:


# パッケージのimport
from math import sqrt
from itertools import product

import pandas as pd
import torch
from torch.autograd import Function
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init


# # vgg 模块的实现

# In[2]:


# 创建34层神经网络的vgg模块
def make_vgg():
    layers = []
    in_channels = 3  # 颜色通道数

    # 在vgg模块中使用的卷积层和最大池化等的通道数
    cfg = [64, 64, 'M', 128, 128, 'M', 256, 256,
           256, 'MC', 512, 512, 512, 'M', 512, 512, 512]

    for v in cfg:
        if v == 'M':
            layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
        elif v == 'MC':
            # ceil模式输出的尺寸，对计算结果（float）进行向上取整
            # 默认情况下输出的尺寸，对计算结果（float）进行向下取整的floor模式
            layers += [nn.MaxPool2d(kernel_size=2, stride=2, ceil_mode=True)]
        else:
            conv2d = nn.Conv2d(in_channels, v, kernel_size=3, padding=1)
            layers += [conv2d, nn.ReLU(inplace=True)]
            in_channels = v

    pool5 = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
    conv6 = nn.Conv2d(512, 1024, kernel_size=3, padding=6, dilation=6)
    conv7 = nn.Conv2d(1024, 1024, kernel_size=1)
    layers += [pool5, conv6,
               nn.ReLU(inplace=True), conv7, nn.ReLU(inplace=True)]
    return nn.ModuleList(layers)


# 确认执行结果
vgg_test = make_vgg()
print(vgg_test)


# #extras 模块的实现

# In[4]:


# 创建8层网络的extras模块
def make_extras():
    layers = []
    in_channels = 1024  # 从vgg模块输出，作为extras模块的输入图像的通道数

    # extras模块的卷积层的通道数的配置数据
    cfg = [256, 512, 128, 256, 128, 256, 128, 256]

    layers += [nn.Conv2d(in_channels, cfg[0], kernel_size=(1))]
    layers += [nn.Conv2d(cfg[0], cfg[1], kernel_size=(3), stride=2, padding=1)]
    layers += [nn.Conv2d(cfg[1], cfg[2], kernel_size=(1))]
    layers += [nn.Conv2d(cfg[2], cfg[3], kernel_size=(3), stride=2, padding=1)]
    layers += [nn.Conv2d(cfg[3], cfg[4], kernel_size=(1))]
    layers += [nn.Conv2d(cfg[4], cfg[5], kernel_size=(3))]
    layers += [nn.Conv2d(cfg[5], cfg[6], kernel_size=(1))]
    layers += [nn.Conv2d(cfg[6], cfg[7], kernel_size=(3))]

    # 激励函数ReLU放到SSD模型的正向传播函数中实现
    ## 不在extras模块中实现

    return nn.ModuleList(layers)


# 确认执行结果
extras_test = make_extras()
print(extras_test)


# #loc模块与conf模块的实现

# In[5]:


# loc_layers负责输出DBox的位移值
# 创建用于输出对DBox的每个分类的置信度confidence的conf_layers


def make_loc_conf(num_classes=21, bbox_aspect_num=[4, 6, 6, 6, 4, 4]):
    loc_layers = []
    conf_layers = []

    # VGG的第22层，对应conv4_3（source1）的卷积层
    loc_layers += [nn.Conv2d(512, bbox_aspect_num[0]
                             * 4, kernel_size=3, padding=1)]
    conf_layers += [nn.Conv2d(512, bbox_aspect_num[0]
                              * num_classes, kernel_size=3, padding=1)]

    # VGG的最后一层，对应（source2）的卷积层
    loc_layers += [nn.Conv2d(1024, bbox_aspect_num[1]
                             * 4, kernel_size=3, padding=1)]
    conf_layers += [nn.Conv2d(1024, bbox_aspect_num[1]
                              * num_classes, kernel_size=3, padding=1)]

    # extras的对应（source3）的卷积层
    loc_layers += [nn.Conv2d(512, bbox_aspect_num[2]
                             * 4, kernel_size=3, padding=1)]
    conf_layers += [nn.Conv2d(512, bbox_aspect_num[2]
                              * num_classes, kernel_size=3, padding=1)]

    # extras的对应（source4）的卷积层
    loc_layers += [nn.Conv2d(256, bbox_aspect_num[3]
                             * 4, kernel_size=3, padding=1)]
    conf_layers += [nn.Conv2d(256, bbox_aspect_num[3]
                              * num_classes, kernel_size=3, padding=1)]

    # extras的对应（source5）的卷积层
    loc_layers += [nn.Conv2d(256, bbox_aspect_num[4]
                             * 4, kernel_size=3, padding=1)]
    conf_layers += [nn.Conv2d(256, bbox_aspect_num[4]
                              * num_classes, kernel_size=3, padding=1)]

    # extras的对应（source6）的卷积层
    loc_layers += [nn.Conv2d(256, bbox_aspect_num[5]
                             * 4, kernel_size=3, padding=1)]
    conf_layers += [nn.Conv2d(256, bbox_aspect_num[5]
                              * num_classes, kernel_size=3, padding=1)]

    return nn.ModuleList(loc_layers), nn.ModuleList(conf_layers)


# 确认执行结果
loc_test, conf_test = make_loc_conf()
print(loc_test)
print(conf_test)


# L2Norm层的实现

# In[10]:


# 对convC4_3的输出进行scale=20的L2Norm的正规化处理的层
class L2Norm(nn.Module):
    def __init__(self, input_channels=512, scale=20):
        super(L2Norm, self).__init__()  # 调用父类的构造函数
        self.weight = nn.Parameter(torch.Tensor(input_channels))
        self.scale = scale  # 系数weight的初始值
        self.reset_parameters()  # 对参数进行初始化
        self.eps = 1e-10

    def reset_parameters(self):
        '''将连接参数设置为大小为scale的值，执行初始化'''
        init.constant_(self.weight, self.scale)  # weight的值全部设为scale（=20）

    def forward(self, x):
        '''对38×38的特征量，求512个通道的平方和的根值
        使用38×38个值，对每个特征量进行正规化处理后再乘以系数的层'''

        # 对每个通道进行38x38个特征量的通道方向的平方和计算
        # 接下来进行正规化处理
        # norm的张量尺寸为torch.Size([batch_num, 1, 38, 38])
        norm = x.pow(2).sum(dim=1, keepdim=True).sqrt() + self.eps
        x = torch.div(x, norm)

        # 乘以系数。每个通道1个系数，总共有512个系数
        # 因为self.weight的张量尺寸是torch.Size([512])
        # 转换为torch.Size([batch_num, 512, 38, 38])
        weights = self.weight.unsqueeze(
            0).unsqueeze(2).unsqueeze(3).expand_as(x)
        out = weights * x

        return out


# Default Box 的实现

# In[12]:


# 输出DBox的类
class DBox(object):
    def __init__(self, cfg):
        super(DBox, self).__init__()

        # 初始化设置
        self.image_size = cfg['input_size']  # 图像尺寸为300像素
        # [38, 19, …] 每个source的特征量图的大小
        self.feature_maps = cfg['feature_maps']
        self.num_priors = len(cfg["feature_maps"])  # source的个数=6
        self.steps = cfg['steps']  # [8, 16, …]DBox的像素尺寸
        self.min_sizes = cfg['min_sizes']  # [30, 60, …] 小正方形的DBox的像素尺寸
        self.max_sizes = cfg['max_sizes']  # [60, 111, …]大正方形的DBox的像素尺寸
        self.aspect_ratios = cfg['aspect_ratios']  # 长方形的DBox的纵横比

    def make_dbox_list(self):
        ''''创建DBox'''
        mean = []
        # 'feature_maps': [38, 19, 10, 5, 3, 1]
        for k, f in enumerate(self.feature_maps):
            for i, j in product(range(f), repeat=2):  # 创建到f为止的2对排列组合f_P_2 个
                # 特征量的图像尺寸
                # 300 / 'steps': [8, 16, 32, 64, 100, 300],
                f_k = self.image_size / self.steps[k]

                # DBox的中心坐标x,y　但是，正规化为0～1的值
                cx = (j + 0.5) / f_k
                cy = (i + 0.5) / f_k

                # 宽高比为1的小DBox [cx,cy, width, height]
                # 'min_sizes': [30, 60, 111, 162, 213, 264]
                s_k = self.min_sizes[k] / self.image_size
                mean += [cx, cy, s_k, s_k]

                # 宽高比为1的大DBox [cx,cy, width, height]
                # 'max_sizes': [45, 99, 153, 207, 261, 315],
                s_k_prime = sqrt(s_k * (self.max_sizes[k] / self.image_size))
                mean += [cx, cy, s_k_prime, s_k_prime]

                # 其他宽高比的DBox [cx,cy, width, height]
                for ar in self.aspect_ratios[k]:
                    mean += [cx, cy, s_k * sqrt(ar), s_k / sqrt(ar)]
                    mean += [cx, cy, s_k / sqrt(ar), s_k * sqrt(ar)]

        # 将DBox转换成张量torch.Size([8732, 4])
        output = torch.Tensor(mean).view(-1, 4)

        # 为防止DBox的大小超出图像范围，将尺寸调整为最小为0，最大为1
        output.clamp_(max=1, min=0)

        return output


# In[13]:


# 确认执行结果

# 设置SSD300
ssd_cfg = {
    'num_classes': 21,  # 包含背景类的总类数
    'input_size': 300,  # 图像的输入尺寸
    'bbox_aspect_num': [4, 6, 6, 6, 4, 4],  # 要输出的DBox的宽高比的种类
    'feature_maps': [38, 19, 10, 5, 3, 1],  # 各个source的图像尺寸
    'steps': [8, 16, 32, 64, 100, 300],  # 确定DBox的大小
    'min_sizes': [30, 60, 111, 162, 213, 264],  # 确定DBox的大小
    'max_sizes': [60, 111, 162, 213, 264, 315],  # 确定DBox的大小
    'aspect_ratios': [[2], [2, 3], [2, 3], [2, 3], [2], [2]]
}

# 创建DBox
dbox = DBox(ssd_cfg)
dbox_list = dbox.make_dbox_list()

# 确认DBox的输出结果
print(pd.DataFrame(dbox_list.numpy()))


# SSD类的实现

# In[14]:


# 创建SSD类
class SSD(nn.Module):

    def __init__(self, phase, cfg):
        super(SSD, self).__init__()

        self.phase = phase  # 指定是训练还是推测
        self.num_classes = cfg["num_classes"]  # 类的数量 =21n
        # 生成SSD网络
        self.vgg = make_vgg()
        self.extras = make_extras()
        self.L2Norm = L2Norm()
        self.loc, self.conf = make_loc_conf(
            cfg["num_classes"], cfg["bbox_aspect_num"])

        # 生成DBox
        dbox = DBox(cfg)
        self.dbox_list = dbox.make_dbox_list()

        # 推测时使用Detect类
        if phase == 'inference':
            self.detect = Detect()


# 确认执行结果
ssd_test = SSD(phase="train", cfg=ssd_cfg)
print(ssd_test)


# # 2.5 正向传播函数的实现

# # decode函数的实现

# In[15]:


# 使用位移信息，将DBox转换成BBox的函数


def decode(loc, dbox_list):
    """
    使用位移信息，将DBox转换成BBox

    Parameters
    ----------
    loc:  [8732,4]
        用SSD模型推测位移信息
    dbox_list: [8732,4]
        BBox的信息

    Returns
    -------
    boxes : [xmin, ymin, xmax, ymax]
        BBoxの情報
    """

    # DBox以[cx, cy, width, height]形式被保存
    # loc以[Δcx, Δcy, Δwidth, Δheight]形式被保存

    # 从位移信息求取BBox
    boxes = torch.cat((
        dbox_list[:, :2] + loc[:, :2] * 0.1 * dbox_list[:, 2:],
        dbox_list[:, 2:] * torch.exp(loc[:, 2:] * 0.2)), dim=1)
    # boxes的尺寸为torch.Size([8732, 4])

    # BBox的坐标信息从[cx, cy, width, height]变为[xmin, ymin, xmax, ymax]
    boxes[:, :2] -= boxes[:, 2:] / 2  # 变换为坐标(xmin,ymin)
    boxes[:, 2:] += boxes[:, :2]  # 变换为坐标(xmax,ymax)

    return boxes


# Non-Maximum Suppression函数的实现

# In[16]:


# 进行Non−Maximum Suppression处理的函数


def nm_suppression(boxes, scores, overlap=0.45, top_k=200):
    """
    进行Non−Maximum Suppression处理的函数
    将boxes中过于重叠的BBox删除

    Parameters
    ----------
    boxes : [超过了置信度阈值（0.01）的BBox数量,4]
        BBox情報。
    scores :[超过了置信度阈值（0.01）的BBox数量]
        conf的信息

    Returns
    -------
    keep : 列表
       保存按conf降序通过了nms处理的index
    count：int
        通过了nms处理的BBox的数量
    """

    # 创建return的雏形
    count = 0
    keep = scores.new(scores.size(0)).zero_().long()
    # keep ：torch.Size([超过了置信度阈值的BBox数量])，元素全部为0

    # 计算各个BBox的面积area
    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    x2 = boxes[:, 2]
    y2 = boxes[:, 3]
    area = torch.mul(x2 - x1, y2 - y1)

    # 复制boxes，准备用于稍后进行BBox的过重叠度IoU计算时使用的雏形
    tmp_x1 = boxes.new()
    tmp_y1 = boxes.new()
    tmp_x2 = boxes.new()
    tmp_y2 = boxes.new()
    tmp_w = boxes.new()
    tmp_h = boxes.new()

    # 将socre按升序排列
    v, idx = scores.sort(0)

    # 将前面top_k个(200个)BBox的index取出（也有不到200个的情况）
    idx = idx[-top_k:]

    # 当idx的元素数量不为0时，则执行循环
    while idx.numel() > 0:
        i = idx[-1]  # 将现在conf最大的index赋值给i

        # 将conf最大的index保存到keep中现在最末尾的位置
        # 开始删除该index的BBox和重叠较大的BBox
        keep[count] = i
        count += 1

        # 当处理到最后一个BBox时，跳出循环
        if idx.size(0) == 1:
            break

        # keep中保存了目前的conf最大的index,因此将idx减1
        idx = idx[:-1]

        # -------------------
        # 开始对keep中保存的BBox和重叠较大的BBox抽取出来并删除
        # -------------------
        # 到减去1的idx为止，将BBox放到out指定的变量中
        torch.index_select(x1, 0, idx, out=tmp_x1)
        torch.index_select(y1, 0, idx, out=tmp_y1)
        torch.index_select(x2, 0, idx, out=tmp_x2)
        torch.index_select(y2, 0, idx, out=tmp_y2)

        # 对所有的BBox，当前的BBox=index被到i为止的值覆盖（clamp）
        tmp_x1 = torch.clamp(tmp_x1, min=x1[i])
        tmp_y1 = torch.clamp(tmp_y1, min=y1[i])
        tmp_x2 = torch.clamp(tmp_x2, max=x2[i])
        tmp_y2 = torch.clamp(tmp_y2, max=y2[i])

        # 将w和h的张量尺寸设置为index减去1后的结果
        tmp_w.resize_as_(tmp_x2)
        tmp_h.resize_as_(tmp_y2)

        # 将w和h的张量尺寸设置为index减去1后的结果
        tmp_w = tmp_x2 - tmp_x1
        tmp_h = tmp_y2 - tmp_y1

        # 如果高度或宽度为负数，则设为0
        tmp_w = torch.clamp(tmp_w, min=0.0)
        tmp_h = torch.clamp(tmp_h, min=0.0)

        ##计算经过clamp处理后的面积
        inter = tmp_w * tmp_h

        # IoU = intersect部分/[area(a) + area(b) – intersect部分]的计算
        rem_areas = torch.index_select(area, 0, idx)  # 各个BBox的原有面积
        union = (rem_areas - inter) + area[i]  # 对两个区域的面积求与
        IoU = inter / union

        # 只保留IoU比overlap小的idx
        idx = idx[IoU.le(overlap)]  # le是进行Less than or Equal to处理的逻辑运算
        # IoU比overlap大的idx，与刚开始选择并保存到keep中的idx对相同的物体进行了BBox包围，因此要删除

    # while跳出循环体，结束执行

    return keep, count


# # Detect 类的实现

# In[17]:


# 从SSD的推测时的conf和loc的输出数据，得到消除了重叠的BBox并输出


class Detect(Function):

    def __init__(self, conf_thresh=0.01, top_k=200, nms_thresh=0.45):
        self.softmax = nn.Softmax(dim=-1)  # 准备使用Softmax函数对conf进行正规化处理
        self.conf_thresh = conf_thresh  # 只处理conf高于conf_thresh=0.01的DBox
        self.top_k = top_k  # 对conf最高的top_k个进行nm_supression计算时使用, top_k = 200
        self.nms_thresh = nms_thresh  # 进行nm_supression计算时，如果IoU比nms_thresh=0.45大，就认为是同一                                                               物体的BBox

    def forward(self, loc_data, conf_data, dbox_list):
        """
        执行正向传播计算

        Parameters
        ----------
        loc_data:  [batch_num,8732,4]
            位移信息。
        conf_data: [batch_num, 8732,num_classes]
            检测的置信度。
        dbox_list: [8732,4]
            DBox的信息

        Returns
        -------
        output : torch.Size([batch_num, 21, 200, 5])
            （batch_num、分类、conf的top200、BBox的信息）
        """

        # 获取各个尺寸
        num_batch = loc_data.size(0)  # 最小批的尺寸
        num_dbox = loc_data.size(1)  # DBox的数量= 8732
        num_classes = conf_data.size(2)  # 分类数量= 21

        # 使用Softmax对conf进行正规化处理
        conf_data = self.softmax(conf_data)

        # 生成输出数据对象。张量尺寸为[minibatch数, 21, 200, 5]
        output = torch.zeros(num_batch, num_classes, self.top_k, 5)

        # 将cof_data从[batch_num,8732,num_classes]调整为[batch_num, num_classes,8732]
        conf_preds = conf_data.transpose(2, 1)

        # 按最小批进行循环处理
        for i in range(num_batch):

            # 1.从loc和DBox求取修正过的BBox [xmin, ymin, xmax, ymax]
            decoded_boxes = decode(loc_data[i], dbox_list)

            # 创建conf的副本
            conf_scores = conf_preds[i].clone()

            # 图像分类的循环（作为背景分类的index=0不进行计算，从index=1开始）
            for cl in range(1, num_classes):

                # 2.抽出超过了conf阈值的BBox
                # 创建用来表示是否超过了conf阈值的掩码
                # 将阈值超过conf的索引赋值给c_mask
                c_mask = conf_scores[cl].gt(self.conf_thresh)
                # gt表示Greater Than。超过阈值gt返回1，未超过则返回0
                # conf_scores:torch.Size([21, 8732])
                # c_mask:torch.Size([8732])

                # scores是torch.Size([超过阈值的BBox的数量])
                scores = conf_scores[cl][c_mask]

                # 如果不存在超过阈值的conf，即当scores=[]时,则不做任何处理
                if scores.nelement() == 0:  # 用nelement求取要素的数量
                    continue

                # 对c_mask进行转换，使其能适用于decoded_boxes的大小
                l_mask = c_mask.unsqueeze(1).expand_as(decoded_boxes)
                # l_mask:torch.Size([8732, 4])

                # 将l_mask用于decoded_boxes
                boxes = decoded_boxes[l_mask].view(-1, 4)
                # decoded_boxes[l_mask]调用会返回一维列表
                # 因此用view转换为（超过阈值的BBox数， 4）的尺寸

                # 3.开始Non−Maximum Suppression处理，消除重叠的BBox
                ids, count = nm_suppression(
                    boxes, scores, self.nms_thresh, self.top_k)
                # ids ：用于保存按conf降序排列通过了Non−Maximum Suppression处理的index
                # count ：通过了Non−Maximum Suppression处理的BBox的数量

                # 将通过了Non−Maximum Suppression处理的结果保存到output中
                output[i, cl, :count] = torch.cat((scores[ids[:count]].unsqueeze(1),
                                                   boxes[ids[:count]]), 1)

        return output  # torch.Size([1, 21, 200, 5])


# # SSD 模块的实现

# In[18]:


# 创建SSD类


class SSD(nn.Module):

    def __init__(self, phase, cfg):
        super(SSD, self).__init__()

        self.phase = phase  # 指定是train 还是inference
        self.num_classes = cfg["num_classes"]  # 分类数=21

        # 创建SSD神经网络
        self.vgg = make_vgg()
        self.extras = make_extras()
        self.L2Norm = L2Norm()
        self.loc, self.conf = make_loc_conf(
            cfg["num_classes"], cfg["bbox_aspect_num"])

        # 创建DBox
        dbox = DBox(cfg)
        self.dbox_list = dbox.make_dbox_list()

        # 推测模式下，需要使用Detect类
        if phase == 'inference':
            self.detect = Detect()

    def forward(self, x):
        sources = list()  # 保存source1～source6作为loc和conf的输入数据
        loc = list()  # 用于保存loc的输出数据
        conf = list()  # 用于保存conf的输出数据

        # 计算到vgg的conv4_3
        for k in range(23):
            x = self.vgg[k](x)

        # 将conv4_3的输出作为L2Norm的输入，创建source1，并添加到sources中
        source1 = self.L2Norm(x)
        sources.append(source1)

        # 计算至vgg的末尾，创建source2，并添加到sources中
        for k in range(23, len(self.vgg)):
            x = self.vgg[k](x)

        sources.append(x)

        # 计算extras的conv和ReLU
        # 并将source3～source6添加到sources中
        for k, v in enumerate(self.extras):
            x = F.relu(v(x), inplace=True)
            if k % 2 == 1:  # conv→ReLU→cov→ReLU完成后，放到source中
                sources.append(x)

        # 对source1～source6分别进行一次卷积处理
        # 使用zip获取for循环的多个列表的元素
        # 需要处理source1～source6的数据，因此循环6次
        for (x, l, c) in zip(sources, self.loc, self.conf):
            # 使用Permute调整要素的顺序
            loc.append(l(x).permute(0, 2, 3, 1).contiguous())
            conf.append(c(x).permute(0, 2, 3, 1).contiguous())
        # 用l(x)和c(x)进行卷积操作
        # l(x)和c(x)的输出尺寸是[batch_num, 4*宽高比的种类数, featuremap的高度,featuremap的宽度]
        # 不同source的宽高比的种类数量不同，处理比较麻烦，因此对顺序进行调整
        # 使用Permute调整要素的顺序
        # 增加到[minibatch的数量, featuremap的数量, featuremap的数量,4*宽高比的种类数]
        # （注释）
        # torch.contiguous()是在内存中连续的设置元素的命令
        # 稍后使用view函数
        # 为了能够执行view函数，对象的变量在内存中必须是被连续存储的。

        # 对loc和conf进行变形
        # loc的尺寸是torch.Size([batch_num, 34928])
        # conf的尺寸是torch.Size([batch_num, 183372])
        loc = torch.cat([o.view(o.size(0), -1) for o in loc], 1)
        conf = torch.cat([o.view(o.size(0), -1) for o in conf], 1)

        # 进一步对loc和conf进行对齐
        # loc的尺寸是torch.Size([batch_num, 8732, 4])
        # conf的尺寸是torch.Size([batch_num, 8732, 21])
        loc = loc.view(loc.size(0), -1, 4)
        conf = conf.view(conf.size(0), -1, self.num_classes)

        # 最后输出结果
        output = (loc, conf, self.dbox_list)

        if self.phase == "inference":  # 推测模式
            # 执行Detect类的forward
            # 返回值的尺寸是torch.Size([batch_num, 21, 200, 5])
            return self.detect(output[0], output[1], output[2])

        else:  # 学习模式
            return output
        # 返回值是(loc, conf, dbox_list)的元组

# 以上
