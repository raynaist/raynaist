# Dogs-Cats
A project built to train a model which can recognize pictures of dogs and cats, and make a classification.
