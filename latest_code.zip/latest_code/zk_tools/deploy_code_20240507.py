# import os
# import shutil
#
# SRC_FOLDER = r"D:\zhangkun_20240407\pycharm_code_20240407\Camera-Calibration-Reconstruct"
# DEAL_FOLDER = r"D:\zhangkun_20240407\pycharm_code_20240407\deployment_code_0423\Camera-Calibration-Reconstruct"
# DEAL_FILE = r"D:\zhangkun_20240407\pycharm_code_20240407\deployment_code_0423\Camera-Calibration-Reconstruct.rar"
#
# if os.path.exists(DEAL_FOLDER):
#     for root, dirs, files in os.walk(DEAL_FOLDER):
#         for file in files:
#             file_path = os.path.join(root, file)
#             os.chmod(file_path, 0o777)  # 设置文件权限为可读可写可执行
#
#     shutil.rmtree(DEAL_FOLDER)
#
# if os.path.exists(DEAL_FILE):
#     os.remove(DEAL_FILE)
#
#
# def ignore_files(dir, files):
#     return [file for file in files if file.endswith(('.jpg', '.png'))]
#
#
# shutil.copytree(SRC_FOLDER, DEAL_FOLDER, ignore=ignore_files)
