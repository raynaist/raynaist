import os

file_path=r"G:\original_dataset\product_identify\produc_salt.jpg"

_basename=os.path.basename(file_path)
_splitext=os.path.splitext(_basename)

pass
