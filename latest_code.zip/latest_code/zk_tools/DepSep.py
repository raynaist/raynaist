import torch
import torch.nn as nn


# 定义一个简单的深度可分离卷积块
class DepthwiseSeparableConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(DepthwiseSeparableConvBlock, self).__init__()

        # 深度卷积层（Depthwise Convolution）
        self.depthwise_conv = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=stride, padding=1, groups=in_channels)
        self.depthwise_bn = nn.BatchNorm2d(in_channels)

        # 逐点卷积层（Pointwise Convolution）
        self.pointwise_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.pointwise_bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        out = self.depthwise_conv(x)
        out = self.depthwise_bn(out)
        out = nn.ReLU(inplace=True)(out)

        out = self.pointwise_conv(out)
        out = self.pointwise_bn(out)
        out = nn.ReLU(inplace=True)(out)

        return out


# 创建一个包含深度可分离卷积的简单模型
class MobileNet(nn.Module):
    def __init__(self, num_classes=5):
        super(MobileNet, self).__init__()

        self.model = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),

            DepthwiseSeparableConvBlock(32, 64, stride=1),
            DepthwiseSeparableConvBlock(64, 128, stride=2),
            DepthwiseSeparableConvBlock(128, 128, stride=1),
            DepthwiseSeparableConvBlock(128, 256, stride=2),
            DepthwiseSeparableConvBlock(256, 256, stride=1),

            nn.AdaptiveAvgPool2d(1)
        )

        self.fc = nn.Linear(256, num_classes)

    def forward(self, x):
        x = self.model(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x


if __name__ == '__main__':
    # 创建一个示例MobileNet模型
    mobilenet = MobileNet()
    data = torch.randn(4, 3, 128, 128)
    out = mobilenet(data)
    print(mobilenet)
    print(out.shape)
