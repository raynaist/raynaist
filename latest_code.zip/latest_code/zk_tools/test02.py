
import torch

print( torch.cuda.is_available())

## CUDA - GPU 占用显著提高（>95,NVIDIA 3060 LAP

import torch
import torch.nn as nn
import torch.optim as optim

# 检查CUDA是否可用
if torch.cuda.is_available():
    device = torch.device("cuda")
    print("CUDA is available. Using GPU.")
else:
    raise Exception("CUDA is not available. Please ensure you have a GPU.")




bat test sssssssssssssssssssssss