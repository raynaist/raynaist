import numpy as np
import matplotlib.pyplot as plt

# 生成一组示例数据，包括正数和零
x = np.linspace(0.1, 5, 100)  # 生成0.1到5之间的100个数据点

# 计算对数
# log_x = np.log(x)
log_x = np.exp(x)

# 绘制原始数据和对数化后的数据
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.plot(x, x, label='Original Data')
plt.title('Original Data')

plt.subplot(1, 2, 2)
plt.plot(x, log_x, label='Log Transformed Data', color='orange')
plt.title('Log Transformed Data')

plt.tight_layout()
plt.show()
