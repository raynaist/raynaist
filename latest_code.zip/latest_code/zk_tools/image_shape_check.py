import os

from PIL import Image


def image_shape_check():
    path = r"D:\PycharmProjects\face_recognition_1120\data\student_image"

    for root, dirs, files in os.walk(path):
        for file in files:
            img_path = os.path.join(root, file)
            img_data = Image.open(img_path)

            if img_data.size[0] != 224 or img_data.size[1] != 224:
                print(img_path)


if __name__ == '__main__':
    image_shape_check()
