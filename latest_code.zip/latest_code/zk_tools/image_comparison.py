from PIL import Image

# 打开两张图片
# image1 = Image.open(r"D:\PycharmProjects\ZKYOLO_Minions_0918\data\img\src_minions_png\3.png")
# image2 = Image.open(r"D:\PycharmProjects\ZKYOLO_Minions_0918\data\img\src_minions_png\minions_PNG45.png")

# 比较图片的像素数据是否一致
if image1.tobytes() == image2.tobytes():
    print("图片内容相同")
else:
    print("图片内容不同")
