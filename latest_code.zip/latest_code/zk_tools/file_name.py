import os

file_path = r"G:\original_dataset\product_identify\product_yolo\images\a.v.v.frame_6_salt.jpg.txt"

_basename = os.path.basename(file_path)
_splitext = os.path.splitext(_basename)

pass
