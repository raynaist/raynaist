import os


def file_count():
    # path = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dataset_yolo_equalization"
    # path = r"D:\PycharmProjects\face_recognition_1120\data\student_image"
    path = r"D:\PycharmProjects\face_recognition_1120\data\student_image_test"
    # path = r"D:\PycharmProjects\face_recognition_1120\data\original_class_faces"
    # path = r"D:\PycharmProjects\face_recognition_1120\data\face_crop"
    # path = r"D:\PycharmProjects\face_recognition_1120\data\feature_image"

    for root, dirs, files in os.walk(path):
        if len(files) > 0:
            # print("{:>{}}  {}".format(round(len(files) / 1400, 2), 10, root))
            print("{:>{}}  {}".format(len(files), 10, root))


def delete_duplicate_files(folder1, folder2):
    # 获取两个文件夹中的所有文件名
    all_files1, _ = get_all_files(folder1)
    _, all_files_full_path2 = get_all_files(folder2)

    deleted_num = 0
    for file2 in all_files_full_path2:
        file2_name = file2.split(os.sep)[-1]
        if file2_name in all_files1:
            os.remove(file2)
            print(f"Deleted duplicate file: {file2}")
            deleted_num = deleted_num + 1
    print(f"deleted_num : {deleted_num}")


def get_all_files(folder):
    all_files = []
    all_files_full_path = []

    for root, dirs, files in os.walk(folder):
        for file in files:
            all_files.append(file)
            all_files_full_path.append(os.path.join(root, file))
    return all_files, all_files_full_path


if __name__ == '__main__':
    file_count()

    # folder2_path = r"I:\手机重置系统数据备份_20231118"
    # folder1_path = r"I:\个人文件_20231118\照片汇总"
    # delete_duplicate_files(folder1_path, folder2_path)
