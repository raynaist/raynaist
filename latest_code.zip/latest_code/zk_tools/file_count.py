import os


def file_count():
    # path = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dataset_yolo_equalization"
    path = r"D:\zhangkun_20240407\all_dataset\empty_store_yolo"
    # path = r"D:\PycharmProjects\face_recognition_1120\data\student_image_test"
    # path = r"D:\PycharmProjects\face_recognition_1120\data\original_class_faces"

    for root, dirs, files in os.walk(path):
        if len(files) > 0:
            print("{:>{}}  {}".format(len(files), 10, root))


def file_name():
    path = r"G:\original_dataset\snack_video_20240125\student"
    # path = r"E:\工作\真术相成学习资料_20230610\面试\面试资料_20231211发"

    for root, dirs, files in os.walk(path):
        if len(files) > 0:
            for file in files:
                file_path = os.path.join(root, file)
                file_path = file_path.replace(path, "")
                file_path = file_path.split(os.sep)
                file_path = file_path[::-1]
                file_path = '/'.join(map(str, file_path))  # \t tab
                print(file_path)


if __name__ == '__main__':
    file_count()
    # file_name()
