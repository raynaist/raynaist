import os

import fitz  # PyMuPDF库
from PIL import Image, ImageEnhance
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


def pdf_to_images(pdf_file):
    doc = fitz.open(pdf_file)
    images = []
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        image = page.get_pixmap()
        img = Image.frombytes("RGB", [image.width, image.height], image.samples)
        images.append(img)
    return images


def process_images(images):
    processed_images = []
    for i, img in enumerate(images):
        # 转为黑白
        bw_img = img.convert("L")

        # 增强锐度
        enhancer = ImageEnhance.Sharpness(bw_img)
        sharp_img = enhancer.enhance(3.5)  # 增强锐度的程度x倍锐度

        # 增强图像的对比度
        contrast = ImageEnhance.Contrast(sharp_img)
        enhanced_contrast = contrast.enhance(3.5)  # 增强对比度的程度x倍对比度

        processed_images.append(enhanced_contrast)
    return processed_images


def save_images_as_pdf(images, output_pdf):
    c = canvas.Canvas(output_pdf, pagesize=letter)
    for i, img in enumerate(images):
        img_path = f"temp_image_{i}.png"  # 临时保存图像的文件路径
        img.save(img_path)

        c.drawImage(img_path, 0, 0, width=letter[0], height=letter[1])
        c.showPage()

        # 删除临时图像文件
        os.remove(img_path)

    c.save()


if __name__ == "__main__":
    """
    将PDF转为黑白图
    增强锐度对比度    
    """
    pdf_file = r"F:\电子图书馆\AIBOOK\14772254百面深度学习.pdf"  # 替换为你的PDF文件路径
    images = pdf_to_images(pdf_file)
    processed_images = process_images(images)
    save_images_as_pdf(processed_images, "data/pdf/a4.pdf")
