import cv2
import os
from shutil import rmtree


def video_to_frame():
    # 打开摄像头
    cap = cv2.VideoCapture(video_path)

    # 文件夹重建
    if os.path.exists(left_image_path):
        print("数据删除中……", left_image_path)
        rmtree(left_image_path)
        print("数据已删除", left_image_path)
    os.makedirs(left_image_path)

    if os.path.exists(right_img_path):
        print("数据删除中……", right_img_path)
        rmtree(right_img_path)
        print("数据已删除", right_img_path)
    os.makedirs(right_img_path)

    n = 0

    while (True):
        # 读取摄像头捕获的视频帧
        ret, frame = cap.read()
        if not ret:
            break

        # 在窗口中显示视频帧
        # cv2.imshow('frame', frame)

        # 获取图片的宽度和高度
        height, width = frame.shape[:2]

        # 将图片分为左右两份
        left_image = frame[:, :width // 2]
        right_image = frame[:, width // 2:]

        if n % FRAME_NUM == 0:
            cv2.imwrite(os.path.join(left_image_path, f"left_{n}.jpg"), left_image)
            cv2.imwrite(os.path.join(right_img_path, f"right_{n}.jpg"), right_image)

        n = n + 1

        # 显示左右两份图片
        cv2.imshow('Left Image', left_image)
        cv2.imshow('Right Image', right_image)

        # 检查是否按下了q键，如果是则退出循环
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # 释放摄像头资源并关闭窗口
    cap.release()
    cv2.destroyAllWindows()


def video_capture():
    capture = cv2.VideoCapture(0)
    if not capture.isOpened():
        print("Error opening video file.")
        exit()

    # 设置分辨率
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
    capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))

    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = capture.get(cv2.CAP_PROP_FPS)

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    videoWriter = cv2.VideoWriter(OUTPUT_VIDEO_PATH, fourcc, fps, (width, height))

    # start_time = time.time()

    while True:
        ret, frame = capture.read()
        if not ret:
            break

        output_image_frame = frame

        # 上下左右翻转
        output_image_frame = cv2.flip(output_image_frame, 0)
        output_image_frame = cv2.flip(output_image_frame, 1)

        # usetime = time.time() - start_time
        # if usetime >= WAIT_TIME:
        #     # 保存真实的图片，用于标定
        #     videoWriter.write(frame)

        if cv2.waitKey(1) & 0xFF == ord('p'):
            videoWriter.write(frame)

        # 展示的是上下左右翻转的图片，方便录制时镜头操作p
        cv2.imshow('Demo', output_image_frame)
        if cv2.waitKey(1) & 0xFF == ord(' '):
            break

    capture.release()
    videoWriter.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    '''
    2024年4月11日09:50:53
    实际测量打印出来的棋盘格A4纸图片宽高，24.2mm    
    '''

    OUTPUT_VIDEO_PATH = r"D:\zhangkun_20240407\pycharm_code_20240407\zk_tools\data\camera_calibration\video\video.mp4"
    video_path = OUTPUT_VIDEO_PATH
    left_image_path = r"D:\zhangkun_20240407\pycharm_code_20240407\zk_tools\data\camera_calibration\left_image"
    right_img_path = r"D:\zhangkun_20240407\pycharm_code_20240407\zk_tools\data\camera_calibration\right_img"
    FRAME_NUM = 1  # 多少帧抽一张图片
    WAIT_TIME = 5  # 几秒钟后开始录制视频
    FRAME_WIDTH = 1280
    FRAME_HEIGHT = 480

    video_to_frame()
    # video_capture()
