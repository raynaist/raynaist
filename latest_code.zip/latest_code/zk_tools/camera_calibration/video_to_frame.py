import cv2
import os
from shutil import rmtree


def video_to_frame():
    # 文件夹重建
    if os.path.exists(OUTPUT_IMAGE_PATH):
        print("数据删除中……")
        rmtree(OUTPUT_IMAGE_PATH)
        print("数据已删除")
    os.makedirs(OUTPUT_IMAGE_PATH)

    for vid in os.listdir(INPUT_VIDEO_PATH):

        os.makedirs(os.path.join(OUTPUT_IMAGE_PATH, os.path.splitext(vid)[0]))

        video_path = os.path.join(INPUT_VIDEO_PATH, vid)

        capture = cv2.VideoCapture(video_path)
        if not capture.isOpened():
            print("Error opening video file.")
            exit()

        n = 0
        m = 0
        while True:
            ret, frame = capture.read()
            if not ret:
                break

            if m % IMAGE_FRAME == 0:
                cv2.imwrite(os.path.join(OUTPUT_IMAGE_PATH, os.path.splitext(vid)[0], f"{os.path.splitext(vid)[0]}_frame_{n}.jpg"), frame)
                n = n + 1
            m = m + 1

        print("视频抽帧完成", vid)


if __name__ == '__main__':
    INPUT_VIDEO_PATH = r"D:\zhangkun_20240407\all_dataset\camera_calibration\0426\video"
    OUTPUT_IMAGE_PATH = r"D:\zhangkun_20240407\all_dataset\camera_calibration\0426\frame"
    IMAGE_FRAME = 10  # 多少帧抽一张图片

    # 视频抽帧
    video_to_frame()
