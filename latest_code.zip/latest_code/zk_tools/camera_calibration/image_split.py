import cv2
import os
from shutil import rmtree


def image_split():
    # 文件夹重建
    if os.path.exists(OUTPUT_IMAGE_PATH):
        print("数据删除中……")
        rmtree(OUTPUT_IMAGE_PATH)
        print("数据已删除")

    os.makedirs(OUTPUT_IMAGE_PATH)

    for dir in os.listdir(INPUT_VIDEO_PATH):
        os.makedirs(os.path.join(OUTPUT_IMAGE_PATH, dir, "left"))
        os.makedirs(os.path.join(OUTPUT_IMAGE_PATH, dir, "right"))

    for root, dirs, files in os.walk(INPUT_VIDEO_PATH):
        for file in files:
            folder_name = root.split(os.sep)

            file_path = os.path.join(root, file)
            frame = cv2.imread(file_path)
            height, width = frame.shape[:2]
            frame_left = frame[:, :width // 2]
            frame_right = frame[:, width // 2:]

            frame_left_path = os.path.join(OUTPUT_IMAGE_PATH, folder_name[-1], "left", f"left_{file}")
            frame_right_path = os.path.join(OUTPUT_IMAGE_PATH, folder_name[-1], "right", f"right_{file}")

            cv2.imwrite(frame_left_path, frame_left)
            cv2.imwrite(frame_right_path, frame_right)


if __name__ == '__main__':
    INPUT_VIDEO_PATH = r"D:\zhangkun_20240407\all_dataset\camera_calibration\0426\collation"
    OUTPUT_IMAGE_PATH = r"D:\zhangkun_20240407\all_dataset\camera_calibration\0426\image_split"
    image_split()
