from PIL import Image, ImageDraw, ImageFont
from PIL.ExifTags import TAGS


# 读取图像的拍摄时间
def get_image_date_time(file_path):
    try:
        image = Image.open(file_path)
        exif_data = image._getexif()
        for tag, value in exif_data.items():
            tag_name = TAGS.get(tag, tag)
            if tag_name == 'DateTimeOriginal':
                return value
    except (AttributeError, KeyError, IndexError, IOError):
        pass
    return None


# 添加水印到图像
def add_watermark_to_image(file_path, watermark_text, output_path):
    image = Image.open(file_path)

    # 读取拍摄时间
    date_time = get_image_date_time(file_path)

    # 创建可绘制对象
    draw = ImageDraw.Draw(image)
    width, height = image.size

    # 设置水印字体和大小
    font = ImageFont.truetype("arial.ttf", 100)

    # 添加水印文本和拍摄时间
    draw.text((10, height - 500), watermark_text, fill=(255, 255, 255), font=font)
    if date_time:
        draw.text((10, height - 300), date_time, fill=(255, 255, 255), font=font)

    # 保存带水印的图像
    image.save(output_path)


if __name__ == '__main__':
    # 输入图像文件路径
    input_image_path = r"E:\个人\照片汇总_20220327整理\照片汇总_20230617整理\故乡\山\IMG_0360.JPG"
    input_image_path = r"E:\个人\照片汇总_20220327整理\万峰山20230314\03\IMG_20230314_184331.jpg"

    # 输出带水印的图像文件路径
    output_image_path = "output.png"

    # 要添加的水印文本
    watermark_text = "My Watermark"

    # 添加水印到图像
    add_watermark_to_image(input_image_path, watermark_text, output_image_path)

    print(f"水印已添加到 {output_image_path}")

    # get_image_date_time(r"E:\个人\照片汇总_20220327整理\万峰山20230314\03\IMG_20230314_184331.jpg")
