import numpy as np


def DIoU(box1, box2):
    # 计算两个边界框的交集的左上角和右下角坐标
    inter_x1 = np.maximum(box1[0], box2[0])
    inter_y1 = np.maximum(box1[1], box2[1])
    inter_x2 = np.minimum(box1[2], box2[2])
    inter_y2 = np.minimum(box1[3], box2[3])

    # 计算交集的面积
    inter_area = np.maximum(inter_x2 - inter_x1 + 1, 0) * np.maximum(inter_y2 - inter_y1 + 1, 0)

    # 计算两个边界框的面积
    area1 = (box1[2] - box1[0] + 1) * (box1[3] - box1[1] + 1)
    area2 = (box2[2] - box2[0] + 1) * (box2[3] - box2[1] + 1)

    # 计算并集的面积
    union_area = area1 + area2 - inter_area

    # 计算IoU
    iou = inter_area / union_area

    # 计算两个边界框的中心点距离的平方
    center_dist = np.power(box1[0] + box1[2] - box2[0] - box2[2], 2) + \
                  np.power(box1[1] + box1[3] - box2[1] - box2[3], 2)

    # 计算最小外接矩形的对角线的平方
    diag_dist = np.power(np.maximum(box1[2], box2[2]) - np.minimum(box1[0], box2[0]), 2) + \
                np.power(np.maximum(box1[3], box2[3]) - np.minimum(box1[1], box2[1]), 2)

    # 计算DIoU
    diou = iou - center_dist / diag_dist

    return diou


# 示例
box1 = np.array([50, 50, 150, 150], dtype=np.float32)
box2 = np.array([40, 50, 150, 150], dtype=np.float32)

diou_value = DIoU(box1, box2)
print("DIoU:", diou_value.item())
