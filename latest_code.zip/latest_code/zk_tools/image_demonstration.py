import math
import random

import cv2
import numpy as np


class ImageAugment:
    def rotate_image(self, image):
        rows, cols, _ = image.shape
        angle = random.randint(-20, 20)
        M = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle, 1)
        rotated_image = cv2.warpAffine(image, M, (cols, rows))
        return rotated_image

    def flip_image(self, image):
        return cv2.flip(image, 1)

    def scale_image(self, image, scale_factor):
        scale_factor = random.uniform(0.8, 1.2)
        rows, cols, _ = image.shape
        new_size = (int(cols * scale_factor), int(rows * scale_factor))
        scaled_image = cv2.resize(image, new_size)
        scaled_image = cv2.resize(scaled_image, (640, 640))
        return scaled_image

    def adjust_brightness_contrast(self, image):
        alpha = random.uniform(0.5, 1.5)
        beta = random.randint(10, 50)
        return cv2.convertScaleAbs(image, alpha=alpha, beta=beta)

    def color_distortion(self, image, color_matrix):
        return cv2.transform(image, color_matrix)

    def salt_and_pepper_noise(self, image, salt_prob=0.01, pepper_prob=0.01):
        noisy_image = image.copy()
        total_pixels = image.size
        num_salt = int(total_pixels * salt_prob)
        salt_coords = [np.random.randint(0, i - 1, num_salt) for i in image.shape]
        noisy_image[salt_coords[0], salt_coords[1]] = 255
        num_pepper = int(total_pixels * pepper_prob)
        pepper_coords = [np.random.randint(0, i - 1, num_pepper) for i in image.shape]
        noisy_image[pepper_coords[0], pepper_coords[1]] = 0
        return noisy_image

    def equalizeHist_image(self, image):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image = cv2.equalizeHist(image)
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        return image

    def clahe_image(self, image):
        b, g, r = cv2.split(image)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(5, 5))
        clahe_b = clahe.apply(b)
        clahe_g = clahe.apply(g)
        clahe_r = clahe.apply(r)
        return cv2.merge((clahe_b, clahe_g, clahe_r))

    def detailEnhance_image(self, image):
        return cv2.detailEnhance(image, None, 20, 0.8)

    def illumination_change(self, image):
        img_zero = np.zeros(image.shape, dtype=np.uint8)
        return cv2.illuminationChange(image, mask=img_zero, alpha=0.2, beta=0.4)

    def enhance_reduce(self, image, strength=100):
        # strength > 0 enhance, strength < 0 reduce
        x, y, _ = image.shape
        radius = np.random.randint(10, int(min(x, y)), 1)
        pos_x = np.random.randint(0, (min(x, y) - radius), 1)
        pos_y = np.random.randint(0, (min(x, y) - radius), 1)
        pos_x = int(pos_x[0])
        pos_y = int(pos_y[0])
        radius = int(radius[0])
        for j in range(pos_y - radius, pos_y + radius):
            for i in range(pos_x - radius, pos_x + radius):
                distance = math.pow((pos_x - i), 2) + math.pow((pos_y - j), 2)
                distance = np.sqrt(distance)
                if distance < radius:
                    result = 1 - distance / radius
                    result = result * strength
                    if strength > 0:
                        image[i, j, 0] = min((image[i, j, 0] + result), 255)
                        image[i, j, 1] = min((image[i, j, 1] + result), 255)
                        image[i, j, 2] = min((image[i, j, 2] + result), 255)
                    else:
                        image[i, j, 0] = max((image[i, j, 0] + result), 0)
                        image[i, j, 1] = max((image[i, j, 1] + result), 0)
                        image[i, j, 2] = max((image[i, j, 2] + result), 0)
        image = image.astype(np.uint8)
        return image

    def mask(self, image, low=10, high=50):
        x, y, _ = image.shape
        mask_size = np.random.randint(low, high, 1)
        pos_x = np.random.randint(low, (min(x, y) - high), 1)
        pos_y = np.random.randint(low, (min(x, y) - high), 1)
        pos_x = int(pos_x[0])
        pos_y = int(pos_y[0])
        mask_size = int(mask_size[0])
        image[pos_x:pos_x + mask_size, pos_y:pos_y + mask_size] = 0
        return image


if __name__ == '__main__':
    image = cv2.imread(r"C:\Users\zk\Desktop\TEMP\shot_20240123_145334.jpg")

    ia = ImageAugment()
    color_matrix = np.array([[0.393, 0.769, 0.189], [0.349, 0.686, 0.168], [0.272, 0.534, 0.131]])

    rotated_image = ia.rotate_image(image)
    flipped_image = ia.flip_image(image)
    scaled_image = ia.scale_image(image, scale_factor=1.2)
    adjusted_image = ia.adjust_brightness_contrast(image)
    color_distorted_image = ia.color_distortion(image, color_matrix)
    salt_image = ia.salt_and_pepper_noise(image)
    equalize_image = ia.equalizeHist_image(image)
    clahe_image = ia.clahe_image(image)
    detailenhance_image = ia.detailEnhance_image(image)
    illumination_image = ia.illumination_change(image)
    enhance_image = ia.enhance_reduce(image, 100)
    reduce_image = ia.enhance_reduce(image, -100)
    mask_image = ia.mask(image)

    cv2.imwrite(r"C:\Users\zk\Desktop\TEMP\out.jpg", equalize_image)

