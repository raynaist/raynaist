import numpy as np
import torch
from PIL import Image

output = torch.randn(1, 3, 256, 256)
output = output.squeeze(0)
output = (output - output.min()) / (output.max() - output.min())
output = np.uint8(output * 255)
output = Image.fromarray(output.transpose(1, 2, 0))
output.save('output_image.jpg')



