import os

import fitz  # PyMuPDF
from PIL import Image


def convert_pdf_to_images(pdf_path, output_folder):
    # 创建输出文件夹
    os.makedirs(output_folder, exist_ok=True)

    # 遍历文件夹中的PDF文件
    for pdf_file in os.listdir(pdf_path):
        if pdf_file.endswith(".pdf"):
            pdf_file_path = os.path.join(pdf_path, pdf_file)
            pdf_doc = fitz.open(pdf_file_path)

            # 遍历PDF的每一页
            for page_num in range(pdf_doc.page_count):
                page = pdf_doc[page_num]
                image = page.get_pixmap()

                # 将Pixmap对象转换为PIL Image对象
                img = Image.frombytes("RGB", [image.width, image.height], image.samples)

                # 生成图片文件名
                image_filename = f"{pdf_file}_page_{page_num + 1}.png"
                image_filepath = os.path.join(output_folder, image_filename)

                # 保存图片
                img.save(image_filepath)

            # 关闭当前PDF文档
            pdf_doc.close()


if __name__ == "__main__":
    # 指定PDF文件夹和输出文件夹

    pdf_folder_path = r"C:\Users\zk\Desktop\TEMP\tj"
    output_folder_path = r"C:\Users\zk\Desktop\TEMP\tjpdf"

    # 调用函数进行转换
    convert_pdf_to_images(pdf_folder_path, output_folder_path)
