import os
import shutil

source_folder = r"D:\Yang"
destination_folder = r"D:\zhangkun_20240407\all_dataset\yang"

# 获取源文件夹下的所有子文件夹
subfolders = [f for f in os.listdir(source_folder) if os.path.isdir(os.path.join(source_folder, f))]

# 遍历所有子文件夹
for subfolder in subfolders:
    if subfolder.startswith('VOC'):
        # 构建子文件夹的完整路径
        subfolder_path = os.path.join(source_folder, subfolder)
        print(subfolder_path)

        # 移动子文件夹到目标文件夹
        shutil.move(subfolder_path, destination_folder)
