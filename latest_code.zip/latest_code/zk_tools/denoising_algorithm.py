import cv2
import numpy as np
from matplotlib import pyplot as plt

# 读取图片
img = cv2.imread(r"G:\original_dataset\product_identify\product_video_20240125\train_data\goods_image\goods_18\salt_96.jpg")


noisy_img = img

# 定义各种去噪算法
methods = [
    ('Original', img),
    ('Gaussian Blur', cv2.GaussianBlur(noisy_img, (5, 5), 0)),
    ('Median Blur', cv2.medianBlur(noisy_img, 5)),
    ('Bilateral Filter', cv2.bilateralFilter(noisy_img, 9, 75, 75)),
    ('Non-Local Means', cv2.fastNlMeansDenoisingColored(noisy_img, None, 10, 10, 7, 21))
]

# 显示去噪效果
plt.figure(figsize=(12, 6))
for i, (name, method) in enumerate(methods):
    plt.subplot(2, 3, i + 1)
    plt.imshow(cv2.cvtColor(method, cv2.COLOR_BGR2RGB))
    plt.title(name)
    plt.axis('off')

plt.tight_layout()
plt.show()
