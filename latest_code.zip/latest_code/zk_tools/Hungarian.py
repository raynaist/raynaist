import numpy as np
from scipy.optimize import linear_sum_assignment

# 匈牙利匹配算法

# 两个矩阵，表示权重
# cost_matrix = np.array([
#     [20, 15, 18, 24, 25],
#     [18, 20, 12, 14, 15],
#     [21, 23, 25, 27, 26],
#     [17, 18, 21, 23, 22],
#     [19, 22, 16, 21, 20]
# ])


cost_matrix = np.array([
    [-20, -15, -18, -24, -25],
    [-18, -20, -12, -14, -15],
    [-21, -23, -25, -27, -26],
    [-17, -18, -21, -23, -22],
    [-19, -22, -16, -21, -20]
])

# 使用linear_sum_assignment函数找到最小权重的匹配
row_indices, col_indices = linear_sum_assignment(cost_matrix)

# 输出匹配结果
matches = list(zip(row_indices, col_indices))
total_cost = cost_matrix[row_indices, col_indices].sum()

print("最优匹配：", matches)
print("总成本：", total_cost)
