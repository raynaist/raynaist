import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont

image = Image.open(r"D:\zhangkun_20240407\zk_temp\19_168_456_232_572_1031_19_1062_1543_217_1905_143_1905_1055_1429_1047_2.jpg")
draw = ImageDraw.Draw(image)
font = ImageFont.truetype(r"D:\zhangkun_20240407\pycharm_code_20240407\zk_tools\data\simhei.ttf", size=72)
text = "你好，世界！"
text_position = (10, 10)
draw.text(text_position, text, font=font, fill=(255, 0, 0))
plt.imshow(image)
plt.show()
