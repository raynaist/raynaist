import random


def generate_random_hex_color():
    # 生成 RGB 随机值
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)

    # 将 RGB 转换为十六进制格式
    hex_color = "#{:02X}{:02X}{:02X}".format(r, g, b)

    return hex_color


for i in range(0, 10):
    # 生成随机颜色
    random_color = generate_random_hex_color()
    print(f"'{random_color}',")
