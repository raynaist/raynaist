from pypinyin import pinyin, Style


def hanzi_to_pinyin(input_str, abbreviation=False):
    """
    汉字转拼音
    :param input_str:
    :return:
    """
    # 调用 pinyin 方法将汉字转换为拼音，Style.NORMAL 表示不带声调
    pinyin_list = pinyin(input_str, style=Style.NORMAL)

    if abbreviation:
        head = pinyin_list[0][0]
        str = ""
        for py in pinyin_list[1:]:
            str = str + py[0][0]
        pinyin_str = f"{head}_{str}"

    else:
        # 将拼音列表连接成字符串
        pinyin_str = '_'.join([py[0] for py in pinyin_list])

    return pinyin_str


if __name__ == '__main__':

    for str in ["塑料水瓶",
                "废纸板",
                "易拉罐",
                "综合纸",
                "杂项纸",
                "非饮用塑料水瓶",
                "旧书报",
                "扎带",
                "袋装",
                "塑料水瓶扁",
                "废纸箱",
                "旧衣物",
                "易拉罐扁"]:
        pinyin_str = hanzi_to_pinyin(str, abbreviation=True)
        print(pinyin_str)
