import os
import random
import shutil
from shutil import rmtree

import cv2
from pypinyin import pinyin, Style

student_name = ["李沁洋", "姚广", "尹宏伟", "陈家骏", "赖星宇", "郑宇涵", "李俊华", "彭扬帆", "黄鹏宇",
                "文丽雪", "倪治强", "吴越", "吴明辉",
                "王照菊", "左秋香", "唐荣嘉", "刘洋鑫", "梁羽龙", "谢康",
                "刘建鹤", "刘载杨", "丁灏", "杨海斌", "程文东", "鄢飘", "朱玉洁", "张坤", "李怡杉"  # , "陈昊"
                ]


def hanzi_to_pinyin(input_str):
    """
    汉字转拼音
    :param input_str:
    :return:
    """
    # 调用 pinyin 方法将汉字转换为拼音，Style.NORMAL 表示不带声调
    pinyin_list = pinyin(input_str, style=Style.NORMAL)

    # 将拼音列表连接成字符串
    pinyin_str = '_'.join([py[0] for py in pinyin_list])

    return pinyin_str


def video_to_frame():
    # 文件夹重建
    if os.path.exists(OUTPUT_IMAGE_PATH):
        print("数据删除中……")
        rmtree(OUTPUT_IMAGE_PATH)
        print("数据已删除")
    os.makedirs(OUTPUT_IMAGE_PATH)

    for vid in os.listdir(INPUT_VIDEO_PATH):
        video_path = os.path.join(INPUT_VIDEO_PATH, vid)

        capture = cv2.VideoCapture(video_path)
        if not capture.isOpened():
            print("Error opening video file.")
            exit()

        n = 0
        m = 0
        while True:
            ret, frame = capture.read()
            if not ret:
                break

            if m % IMAGE_FRAME == 0:
                cv2.imwrite(os.path.join(OUTPUT_IMAGE_PATH, f"{os.path.splitext(vid)[0]}_frame_{n}.jpg"), frame)
                n = n + 1
            m = m + 1

        print("视频抽帧完成", vid)


def student_pinyin():
    """
    根据拼音新建文件夹
    :return:
    """
    if os.path.exists(STUDENT_PATH):
        print("数据删除中……")
        rmtree(STUDENT_PATH)
        print("数据已删除")
    os.makedirs(STUDENT_PATH)

    for st in student_name:
        pinyin_str = hanzi_to_pinyin(st)
        os.makedirs(os.path.join(STUDENT_PATH, pinyin_str))

    print("重建全部学生文件夹完成")


def data_partitioning():
    files = os.listdir(OUTPUT_IMAGE_PATH)
    students = os.listdir(STUDENT_PATH)
    random.shuffle(files)
    random.shuffle(students)

    DIVIDE_NUM = (len(files) // len(students))

    img_num = 1
    stu_idx = 0

    for file in files:
        shutil.move(os.path.join(OUTPUT_IMAGE_PATH, file),
                    os.path.join(STUDENT_PATH, students[stu_idx], file))

        if img_num % DIVIDE_NUM == 0:
            stu_idx = stu_idx + 1

        img_num = img_num + 1

        if stu_idx == len(students):
            break

    # 剩余照片分配
    remain_files = os.listdir(OUTPUT_IMAGE_PATH)
    if len(remain_files) > 0:
        random.shuffle(remain_files)
        random.shuffle(students)

        # 一张照片分配给一个人
        stu_idx = 0
        for remain_file in remain_files:
            shutil.move(os.path.join(OUTPUT_IMAGE_PATH, remain_file),
                        os.path.join(STUDENT_PATH, students[stu_idx], remain_file))
            stu_idx = stu_idx + 1


if __name__ == '__main__':
    INPUT_VIDEO_PATH = r"G:\original_dataset\product_identify\product_video_20240125\original_video_03\original_video"
    OUTPUT_IMAGE_PATH = r"G:\original_dataset\product_identify\product_video_20240125\frame"
    STUDENT_PATH = r"G:\original_dataset\product_identify\product_video_20240125\student"
    IMAGE_FRAME = 8  # 多少帧抽一张图片

    # 视频抽帧
    video_to_frame()

    # 重建学生文件夹
    student_pinyin()

    # 数据划分，重从视频帧文件夹中随机划分到学生文件夹
    data_partitioning()
