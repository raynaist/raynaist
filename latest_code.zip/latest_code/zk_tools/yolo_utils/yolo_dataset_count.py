import os
from collections import Counter

"""
读取yolo格式数据集，统计各个类别的数量
"""

if __name__ == '__main__':

    TXT_DATA_PATH = r"D:\zhangkun_20240407\all_dataset\yang\VOC0307\labels"
    CLASS_NAME = ["废纸箱", "废纸板", "旧书报", "杂项纸", "袋装", "扎带", "塑料水瓶", "塑料水瓶扁", "综合纸", "非饮用塑料水瓶", "易拉罐", "易拉罐扁", "旧衣物"]
    STATISTICAL_RESULTS = r"D:\zhangkun_20240407\pycharm_code_20240407\zk_tools\data\statistical_results.csv"

    all_class_dir = []
    for root, dirs, files in os.walk(TXT_DATA_PATH):
        for file in files:
            if file.endswith(".txt"):

                with open(os.path.join(root, file), "r") as f:
                    lines = f.readlines()

                    # Draw bounding boxes
                    for line in lines:
                        class_id, _, _, _, _ = map(float, line.strip().split())
                        all_class_dir.append(class_id)

    element_count = Counter(all_class_dir)
    sorted_counts = sorted(element_count.items(), key=lambda x: x[1], reverse=True)

    with open(STATISTICAL_RESULTS, 'w', encoding='utf-8') as f:
        for element in sorted_counts:
            c = CLASS_NAME[int(element[0])]  # 类别翻译
            strs = f"{c}, {element[1]}"
            f.writelines(strs)
            f.writelines("\n")
            f.flush()
        f.close()
