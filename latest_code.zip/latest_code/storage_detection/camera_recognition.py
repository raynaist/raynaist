import cv2

import config


def binocular_camera(camera_id):
    R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(config.LEFT_CAMERA_MATRIX[camera_id],
                                                                      config.LEFT_DISTORTION[camera_id],
                                                                      config.RIGHT_CAMERA_MATRIX[camera_id],
                                                                      config.RIGHT_DISTORTION[camera_id],
                                                                      config.IMAGE_SIZE,
                                                                      config.R[camera_id],
                                                                      config.T[camera_id])

    # 校正查找映射表,将原始图像和校正后的图像上的点一一对应起来
    left_map1, left_map2 = cv2.initUndistortRectifyMap(config.LEFT_CAMERA_MATRIX[camera_id], config.LEFT_DISTORTION[camera_id], R1, P1, config.IMAGE_SIZE, cv2.CV_16SC2)
    right_map1, right_map2 = cv2.initUndistortRectifyMap(config.RIGHT_CAMERA_MATRIX[camera_id], config.RIGHT_DISTORTION[camera_id], R2, P2, config.IMAGE_SIZE, cv2.CV_16SC2)

    capture = cv2.VideoCapture(camera_id)

    # 检查摄像头是否成功打开
    if not capture.isOpened():
        raise Exception("无法打开相机 camera_id", camera_id)

    # 设置分辨率
    capture.set(cv2.CAP_PROP_FRAME_WIDTH, config.IMAGE_SIZE[0] * 2)
    capture.set(cv2.CAP_PROP_FRAME_HEIGHT, config.IMAGE_SIZE[1])
    capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))

    while True:
        ret, frame = capture.read()
        if not ret:
            raise Exception("Error: Could not read frame.")

        height, width = frame.shape[:2]

        frame1 = frame[:, :width // 2]
        frame2 = frame[:, width // 2:]

        # 将BGR格式转换成灰度图片，用于畸变矫正
        imgL = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
        imgR = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)

        # 重映射，就是把一幅图像中某位置的像素放置到另一个图片指定位置的过程。
        # 依据MATLAB测量数据重建无畸变图片,输入图片要求为灰度图
        img1_rectified = cv2.remap(imgL, left_map1, left_map2, cv2.INTER_LINEAR)
        img2_rectified = cv2.remap(imgR, right_map1, right_map2, cv2.INTER_LINEAR)




        # ------------------------------------SGBM算法----------------------------------------------------------
        #   blockSize                   深度图成块，blocksize越低，其深度图就越零碎，0<blockSize<10
        #   img_channels                BGR图像的颜色通道，img_channels=3，不可更改
        #   numDisparities              SGBM感知的范围，越大生成的精度越好，速度越慢，需要被16整除，如numDisparities
        #                               取16、32、48、64等
        #   mode                        sgbm算法选择模式，以速度由快到慢为：STEREO_SGBM_MODE_SGBM_3WAY、
        #                               STEREO_SGBM_MODE_HH4、STEREO_SGBM_MODE_SGBM、STEREO_SGBM_MODE_HH。精度反之
        # ------------------------------------------------------------------------------------------------------

        blockSize = 5
        img_channels = 3


        stereo = cv2.StereoSGBM_create(minDisparity=1,
                                   numDisparities=64,
                                   blockSize=blockSize,
                                   P1=8 * img_channels * blockSize * blockSize,
                                   P2=32 * img_channels * blockSize * blockSize,
                                   disp12MaxDiff=5,
                                   preFilterCap=63,
                                   uniquenessRatio=10,
                                   speckleWindowSize=100,
                                   speckleRange=100,
                                   mode=cv2.STEREO_SGBM_MODE_HH)


        # 计算视差
        disparity = stereo.compute(img1_rectified, img2_rectified)

        # 归一化函数算法，生成深度图（灰度图）
        disp = cv2.normalize(disparity, disparity, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)

        # 生成深度图（颜色图）
        dis_color = cv2.normalize(disparity, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
        dis_color = cv2.applyColorMap(dis_color, 2)

        # 计算三维坐标数据值
        threeD = cv2.reprojectImageTo3D(disparity, Q, handleMissingValues=True)

        # 计算出的threeD，需要乘以16，才等于现实中的距离
        threeD = threeD * 16

        # cv2.imshow("left", frame1)
        # cv2.imshow("disp", disp)  # 显示深度图的双目画面
        cv2.imshow("depth", dis_color)
        cv2.imshow("threeD", threeD)

        if cv2.waitKey(1) & 0xFF == ord(' '):
            break

    # 关闭窗口和摄像头
    capture.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    binocular_camera(config.LEFT_STORAGE_CAMERA_ID)
    # binocular_camera(config.RIGHT_STORAGE_CAMERA_ID)
