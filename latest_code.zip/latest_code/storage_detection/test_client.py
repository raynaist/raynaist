import json
import time

import requests

Datajson = {"weight": "4000", "order_id": "7bfskch58796", "goods_name": '废纸箱', "fault_tolerant": False}
Datajson = json.dumps(Datajson, sort_keys=False, indent=4, separators=(',', ': '))

start_time = time.time()
r = requests.post("http://127.0.0.1:8026/model/StorageDetection", data=Datajson)

data = r.json()
print('time:', round((time.time() - start_time) * 1000, 2), "ms")
print(json.loads(r.text))
