import numpy as np
from PyCameraList.camera_device import list_video_devices

# ___________________________ 双目摄像头参数设置 ___________________________

# TODO 此参数需要每个双目摄像头单独标定

# ____________ 左边仓位摄像头 ____________


# 左镜头的内参，如焦距
LEFT_CAMERA_MATRIX_0 = np.array([[294.3999904, 0.739701053, 322.4275636],
                                 [0., 295.6549146, 267.6047405],
                                 [0., 0., 1.]])

RIGHT_CAMERA_MATRIX_0 = np.array([[295.3307747, 1.622280543, 326.0482724],
                                  [0., 295.9902834, 256.8281324],
                                  [0., 0., 1.]])

# 畸变系数，K1、K2、K3为径向畸变，P1、P2为切向畸变
LEFT_DISTORTION_0 = np.array([[0.004341537, -0.014640185, -0.003258972, -0.0000247645997637284, -0.000348777]])

RIGHT_DISTORTION_0 = np.array([[0.00861578868694360, -0.0165435773807064, -0.00236649152997750, -0.000257158, 0.000759409]])

# 旋转矩阵
R_0 = np.array([[0.999930639, -0.000633442, -0.011760749],
                [0.000745354, 0.999954466, 0.009513738],
                [0.011754187, -0.009521844, 0.99988558]])
# 平移矩阵
T_0 = np.array([-65.21291777, 2.211251894, -0.141967904])

# ____________ 右边仓位摄像头 ____________


# 左镜头的内参，如焦距
LEFT_CAMERA_MATRIX_1 = np.array([[294.3999904, 0.739701053, 322.4275636],
                                 [0., 295.6549146, 267.6047405],
                                 [0., 0., 1.]])

RIGHT_CAMERA_MATRIX_1 = np.array([[295.3307747, 1.622280543, 326.0482724],
                                  [0., 295.9902834, 256.8281324],
                                  [0., 0., 1.]])

# 畸变系数，K1、K2、K3为径向畸变，P1、P2为切向畸变
LEFT_DISTORTION_1 = np.array([[0.004341537, -0.014640185, -0.003258972, -0.0000247645997637284, -0.000348777]])

RIGHT_DISTORTION_1 = np.array([[0.00861578868694360, -0.0165435773807064, -0.00236649152997750, -0.000257158, 0.000759409]])

# 旋转矩阵
R_1 = np.array([[0.999930639, -0.000633442, -0.011760749],
                [0.000745354, 0.999954466, 0.009513738],
                [0.011754187, -0.009521844, 0.99988558]])
# 平移矩阵
T_1 = np.array([-65.21291777, 2.211251894, -0.141967904])

# ____________ 摄像头参数汇总 ____________
LEFT_CAMERA_MATRIX = [LEFT_CAMERA_MATRIX_0, LEFT_CAMERA_MATRIX_1]
RIGHT_CAMERA_MATRIX = [RIGHT_CAMERA_MATRIX_0, RIGHT_CAMERA_MATRIX_1]
LEFT_DISTORTION = [LEFT_DISTORTION_0, LEFT_DISTORTION_1]
RIGHT_DISTORTION = [RIGHT_DISTORTION_0, RIGHT_DISTORTION_1]
R = [R_0, R_1]
T = [T_0, T_1]

# 相机设备名称
CAMERA_DEVICE_NAME = "WN CAMERA1080 TB"

cameras_list = list_video_devices()
CAMERA_DEVICE_ID = [key for key, value in dict(cameras_list).items() if value == CAMERA_DEVICE_NAME]

# 左右相机设备 ID
LEFT_STORAGE_CAMERA_ID = CAMERA_DEVICE_ID[0]
RIGHT_STORAGE_CAMERA_ID = CAMERA_DEVICE_ID[1]

# 图片宽高
IMAGE_SIZE = (640, 480)
