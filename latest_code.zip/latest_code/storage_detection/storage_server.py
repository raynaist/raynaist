import logging
import os
import time

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from camera_recognition import binocular_camera

app = FastAPI()


def output_log():
    """
    自动生成日志文件
    :return:
    """

    prj_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
    log_path = os.path.join(prj_path, 'log')
    log_date_path = os.path.join(log_path, time.strftime('%Y_%m_%d', time.localtime(time.time())))

    if not os.path.exists(log_date_path):
        os.makedirs(log_date_path)

    try:

        log1 = logging.getLogger()
        log1.setLevel(logging.DEBUG)

        # 创建一个handler，用于写入日志文件
        current_time = time.strftime('%Y_%m_%d_%H_%M', time.localtime(time.time()))  # 返回当前时间
        log_name = os.path.join(log_date_path, current_time + '.log')

        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.INFO)

        # 定义handler的输出格式
        formatter = logging.Formatter('[%(asctime)s] - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        # 给logger添加handler
        log1.addHandler(fh)
    except Exception as e:
        pass


# 定义路由
@app.route("/model/StorageDetection", methods=['POST', 'GET'])
async def get_frame(request: Request):
    output_log()

    # 解析接收json
    data_json = await request.json()

    # 将收到的消息记录在log中
    logging.info(f"接收到新请求：{data_json}")

    # 接受到的参数
    weight = data_json['weight']
    orderID = data_json['order_id']
    goods_name = data_json['goods_name']
    fault_tolerant = data_json['fault_tolerant']

    # 定义返回json
    resultdata = {"droppointx": None, "droppointy": None, "lift": None}


    binocular_camera()

    results = {"code": 200, "msg": "OK", "Data": resultdata}

    logging.info(f"返回结果如下:{results}")

    return JSONResponse(content=results)


def app_run():
    """
    启动服务
    """
    print('开始启动接口')
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8026)


if __name__ == "__main__":
    app_run()
