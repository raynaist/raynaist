import cv2

# 读取图像
image = cv2.imread(r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\product1\20240223_105733_983151_OK.bmp")

# 转换为灰度图像
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

retval, thresh = cv2.threshold(gray, 122, 255, type=cv2.THRESH_BINARY_INV)
gray_blur = cv2.medianBlur(thresh, 5)
edges = cv2.Canny(gray_blur, 50, 150)

# cv2.imshow('Circles', edges)
# cv2.waitKey(0)


# 查找轮廓
contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# 遍历轮廓并拟合椭圆
for contour in contours:
    if len(contour) >= 30:
        ellipse = cv2.fitEllipse(contour)
        cv2.ellipse(image, ellipse, (0, 255, 0), 2)

# 显示结果
cv2.imshow('Ellipses', image)
cv2.waitKey(0)
cv2.destroyAllWindows()
