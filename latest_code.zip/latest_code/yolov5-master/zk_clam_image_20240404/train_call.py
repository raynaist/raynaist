import os
import subprocess

if __name__ == '__main__':
    # ___________ 模型参数设置 ___________
    py = r"D:\PycharmProjects\yolov5-master\train.py"
    epochs = 1000
    cfg = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\yolov5n.yaml"
    data = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\pearl.yaml"
    project = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\runs\train"

    # '--exist-ok', action = 'store_true'  这是开关参数，传参为 True，否则默认为False
    call_command = f"python {py} --data {data} --epochs {epochs} --cfg {cfg} --project {project} --exist-ok --single-cls"
    print("\n\n", call_command)

    process = subprocess.Popen(call_command, shell=True)
    process.wait()
