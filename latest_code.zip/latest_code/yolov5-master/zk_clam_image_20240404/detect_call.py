import os
import subprocess

if __name__ == '__main__':
    # ___________ 模型参数设置 ___________
    py = r"D:\PycharmProjects\yolov5-master\detect.py"
    weights = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\runs\train\exp\weights\best.pt"
    source = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\product1_enhancement"
    data = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\pearl.yaml"
    project = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\runs\detect"

    call_command = f"python {py} --data {data} --project {project} --weights {weights} --source {source} --conf-thres {0.5} --exist-ok"
    print("\n\n", call_command)

    process = subprocess.Popen(call_command, shell=True)
    process.wait()
