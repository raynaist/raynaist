import os
import time
from shutil import rmtree

import cv2
import numpy as np


def diou(box1, box2):
    # 计算两个边界框的中心点坐标
    x1_center, y1_center = (box1[0] + box1[2]) / 2, (box1[1] + box1[3]) / 2
    x2_center, y2_center = (box2[0] + box2[2]) / 2, (box2[1] + box2[3]) / 2

    # 计算两个边界框的面积
    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])

    # 计算两个边界框的交集部分
    inter_area = max(0, min(box1[2], box2[2]) - max(box1[0], box2[0])) * \
                 max(0, min(box1[3], box2[3]) - max(box1[1], box2[1]))

    # 计算两个边界框的最小闭包框
    enclose_box_left = min(box1[0], box2[0])
    enclose_box_top = min(box1[1], box2[1])
    enclose_box_right = max(box1[2], box2[2])
    enclose_box_bottom = max(box1[3], box2[3])

    # 计算最小闭包框的对角线距离
    c = (x2_center - x1_center) ** 2 + (y2_center - y1_center) ** 2
    d = (enclose_box_right - enclose_box_left) ** 2 + (enclose_box_bottom - enclose_box_top) ** 2

    # 计算Diou
    iou = inter_area / (box1_area + box2_area - inter_area)
    r_diou = iou - c / d

    return r_diou


def nms(boxes, scores, threshold):
    order = np.argsort(scores)[::-1]

    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        n_diou = np.array([diou(boxes[i, :], boxes[j, :]) for j in order[1:]])
        inds = np.where(n_diou <= threshold)[0]
        order = order[inds + 1]

    return keep


def template_matching_multi(image_path, template_paths, threshold, nms_threshold):
    """
    多目标模板匹配并去重
    :param image_path: 目标图像路径
    :param template_paths: 模板图像路径列表
    :param threshold: 模板匹配阈值
    :param nms_threshold: 非极大值抑制的阈值
    """
    # 读取目标图像
    target_img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    all_detections = []

    for template_path in template_paths:
        # 读取模板图像
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        h, w = template.shape

        # 执行模板匹配
        res = cv2.matchTemplate(target_img, template, cv2.TM_CCOEFF_NORMED)
        loc = np.where(res >= threshold)

        is_empty = all(len(arr) == 0 for arr in loc)

        if is_empty:
            break

        # 提取边界框坐标和得分
        detections = []
        for pt in zip(*loc[::-1]):
            detections.append([pt[0], pt[1], pt[0] + w, pt[1] + h, res[pt[1], pt[0]]])
        detections = np.array(detections)

        # 应用NMS和IOU去除重复框
        keep = nms(detections[:, :4], detections[:, 4], nms_threshold)
        detections = detections[keep]

        all_detections.extend(detections.tolist())

    # 在目标图像上绘制边界框
    target_img = cv2.cvtColor(target_img, cv2.COLOR_GRAY2RGB)

    for detection in all_detections:
        cv2.rectangle(target_img, (int(detection[0]), int(detection[1])), (int(detection[2]), int(detection[3])), (0, 0, 255), 1)

    _basename = os.path.basename(image_path)

    save_file_name = os.path.join(result_matchTemplate, _basename)
    cv2.imwrite(save_file_name, target_img)

    # # 显示结果
    # cv2.imshow('Result', target_img)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()


if __name__ == '__main__':
    # 示例用法
    image_path = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\product1"
    result_matchTemplate = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\result_matchTemplate"

    template_paths = [
        r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\circular_template.bmp",
        # r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\elliptical_template.bmp"
    ]
    threshold = 0.7
    nms_threshold = 0.1

    # 初始化，重建文件夹
    if os.path.exists(result_matchTemplate):
        print("数据删除中……", result_matchTemplate)
        rmtree(result_matchTemplate)
        print("数据已删除", result_matchTemplate)
    os.makedirs(result_matchTemplate)

    all_time = 0

    for root, dirs, files in os.walk(image_path):
        for file in files:
            _image_path = os.path.join(root, file)
            start_time = time.time()

            template_matching_multi(_image_path, template_paths, threshold, nms_threshold)

            end_time = time.time()
            elapsed_time = end_time - start_time

            all_time = all_time + elapsed_time

            # print(round(elapsed_time * 1000, 2), "ms")

    avg_time = all_time / len(os.listdir(image_path))
    print("avg_time", round(avg_time * 1000, 2), "ms")
