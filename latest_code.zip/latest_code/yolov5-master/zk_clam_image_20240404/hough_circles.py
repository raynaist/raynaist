import os
import time
from shutil import rmtree

import cv2
import numpy as np


def find_circles(_image_path):
    image = cv2.imread(_image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    retval, dst = cv2.threshold(gray, 122, 255, type=cv2.THRESH_BINARY_INV)

    # cv2.imshow('Circles', dst)
    # cv2.waitKey(0)

    # 中值模糊
    gray_blur = cv2.medianBlur(dst, 5)
    edges = cv2.Canny(gray_blur, 50, 150)

    # cv2.imshow('Circles', edges)
    # cv2.waitKey(0)

    # 检测圆
    circles = cv2.HoughCircles(edges, cv2.HOUGH_GRADIENT, dp=1, minDist=20, param1=50, param2=15, minRadius=0, maxRadius=20)
    # circles = cv2.HoughCircles(gray_blur, cv2.HOUGH_GRADIENT, dp=1, minDist=20, param1=50, param2=20, minRadius=0, maxRadius=20)


    if circles is not None:
        circles = np.uint16(np.around(circles))
        for i in circles[0, :]:
            # 绘制检测到的圆
            cv2.circle(image, (i[0], i[1]), i[2], (0, 255, 0), 1)

    _basename = os.path.basename(_image_path)

    save_file_name = os.path.join(result_HoughCircles, _basename)
    cv2.imwrite(save_file_name, image)

    # # 显示结果
    # cv2.imshow('Circles', image)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()


if __name__ == '__main__':

    image_path = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\product1"
    result_HoughCircles = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\result_HoughCircles"

    # 初始化，重建文件夹
    if os.path.exists(result_HoughCircles):
        print("数据删除中……", result_HoughCircles)
        rmtree(result_HoughCircles)
        print("数据已删除", result_HoughCircles)
    os.makedirs(result_HoughCircles)

    all_time = 0

    for root, dirs, files in os.walk(image_path):
        for file in files:
            _image_path = os.path.join(root, file)
            start_time = time.time()

            find_circles(_image_path)

            # find_circles(r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\product1\20240223_105725_571020_OK.bmp")
            # break

            end_time = time.time()
            elapsed_time = end_time - start_time

            all_time = all_time + elapsed_time

    avg_time = all_time / len(os.listdir(image_path))
    print("avg_time", round(avg_time * 1000, 2), "ms")
