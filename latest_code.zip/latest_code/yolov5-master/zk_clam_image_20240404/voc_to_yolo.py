import glob
import os
import random
import shutil
import xml.etree.ElementTree as ET
from collections import Counter
from shutil import rmtree

import cv2
from PIL import Image

'''
简化版，没有划分测试、验证集
2024年4月6日09:53:42
'''


def load_xml(xml_path, img_path):
    """
    解析 VOC XML文件
    :param img_path: 原始图片路径
    :param xml_path: xml文件目录
    :return: object_box按一行一个文件返回原始标签框信息  class_dir数据集中的全部不重复的类别
    """
    object_box = []
    class_dir = set()
    all_class_dir = []

    # 读取目录下全部 xml 文件
    for xml_file in glob.glob("{}/*xml".format(xml_path)):
        tree = ET.parse(xml_file)

        file_name = tree.findtext("filename")
        file_name = os.path.join(img_path, file_name)

        class_str = ""
        for obj in tree.iter("object"):
            class_name = obj.findtext("name")

            # 判断是否为指定类别
            if len(TARGET_CATEGORY) > 0:
                if class_name not in TARGET_CATEGORY:
                    print("file_name", file_name, "class_name", class_name)
                    continue

            xmin = str(int(float(obj.findtext("bndbox/xmin"))))
            ymin = str(int(float(obj.findtext("bndbox/ymin"))))
            xmax = str(int(float(obj.findtext("bndbox/xmax"))))
            ymax = str(int(float(obj.findtext("bndbox/ymax"))))

            class_str = f" {class_str} {class_name} {xmin} {ymin} {xmax} {ymax} "
            class_dir.add(class_name)
            all_class_dir.append(class_name)

        object_str = f"{file_name} {class_str}"
        object_box.append(object_str)

    return object_box, class_dir, all_class_dir


def get_key_by_value(dict, value):
    return [key for key, val in dict.items() if val == value][0]


def convert_box(size, box):
    """
    将标注框的原始坐标转换为中心点宽高，相对于原始图片的宽高百分比
    :param size: 原始图片宽高
    :param box: 标注框 x1 x2 y1 y2
    :return: cx, cy, w, h，相对于原始图片的宽高百分比
    """

    dw = 1. / (size[0])
    dh = 1. / (size[1])
    cx = (box[0] + box[1]) / 2.0 - 1  # TODO -1 ?  2023年10月14日16:30:53
    cy = (box[2] + box[3]) / 2.0 - 1
    w = box[1] - box[0]
    h = box[3] - box[2]
    cx = cx * dw
    w = w * dw
    cy = cy * dh
    h = h * dh
    cx = round(cx, 6)
    w = round(w, 6)
    cy = round(cy, 6)
    h = round(h, 6)
    return cx, cy, w, h


def save_category(class_dir, class_name_path):
    """
    保存类别，并编号，onehot编码使用
    :param class_name_path: 保存路径
    :param class_dir: 全部类别字典
    :return: category_num类别键值对
    """

    c = 0
    category_num = {}

    with open(class_name_path, 'w', encoding="utf-8") as f:
        # sorted(class_dir) 需要将数据排序，否则可能onehot编码类别对应错误
        for ct in sorted(class_dir):
            # 类别保存为txt
            f.writelines(f"  {c}: {ct}")
            f.writelines("\n")
            f.flush()

            category_num[c] = ct
            c = c + 1
    f.close()

    return category_num


def save_labels(out_labels_path, file_name, boxes):
    """
    保存图片标注框txt，一张图片一个txt
    :param out_labels_path: labels txt保存路径
    :param file_name: txt文件名称
    :param boxes: onehot类别，cx, cy, w, h，相对于原始图片的宽高百分比
    """

    label_txt_name = os.path.join(out_labels_path, f"{file_name}.txt")
    with open(label_txt_name, 'w', encoding='utf-8') as f:
        for strs in boxes:
            f.writelines([(str(x) + " ") for x in strs])
            f.writelines("\n")
            f.flush()
    f.close()


def save_data_partition_txt(txt_file_path, file_array):
    """
    保存数据划分txt， train.txt val.txt test.txt
    :param txt_file_path: txt保存路径
    :param file_array: 数据划分结果数组
    """
    with open(txt_file_path, 'w', encoding='utf-8') as f:
        for strs in file_array:
            f.writelines(strs)
            f.writelines("\n")
            f.flush()
    f.close()


def save_class_count(all_class_dir):
    """
    保存类别统计数据为 CSV
    :param all_class_dir: 没有去重的全部类别数据
    """

    # 使用Counter统计元素出现的次数
    element_count = Counter(all_class_dir)
    sorted_counts = sorted(element_count.items(), key=lambda x: x[1], reverse=True)

    with open(CLASS_COUNT_PATH, 'w', encoding='utf-8') as f:
        for element in sorted_counts:
            strs = f"{element[0]}, {element[1]}"
            f.writelines(strs)
            f.writelines("\n")
            f.flush()
        f.close()


def data_partition():
    """
    数据划分按照设置比例划分为 train val test
    """
    train_file = []
    val_file = []
    test_file = []

    total_file_num = len(os.listdir(OUT_IMAGES_PATH))
    # val_num = int(total_file_num * VAL_PERCENT)
    # test_num = int(total_file_num * (VAL_PERCENT + TEST_PERCENT))

    k = 0
    for root, dirs, files in os.walk(OUT_IMAGES_PATH):
        random.shuffle(files)
        for file in files:
            file_name = os.path.join(root, file)

            # # 放入val
            # if k < val_num:
            #     val_file.append(file_name)
            #
            # # 放入test
            # elif k < test_num:
            #     test_file.append(file_name)
            #
            # # 放入train
            # else:
            train_file.append(file_name)

            k = k + 1

    # ___________ 保存txt ___________

    # test_file
    # save_data_partition_txt(OUT_TEST_TXT_PATH, test_file)

    # val_file
    # save_data_partition_txt(OUT_VAL_TXT_PATH, val_file)

    # train_file
    save_data_partition_txt(OUT_TRAIN_TXT_PATH, train_file)


def data_processing():
    """
    数据处理调用函数
    """

    # ___________ 文件夹初始化 ___________
    if os.path.exists(OUT_PATH):
        print("数据删除中……")
        rmtree(OUT_PATH)
        print("数据已删除")
    os.makedirs(OUT_PATH)
    os.makedirs(OUT_LABELS_PATH)
    os.makedirs(OUT_IMAGES_PATH)

    # ___________ 加载xml循环处理图片，根据xml读取图片 ___________

    object_box, class_dir, all_class_dir = load_xml(ANNOTATIONS_PATH, ORIGINAL_IMG_PATH)
    category_num = save_category(class_dir, OUT_CLASS_NAME_PATH)  # 保存类别

    # 保存类别统计数据为 CSV
    save_class_count(all_class_dir)

    for obj_str in object_box:
        try:

            obj_array = obj_str.split()

            file_name = obj_array[0]
            new_file_name = os.path.join(OUT_IMAGES_PATH, file_name.split(os.sep)[-1])

            # 标签框处理
            box_str = obj_array[1:]
            box_array = [box_str[i:i + 5] for i in range(0, len(box_str), 5)]
            img = Image.open(file_name)

            _convert_box = []
            for box in box_array:
                class_name = box[0]
                xmin = float(box[1])
                ymin = float(box[2])
                xmax = float(box[3])
                ymax = float(box[4])

                class_name_one_hot = get_key_by_value(category_num, class_name)
                cx, cy, w, h = convert_box(img.size, [xmin, xmax, ymin, ymax])
                _convert_box.append((class_name_one_hot, cx, cy, w, h))

            # 将原始图片原封不动复制到新目录下
            shutil.copy2(file_name, new_file_name)

            # 保存labels
            real_file_name = file_name.split(os.sep)[-1]
            real_file_name = real_file_name.split(".")[0]  # 不要文件扩展名
            save_labels(OUT_LABELS_PATH, real_file_name, _convert_box)

        except FileNotFoundError as e:
            print(e)
            continue

    # ___________ 数据划分 ___________
    data_partition()


def image_enhancement(file_name, tile_grid_size=(3, 3)):
    """
    调用cv2对图片使用自适应直方图均衡化，并保存到新路径下
    :param tile_grid_size: 网格大小，默认(3, 3)
    :param file_name: 原始图片路径
    :param new_file_name: 新图片路径
    :return:
    """
    cv_img = cv2.imread(file_name, cv2.IMREAD_GRAYSCALE)  # 灰度图读取
    clahe = cv2.createCLAHE(tileGridSize=tile_grid_size)  # 自适应直方图均衡化
    clahe_img = clahe.apply(cv_img)
    # cv2.imwrite(new_file_name, clahe_img)  # 保存到新路径下
    return clahe_img


def image_processing():
    # ___________ 文件夹初始化 ___________
    if os.path.exists(IMAGE_ENHANCEMENT_PATH):
        print("数据删除中……", IMAGE_ENHANCEMENT_PATH)
        rmtree(IMAGE_ENHANCEMENT_PATH)
        print("数据已删除", IMAGE_ENHANCEMENT_PATH)
    os.makedirs(IMAGE_ENHANCEMENT_PATH)

    for root, dirs, files in os.walk(ORIGINAL_IMG_PATH):
        for file in files:
            _image_path = os.path.join(root, file)
            clahe_img = image_enhancement(_image_path)

            retval, dst = cv2.threshold(clahe_img, 80, 255, type=cv2.THRESH_BINARY_INV)

            # cv2.imshow('Circles', dst)
            # cv2.waitKey(0)

            # 中值模糊
            gray_blur = cv2.medianBlur(dst, 5)
            # edges = cv2.Canny(gray_blur, 50, 150)

            # cv2.imshow('Circles', gray_blur)
            # cv2.waitKey(0)

            new_file_name = os.path.join(IMAGE_ENHANCEMENT_PATH, file)

            cv2.imwrite(new_file_name, gray_blur)


if __name__ == '__main__':
    # ___________ 参数定义 ___________

    ANNOTATIONS_PATH = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\outputs"  # 原始标注XML路径
    ORIGINAL_IMG_PATH = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\product1"  # 原始图片路径

    IMAGE_ENHANCEMENT_PATH = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\product1_enhancement"

    # 数据输出文件夹总路径
    OUT_PATH = r"D:\PycharmProjects\yolov5-master\zk_clam_image_20240404\images\yolo"

    # 不指定类别写为空 TARGET_CATEGORY = []
    TARGET_CATEGORY = []
    # TARGET_CATEGORY = ["down", "person"]

    OUT_LABELS_PATH = os.path.join(OUT_PATH, "labels")
    OUT_IMAGES_PATH = os.path.join(OUT_PATH, "images")
    # OUT_TEST_TXT_PATH = os.path.join(OUT_PATH, "test.txt")
    OUT_TRAIN_TXT_PATH = os.path.join(OUT_PATH, "train.txt")
    # OUT_VAL_TXT_PATH = os.path.join(OUT_PATH, "val.txt")
    OUT_CLASS_NAME_PATH = os.path.join(OUT_PATH, "class_name.txt")
    CLASS_COUNT_PATH = os.path.join(OUT_PATH, "class_count.csv")

    # VAL TEST 占总数据的百分比
    # train = 1 - VAL_PERCENT - TEST_PERCENT
    # VAL_PERCENT = 0.10
    # TEST_PERCENT = 0.05

    # # ___________ 数据处理 ___________
    # data_processing()

    # ___________ 图片单独数据增强 ___________
    image_processing()
