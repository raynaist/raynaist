import glob
import math
import os
import random
import shutil
import xml.etree.ElementTree as ET
from collections import Counter

import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from PIL import ImageDraw, ImageFont
from pypinyin import pinyin, Style
from tqdm import tqdm


def hanzi_to_pinyin(input_str):
    """
    汉字转拼音
    :param input_str:
    :return:
    """
    # 调用 pinyin 方法将汉字转换为拼音，Style.NORMAL 表示不带声调
    pinyin_list = pinyin(input_str, style=Style.NORMAL)

    # 将拼音列表连接成字符串
    pinyin_str = '_'.join([py[0] for py in pinyin_list])

    return pinyin_str


def draw_voc_by_xml():
    # # Path to labels and images folders
    # labels_folder = r"D:\zhangkun_20240407\all_dataset\yang\VOC0307\labels\train"
    # images_folder = r"D:\zhangkun_20240407\all_dataset\yang\VOC0307\images\train"

    # List all image files
    image_files_xml = os.listdir(ANNOTATIONS_PATH)

    # Randomly select 20 images
    # random_images_xml = random.sample(image_files_xml, TEST_NUM)
    random_images_xml = image_files_xml

    font = ImageFont.truetype("arial.ttf", 32)

    draw_img_count = 0

    random.shuffle(random_images_xml)

    # Loop through selected images
    for image_xml in random_images_xml:
        parser = ET.XMLParser(encoding="utf-8")
        tree = ET.parse(os.path.join(ANNOTATIONS_PATH, image_xml), parser=parser)

        file_name = tree.findtext("filename")
        draw_name = file_name
        file_name = os.path.join(ORIGINAL_IMG_PATH, file_name)

        image = Image.open(file_name)
        draw = ImageDraw.Draw(image)

        draw_box_count = 0
        for obj in tree.iter("object"):
            class_name = obj.findtext("name")

            # 判断是否为指定类别
            if len(DRAW_CATEGORY) > 0:
                if class_name not in DRAW_CATEGORY:
                    continue

            class_name = hanzi_to_pinyin(class_name)

            xmin = int(float(obj.findtext("bndbox/xmin")))
            ymin = int(float(obj.findtext("bndbox/ymin")))
            xmax = int(float(obj.findtext("bndbox/xmax")))
            ymax = int(float(obj.findtext("bndbox/ymax")))

            draw.rectangle([xmin, ymin, xmax, ymax], outline="red", width=2)
            if DRAW_FILE_NAME == True:
                draw.text((xmin, ymin), (f"{class_name} {draw_name}"), fill="red", font=font)
            else:
                draw.text((xmin, ymin), (f"{class_name}"), fill="red", font=font)

            draw_box_count = draw_box_count + 1

        if draw_box_count > 0:
            # Display image
            plt.imshow(image)
            plt.show()

            draw_img_count = draw_img_count + 1

        if draw_img_count > TEST_NUM:
            break


def draw_yolo_by_img():
    # Path to labels and images folders
    labels_folder = OUT_LABELS_PATH
    images_folder = OUT_IMAGES_PATH

    # List all image files
    image_files = [f for f in os.listdir(images_folder) if os.path.isfile(os.path.join(images_folder, f))]

    # Randomly select 20 images
    if len(image_files) > TEST_NUM:
        random_images = random.sample(image_files, TEST_NUM)
    else:
        random_images = image_files

    font = ImageFont.truetype("arial.ttf", 32)

    random.shuffle(random_images)

    # Loop through selected images
    for image_name in random_images:
        # Load image
        image_path = os.path.join(images_folder, image_name)
        image = Image.open(image_path)
        draw = ImageDraw.Draw(image)

        # Load corresponding label file
        label_name = os.path.splitext(image_name)[0] + ".txt"
        label_path = os.path.join(labels_folder, label_name)

        # Read label file
        with open(label_path, "r") as f:
            lines = f.readlines()

        # Draw bounding boxes
        for line in lines:
            class_id, center_x, center_y, width, height = map(float, line.strip().split())
            w, h = image.size
            x1 = (center_x - width / 2) * w
            y1 = (center_y - height / 2) * h
            x2 = (center_x + width / 2) * w
            y2 = (center_y + height / 2) * h
            draw.rectangle([x1, y1, x2, y2], outline="red", width=2)

            if DRAW_FILE_NAME == True:
                draw.text((x1, y1), str(f"{int(class_id)}_{image_name}"), fill="red", font=font)
            else:
                draw.text((x1, y1), str(f"{int(class_id)}"), fill="red", font=font)

        # Display image
        # image.show()
        plt.imshow(image)
        plt.show()


def load_xml(xml_path, img_path):
    """
    解析 VOC XML文件
    :param img_path: 原始图片路径
    :param xml_path: xml文件目录
    :return: object_box按一行一个文件返回原始标签框信息  class_dir数据集中的全部不重复的类别
    """
    object_box = []
    class_dir = set()
    all_class_dir = []

    # 读取目录下全部 xml 文件
    for xml_file in glob.glob("{}/*xml".format(xml_path)):
        tree = ET.parse(xml_file)

        file_name = tree.findtext("filename")

        file_name = os.path.join(img_path, file_name)

        class_str = ""

        # 判断拉框了没有保存的情况
        first_object_element = next(tree.iter("object"), None)  # 尝试从迭代器中获取下一个元素，如果没有元素，则返回None
        if first_object_element is None:
            _path = tree.findtext("path")
            print("object 为空", file_name, _path)
            continue

        for obj in tree.iter("object"):
            class_name = obj.findtext("name")

            # 判断是否为指定类别
            if len(TARGET_CATEGORY) > 0:
                if class_name not in TARGET_CATEGORY:
                    print("file_name", file_name, "class_name", class_name)
                    continue

            # try:

            xmin = str(int(float(obj.findtext("bndbox/xmin"))))
            ymin = str(int(float(obj.findtext("bndbox/ymin"))))
            xmax = str(int(float(obj.findtext("bndbox/xmax"))))
            ymax = str(int(float(obj.findtext("bndbox/ymax"))))

            # except Exception as e:
            #     print(e)

            class_str = f" {class_str} {class_name} {xmin} {ymin} {xmax} {ymax} "
            class_dir.add(class_name)
            all_class_dir.append(class_name)

        # 图片完全没有指定目标类型，则不加入object_box，解决加入空的问题
        if len(class_str.strip()) > 0:
            object_str = f"{file_name} {class_str}"
            object_box.append(object_str)

    return object_box, class_dir, all_class_dir


def get_key_by_value(dict, value):
    return [key for key, val in dict.items() if val == value][0]


def convert_box(size, box):
    """
    将标注框的原始坐标转换为中心点宽高，相对于原始图片的宽高百分比
    :param size: 原始图片宽高
    :param box: 标注框 x1 x2 y1 y2
    :return: cx, cy, w, h，相对于原始图片的宽高百分比
    """

    dw = 1. / (size[0])
    dh = 1. / (size[1])
    cx = (box[0] + box[1]) / 2.0 - 1
    cy = (box[2] + box[3]) / 2.0 - 1
    w = box[1] - box[0]
    h = box[3] - box[2]
    cx = cx * dw
    w = w * dw
    cy = cy * dh
    h = h * dh
    cx = round(cx, 6)
    w = round(w, 6)
    cy = round(cy, 6)
    h = round(h, 6)
    return cx, cy, w, h


def save_category(class_dir, class_name_path):
    """
    保存类别，并编号，onehot编码使用
    :param class_name_path: 保存路径
    :param class_dir: 全部类别字典
    :return: category_num类别键值对
    """

    c = 0
    category_num = {}

    if FIXED_CATEGORY:
        category_num = CATEGORY_PARENT_CLASS_KV
        with open(class_name_path, 'w', encoding="utf-8") as f:
            # sorted(class_dir) 需要将数据排序，否则可能onehot编码类别对应错误
            for k, v in category_num.items():
                # 类别保存为txt
                f.writelines(f"  {k}: {v}")
                f.writelines("\n")
                f.flush()
        f.close()

    else:
        with open(class_name_path, 'w', encoding="utf-8") as f:
            # sorted(class_dir) 需要将数据排序，否则可能onehot编码类别对应错误
            for ct in sorted(class_dir):
                # 类别保存为txt

                category_num[c] = ct
                f.writelines(f"  {c}: {ct}")

                f.writelines("\n")
                f.flush()

                c = c + 1
        f.close()

    return category_num


def save_labels(out_labels_path, boxes):
    """
    保存图片标注框txt，一张图片一个txt
    :param out_labels_path: labels txt保存路径
    :param boxes: onehot类别，cx, cy, w, h，相对于原始图片的宽高百分比
    """

    with open(out_labels_path, 'w', encoding='utf-8') as f:
        for strs in boxes:
            f.writelines([(str(x) + " ") for x in strs])
            f.writelines("\n")
            f.flush()
    f.close()


def save_data_partition_txt(txt_file_path, file_array):
    """
    保存数据划分txt， train.txt val.txt test.txt
    :param txt_file_path: txt保存路径
    :param file_array: 数据划分结果数组
    """
    with open(txt_file_path, 'w', encoding='utf-8') as f:
        for strs in file_array:
            f.writelines(strs)
            f.writelines("\n")
            f.flush()
    f.close()


def save_class_count(all_class_dir):
    """
    保存类别统计数据为 CSV
    :param all_class_dir: 没有去重的全部类别数据
    """

    # 使用Counter统计元素出现的次数
    element_count = Counter(all_class_dir)
    sorted_counts = sorted(element_count.items(), key=lambda x: x[1], reverse=True)

    with open(CLASS_COUNT_PATH, 'w', encoding='utf-8') as f:
        for element in sorted_counts:
            strs = f"{element[0]}, {element[1]}"
            f.writelines(strs)
            f.writelines("\n")
            f.flush()
        f.close()


class ImageAugment:

    def horizontal_flip_image(self, image_input, label_lines):
        """
        图像水平翻转
        :param image:
        :param label_lines:
        :return:
        """
        image = image_input.copy()
        height, width, channels = image.shape

        img = cv2.flip(image, 1)
        _convert_box = []
        for line in label_lines:
            class_id, center_x, center_y, box_width, box_height = map(float, line.strip().split())
            new_center_x = (width - width * center_x - 1) / width
            _convert_box.append((int(class_id), new_center_x, center_y, box_width, box_height))

        return img, _convert_box

    def vertical_flip_image(self, image_input, label_lines):
        """
        图像垂直翻转
        :param image:
        :param label_lines:
        :return:
        """
        image = image_input.copy()
        height, width, channels = image.shape

        img = cv2.flip(image, 0)
        _convert_box = []
        for line in label_lines:
            class_id, center_x, center_y, box_width, box_height = map(float, line.strip().split())
            new_center_y = (height - height * center_y - 1) / height
            _convert_box.append((int(class_id), center_x, new_center_y, box_width, box_height))

        return img, _convert_box

    def adjust_brightness_contrast(self, image_input):
        """
        调整图像的亮度和对比度
        :param image:
        :return:
        """
        image = image_input.copy()
        alpha = random.uniform(0.5, 1.5)
        beta = random.randint(10, 50)
        return cv2.convertScaleAbs(image, alpha=alpha, beta=beta)

    def salt_and_pepper_noise(self, image_input, salt_prob=0.01, pepper_prob=0.01):
        """
        添加椒盐噪声
        :param image:
        :param salt_prob:
        :param pepper_prob:
        :return:
        """
        image = image_input.copy()
        noisy_image = image
        total_pixels = image.size
        num_salt = int(total_pixels * salt_prob)
        salt_coords = [np.random.randint(0, i - 1, num_salt) for i in image.shape]
        noisy_image[salt_coords[0], salt_coords[1]] = 255
        num_pepper = int(total_pixels * pepper_prob)
        pepper_coords = [np.random.randint(0, i - 1, num_pepper) for i in image.shape]
        noisy_image[pepper_coords[0], pepper_coords[1]] = 0
        return noisy_image

    def color_distortion(self, image_input,
                         color_matrix=np.array([[0.393, 0.769, 0.189],
                                                [0.349, 0.686, 0.168],
                                                [0.272, 0.534, 0.131]])):
        """
        改变颜色
        :param image:
        :param color_matrix:
        :return:
        """
        image = image_input.copy()
        return cv2.transform(image, color_matrix)

    def mask(self, image_input, width_proportion=(0.05, 0.20), height_proportion=(0.05, 0.20)):
        """
        随机遮挡
        :param image:
        :param width_proportion: 遮挡区域宽度占比范围
        :param height_proportion: 遮挡区域高度占比范围
        :return:
        """
        image = image_input.copy()
        img_height, img_width, _ = image.shape
        mask_width = random.randint(int(img_width * width_proportion[0]), int(img_width * width_proportion[1]))
        mask_height = random.randint(int(img_height * height_proportion[0]), int(img_height * height_proportion[1]))

        pos_x = random.randint(0, int(img_width - mask_width))
        pos_y = random.randint(0, int(img_height - mask_height))

        image[pos_y: min((pos_y + mask_height), img_height),
        pos_x: min((pos_x + mask_width), img_width)] = 0

        return image

    def enhance_reduce(self, image_input, strength=100):
        """
        加强或者变暗
        :param image:
        :param strength:
        :return:
        """

        # strength > 0 enhance, strength < 0 reduce
        image = image_input.copy()
        x, y, _ = image.shape
        radius = np.random.randint(10, int(min(x, y)), 1)
        pos_x = np.random.randint(0, (min(x, y) - radius), 1)
        pos_y = np.random.randint(0, (min(x, y) - radius), 1)
        pos_x = int(pos_x[0])
        pos_y = int(pos_y[0])
        radius = int(radius[0])
        for j in range(pos_y - radius, pos_y + radius):
            for i in range(pos_x - radius, pos_x + radius):
                distance = math.pow((pos_x - i), 2) + math.pow((pos_y - j), 2)
                distance = np.sqrt(distance)
                if distance < radius:
                    result = 1 - distance / radius
                    result = result * strength
                    if strength > 0:
                        image[i, j, 0] = min((image[i, j, 0] + result), 255)
                        image[i, j, 1] = min((image[i, j, 1] + result), 255)
                        image[i, j, 2] = min((image[i, j, 2] + result), 255)
                    else:
                        image[i, j, 0] = max((image[i, j, 0] + result), 0)
                        image[i, j, 1] = max((image[i, j, 1] + result), 0)
                        image[i, j, 2] = max((image[i, j, 2] + result), 0)
        image = image.astype(np.uint8)
        return image

    def clahe_image(self, image_input):
        """
        自适应直方图均衡化
        :param image_input:
        :return:
        """
        image = image_input.copy()
        b, g, r = cv2.split(image)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(5, 5))
        clahe_b = clahe.apply(b)
        clahe_g = clahe.apply(g)
        clahe_r = clahe.apply(r)
        return cv2.merge((clahe_b, clahe_g, clahe_r))

    def detailEnhance_image(self, image_input):
        """
        油画与非真实感渲染
        :param image_input:
        :return:
        """
        image = image_input.copy()
        return cv2.detailEnhance(image, None, 20, 0.8)

    def rotate_image(self, image_input, label_lines, rotate_angle=(-30, 30)):
        """
        随机旋转
        :param image_input:
        :param label_lines:
        :param rotate_angle:
        :return:
        """

        image = image_input.copy()
        rows, cols, _ = image.shape
        img_height, img_width, channels = image.shape

        angle = random.randint(rotate_angle[0], rotate_angle[1])
        M = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle, 1)
        rotated_image = cv2.warpAffine(image, M, (cols, rows))

        _convert_box = []
        for line in label_lines:
            class_id, center_x, center_y, box_width, box_height = map(float, line.strip().split())

            # 将目标框坐标转换为以图片中心为原点的相对坐标
            x_center = center_x * img_width
            y_center = center_y * img_height
            bbox_width = box_width * img_width
            bbox_height = box_height * img_height

            # 将相对坐标转换为以左上角为原点的绝对坐标
            x_min = x_center - bbox_width / 2
            y_min = y_center - bbox_height / 2
            x_max = x_center + bbox_width / 2
            y_max = y_center + bbox_height / 2

            # 计算旋转后的坐标
            center = (img_width / 2, img_height / 2)
            rot_mat = cv2.getRotationMatrix2D(center, angle, 1.0)
            corners = np.array([[x_min, y_min], [x_min, y_max], [x_max, y_min], [x_max, y_max]], dtype=np.float32)
            rotated_corners = cv2.transform(np.array([corners]), rot_mat)[0]

            # 计算旋转后的目标框坐标
            x_min_rot = max(np.min(rotated_corners[:, 0]), 0)
            y_min_rot = max(np.min(rotated_corners[:, 1]), 0)
            x_max_rot = min(np.max(rotated_corners[:, 0]), img_width)
            y_max_rot = min(np.max(rotated_corners[:, 1]), img_height)

            # 将目标框坐标转换为相对坐标
            x_center_rot = (x_min_rot + x_max_rot) / 2
            y_center_rot = (y_min_rot + y_max_rot) / 2
            bbox_width_rot = x_max_rot - x_min_rot
            bbox_height_rot = y_max_rot - y_min_rot

            x_center_rot_rel = x_center_rot / img_width
            y_center_rot_rel = y_center_rot / img_height
            bbox_width_rot_rel = bbox_width_rot / img_width
            bbox_height_rot_rel = bbox_height_rot / img_height

            _convert_box.append(
                (int(class_id), x_center_rot_rel, y_center_rot_rel, bbox_width_rot_rel, bbox_height_rot_rel))

        return rotated_image, _convert_box


def data_augmentation():
    ia = ImageAugment()

    for file in tqdm(os.listdir(OUT_IMAGES_PATH), desc="ImageAugment Processing"):
        image_path = os.path.join(OUT_IMAGES_PATH, file)
        _file_name = os.path.splitext(file)[0]
        _image_ext = os.path.splitext(file)[1]

        label_path = os.path.join(OUT_LABELS_PATH, f"{_file_name}.txt")

        image = cv2.imread(image_path)

        # Read label file
        with open(label_path, "r") as f:
            label_lines = f.readlines()

        # ___________ 图片处理 ___________

        # 随机旋转 01
        rotate_image, convert_box = ia.rotate_image(image, label_lines)
        new_image_path = image_path.replace(".jpg", "_rotate.jpg")
        cv2.imwrite(new_image_path, rotate_image)

        new_label_path = label_path.replace(".txt", "_rotate.txt")
        save_labels(new_label_path, convert_box)

        # 随机旋转 02
        rotate_image, convert_box = ia.rotate_image(image, label_lines)
        new_image_path = image_path.replace(".jpg", "_rotate02.jpg")
        cv2.imwrite(new_image_path, rotate_image)

        new_label_path = label_path.replace(".txt", "_rotate02.txt")
        save_labels(new_label_path, convert_box)

        # 调整图像的亮度和对比度
        adjusted_image = ia.adjust_brightness_contrast(image)
        new_image_path = image_path.replace(".jpg", "_adjusted.jpg")
        cv2.imwrite(new_image_path, adjusted_image)
        new_label_path = label_path.replace(".txt", "_adjusted.txt")
        shutil.copy2(label_path, new_label_path)

        # 图像水平翻转
        flip_h_image, convert_box = ia.horizontal_flip_image(image, label_lines)
        new_image_path = image_path.replace(".jpg", "_flip_h.jpg")
        cv2.imwrite(new_image_path, flip_h_image)

        new_label_path = label_path.replace(".txt", "_flip_h.txt")
        save_labels(new_label_path, convert_box)

        # 图像垂直翻转
        flip_v_image, convert_box = ia.vertical_flip_image(image, label_lines)
        new_image_path = image_path.replace(".jpg", "_flip_v.jpg")
        cv2.imwrite(new_image_path, flip_v_image)

        new_label_path = label_path.replace(".txt", "_flip_v.txt")
        save_labels(new_label_path, convert_box)

        # 图像水平翻转 调整图像的亮度和对比度
        flip_h_image, convert_box = ia.horizontal_flip_image(adjusted_image, label_lines)
        new_image_path = image_path.replace(".jpg", "_flip_hadj.jpg")
        cv2.imwrite(new_image_path, flip_h_image)

        new_label_path = label_path.replace(".txt", "_flip_hadj.txt")
        save_labels(new_label_path, convert_box)

        # 图像垂直翻转 调整图像的亮度和对比度
        flip_v_image, convert_box = ia.vertical_flip_image(adjusted_image, label_lines)
        new_image_path = image_path.replace(".jpg", "_flip_vadj.jpg")
        cv2.imwrite(new_image_path, flip_v_image)

        new_label_path = label_path.replace(".txt", "_flip_vadj.txt")
        save_labels(new_label_path, convert_box)

        # 添加椒盐噪声
        salt_image = ia.salt_and_pepper_noise(image)
        new_image_path = image_path.replace(".jpg", "_salt.jpg")
        cv2.imwrite(new_image_path, salt_image)
        new_label_path = label_path.replace(".txt", "_salt.txt")
        shutil.copy2(label_path, new_label_path)

        # 改变颜色
        color_distorted_image = ia.color_distortion(image)
        new_image_path = image_path.replace(".jpg", "_color.jpg")
        cv2.imwrite(new_image_path, color_distorted_image)
        new_label_path = label_path.replace(".txt", "_color.txt")
        shutil.copy2(label_path, new_label_path)

        # 随机遮挡
        mask_image = ia.mask(image)
        new_image_path = image_path.replace(".jpg", "_mask.jpg")
        cv2.imwrite(new_image_path, mask_image)
        new_label_path = label_path.replace(".txt", "_mask.txt")
        shutil.copy2(label_path, new_label_path)

        # 加强或者变暗 100
        enhance_image = ia.enhance_reduce(image, 100)
        new_image_path = image_path.replace(".jpg", "_enhance.jpg")
        cv2.imwrite(new_image_path, enhance_image)
        new_label_path = label_path.replace(".txt", "_enhance.txt")
        shutil.copy2(label_path, new_label_path)

        # 加强或者变暗 -100
        reduce_image = ia.enhance_reduce(image, -100)
        new_image_path = image_path.replace(".jpg", "_reduce.jpg")
        cv2.imwrite(new_image_path, reduce_image)
        new_label_path = label_path.replace(".txt", "_reduce.txt")
        shutil.copy2(label_path, new_label_path)

        # 自适应直方图均衡化
        clahe_image = ia.clahe_image(image)
        new_image_path = image_path.replace(".jpg", "_clahe.jpg")
        cv2.imwrite(new_image_path, clahe_image)
        new_label_path = label_path.replace(".txt", "_clahe.txt")
        shutil.copy2(label_path, new_label_path)

        # 油画与非真实感渲染
        detailEnhance_image = ia.detailEnhance_image(image)
        new_image_path = image_path.replace(".jpg", "_detailEnhance.jpg")
        cv2.imwrite(new_image_path, detailEnhance_image)
        new_label_path = label_path.replace(".txt", "_detailEnhance.txt")
        shutil.copy2(label_path, new_label_path)


def data_partition():
    """
    数据划分按照设置比例划分为 train val test
    """
    train_file = []
    val_file = []
    test_file = []

    total_file_num = len(os.listdir(OUT_IMAGES_PATH))
    val_num = int(total_file_num * VAL_PERCENT)
    test_num = int(total_file_num * (VAL_PERCENT + TEST_PERCENT))

    k = 0
    for root, dirs, files in os.walk(OUT_IMAGES_PATH):
        random.shuffle(files)
        for file in files:
            file_name = os.path.join(root, file)

            # 放入val
            if k < val_num:
                val_file.append(file_name)

            # 放入test
            elif k < test_num:
                test_file.append(file_name)

            # 放入train
            else:
                train_file.append(file_name)

            k = k + 1

    # ___________ 保存txt ___________

    # test_file
    save_data_partition_txt(OUT_TEST_TXT_PATH, test_file)

    # val_file
    save_data_partition_txt(OUT_VAL_TXT_PATH, val_file)

    # train_file
    save_data_partition_txt(OUT_TRAIN_TXT_PATH, train_file)


def data_processing():
    """
    数据处理调用函数
    """

    # ___________ 文件夹初始化 ___________
    if os.path.exists(OUT_PATH):
        print("数据删除中……")
        shutil.rmtree(OUT_PATH)
        print("数据已删除")
    os.makedirs(OUT_PATH)
    os.makedirs(OUT_LABELS_PATH)
    os.makedirs(OUT_IMAGES_PATH)

    # ___________ 加载xml循环处理图片，根据xml读取图片 ___________

    object_box, class_dir, all_class_dir = load_xml(ANNOTATIONS_PATH, ORIGINAL_IMG_PATH)
    category_num = save_category(class_dir, OUT_CLASS_NAME_PATH)  # 保存类别

    if TEST_MOD == True:
        object_box = random.sample(object_box, TEST_NUM)

    # 保存类别统计数据为 CSV
    save_class_count(all_class_dir)

    for obj_str in object_box:
        try:

            obj_array = obj_str.split()

            file_name = obj_array[0]

            # if TEST_MOD == True and os.path.basename(file_name) != "2024_01_09_11_00_57_weight.jpg":
            #     continue

            new_file_name = os.path.join(OUT_IMAGES_PATH, file_name.split(os.sep)[-1])

            # 标签框处理
            box_str = obj_array[1:]
            box_array = [box_str[i:i + 5] for i in range(0, len(box_str), 5)]
            img = Image.open(file_name)

            _convert_box = []
            for box in box_array:
                class_name = box[0]
                xmin = float(box[1])
                ymin = float(box[2])
                xmax = float(box[3])
                ymax = float(box[4])

                if FIXED_CATEGORY:
                    class_name_one_hot = CATEGORY_SUBCLASS_VK[class_name]
                else:
                    class_name_one_hot = get_key_by_value(category_num, class_name)

                cx, cy, w, h = convert_box(img.size, [xmin, xmax, ymin, ymax])
                _convert_box.append((class_name_one_hot, cx, cy, w, h))

            # 将原始图片原封不动复制到新目录下
            shutil.copy2(file_name, new_file_name)

            # 保存labels
            real_file_name = file_name.split(os.sep)[-1]
            real_file_name = real_file_name.split(".")[0]  # 不要文件扩展名

            _label_name = os.path.join(OUT_LABELS_PATH, f"{real_file_name}.txt")
            save_labels(_label_name, _convert_box)

        except FileNotFoundError as e:
            print(e)
            continue

    # ___________ 数据增强 ___________
    if OPEN_AUGMENTATION == True:
        data_augmentation()

    # ___________ 数据划分 ___________
    data_partition()


if __name__ == '__main__':

    # ___________ 文件夹路径 ___________

    ANNOTATIONS_PATH = r"D:\zhangkun_20240407\all_dataset\zk_arrange_voc\xml"  # 原始标注XML路径
    ORIGINAL_IMG_PATH = r"D:\zhangkun_20240407\all_dataset\zk_arrange_voc\images"  # 原始图片路径

    # 数据输出文件夹总路径
    OUT_PATH = r"D:\zhangkun_20240407\all_dataset\zk_yolo_su_lsp_20240418"

    OUT_LABELS_PATH = os.path.join(OUT_PATH, "labels")
    OUT_IMAGES_PATH = os.path.join(OUT_PATH, "images")
    OUT_TEST_TXT_PATH = os.path.join(OUT_PATH, "test.txt")
    OUT_TRAIN_TXT_PATH = os.path.join(OUT_PATH, "train.txt")
    OUT_VAL_TXT_PATH = os.path.join(OUT_PATH, "val.txt")
    OUT_CLASS_NAME_PATH = os.path.join(OUT_PATH, "class_name.txt")
    CLASS_COUNT_PATH = os.path.join(OUT_PATH, "class_count.csv")

    # ___________ 训练测试数据占比 ___________

    # VAL TEST 占总数据的百分比
    # train = 1 - VAL_PERCENT - TEST_PERCENT
    VAL_PERCENT = 0.15
    TEST_PERCENT = 0.10

    # ___________ 类别设置 ___________

    # 不指定类别写为空 TARGET_CATEGORY = []

    TARGET_CATEGORY = ["塑料水瓶",
                       # "废纸板",
                       # "易拉罐",
                       # "综合纸",
                       # "杂项纸",
                       "非饮用塑料水瓶",
                       # "旧书报",
                       # "扎带",
                       # "袋装",
                       "塑料水瓶扁",
                       # "废纸箱",
                       # "旧衣物",
                       # "易拉罐扁"
                       ]

    # 类别转换  onehot 固定编码
    # 格式说明：指定编码3: ["父类重命名", ["子类对应名称" "子类对应名称" "子类对应名称"]]
    CATEGORY_SUMMARY = {
        0: ["塑料水瓶", ["塑料水瓶"]],
        1: ["非饮用塑料水瓶", ["非饮用塑料水瓶"]],
        2: ["塑料水瓶扁", ["塑料水瓶扁"]]
    }

    CATEGORY_PARENT_CLASS_KV = {k: v[0] for k, v in CATEGORY_SUMMARY.items()}
    CATEGORY_PARENT_CLASS_VK = {v[0]: k for k, v in CATEGORY_SUMMARY.items()}

    CATEGORY_SUBCLASS_VK = {}
    for pk, pv in CATEGORY_SUMMARY.items():
        for sv in pv[1]:
            CATEGORY_SUBCLASS_VK[sv] = pk

    #  ___________ 开关参数 ___________

    MOD_IMAGE_PROCESSING = True  # True图片数据集处理模式   False画图查看模式

    TEST_MOD = False  # 是否打开测试模式，打开时只生成部分测试数据
    TEST_NUM = 10  # 测试数量

    OPEN_AUGMENTATION = True  # 是否开启数据增强
    FIXED_RANDOM = False  # 将随机数固定
    FIXED_CATEGORY = True  # 是否固定类别，类别固定后，根据手动指定的类别进行 onehot 编码，否则自动编码

    # ___________ 画部分标注数据 ___________
    DRAW_FILE_NAME = False  # 画图时是否展示文件名
    SAVE_IMG = False  # 保存图片，则不显示

    DRAW_CATEGORY = ["袋装"]  # 画图指定类别，不指定类别为空
    if MOD_IMAGE_PROCESSING == False:
        # draw_voc_by_xml()  # TODO  画 xml 时 进行类别转换  2024年4月17日15:40:05
        draw_yolo_by_img()

    # ___________ 数据处理 ___________

    if TEST_MOD and FIXED_RANDOM:
        random.seed(999)

    if MOD_IMAGE_PROCESSING == True:
        data_processing()
