import os
import subprocess

if __name__ == '__main__':
    # ___________ 模型参数设置 ___________
    py_exe = r"C:\Users\ghome\AppData\Local\Programs\Python\Python38\python.exe"
    py = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\detect.py"
    weights = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\runs\train\major_category\weights\best.pt"

    # source = r"D:\zhangkun_20240407\all_dataset\zk_yolo_20240415\val_small.txt"
    source = r"D:\zhangkun_20240407\all_dataset\zk_yolo_20240415\test_small.txt"

    data = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\recycle_dataset.yaml"
    project = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\runs\detect"

    # --exist-ok

    call_command = f"{py_exe} {py} --data {data} --project {project} --weights {weights} --source {source} "
    print("\n\n", call_command)

    process = subprocess.Popen(call_command, shell=True)
    process.wait()
