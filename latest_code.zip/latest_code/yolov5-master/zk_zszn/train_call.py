import subprocess


def major_category():
    """
    大类别训练

    # 格式说明：指定编码3: ["父类重命名", ["子类对应名称" "子类对应名称" "子类对应名称"]]
    CATEGORY_SUMMARY = {0: ["塑料水瓶", ["塑料水瓶", "塑料水瓶扁", "非饮用塑料水瓶"]],
                        1: ["废纸板", ["废纸板", "综合纸", "杂项纸", "旧书报", "废纸箱"]],
                        2: ["易拉罐", ["易拉罐", "易拉罐扁"]],
                        3: ["旧衣物", ["旧衣物"]]}

    :return:
    """

    # ___________ 模型参数设置 ___________
    py = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\train.py"
    py_exe = r"C:\Users\ghome\AppData\Local\Programs\Python\Python38\python.exe"
    epochs = 32
    batch_size = 4

    cfg = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\recycle_model_L.yaml"
    data = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\recycle_dataset.yaml"
    project = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\runs\train"
    weights = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\runs\backup\best.pt"
    name = "major_category"

    call_command = rf"{py_exe} {py} --data {data} --weights {weights} --epochs {epochs} --cfg {cfg} --project {project} --name {name} --exist-ok --batch-size {batch_size}"
    print("\n\n", call_command)

    process = subprocess.Popen(call_command, shell=True)
    process.wait()


if __name__ == '__main__':
    # ___________ 大类别训练 ___________
    major_category()
