# ___________________ yolov5 网络加载 ___________________
import os

import cv2
import torch

PRJ_PATH = os.path.dirname(os.path.abspath(__file__))
# print(PRJ_PATH)
# print(os.path.dirname(PRJ_PATH))

model = torch.hub.load(repo_or_dir=os.path.dirname(PRJ_PATH),
                       model="custom",
                       path=r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_zszn\runs\train\major_category\weights\best.pt",
                       source="local")
model.eval()
# model.conf = 0.45
# model.iou = 0.25

# image = cv2.imread(r"D:\zhangkun_20240407\zk_temp\2023_12_06_21_19_54_weight_flip_h.jpg")

result = model(r"D:\zhangkun_20240407\zk_temp\2023_12_06_21_19_54_weight_flip_h.jpg")
# result = model(image)
# boxes = result.xyxy[0]  # 获取预测框

print(result)
