import gradio as gr
import torch

# 加载 YOLOv5 模型
model = torch.hub.load(repo_or_dir=r"D:\PycharmProjects\yolov5-master",
                       model="custom",
                       path=r"D:\PycharmProjects\yolov5-master\runs\train\exp3\weights\best.pt",
                       source="local")  # 替换为适当的模型配置和权重文件路径


# 创建 Gradio 接口
def yolo_inference(image, conf_thres, iou_thres):
    model.conf = conf_thres
    model.iou = iou_thres
    results = model(image)
    return results.render()[0]


title = "yolov5检测"
desc = "desc here"

# 启动 Gradio 接口
gr.Interface(
    fn=yolo_inference,
    inputs=["image",
            gr.Slider(minimum=0, maximum=1, value=0.25),
            gr.Slider(minimum=0, maximum=1, value=0.45)],
    outputs=["image"],
    title=title,
    description=desc
).launch()
