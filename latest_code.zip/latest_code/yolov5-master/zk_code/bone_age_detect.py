import math

import cv2
import torch
from PyQt5.QtGui import QImage, QPixmap
from ultralytics.yolo.utils.plotting import Annotator, colors

from zk_code.arthrosis_predict import call_yolo_classify
from zk_code.finger_filter import finger_filter


def calcBoneAge(score, sex):
    # 根据总分计算对应的年龄
    if sex == 'boy':
        boneAge = 2.01790023656577 + (-0.0931820870747269) * score + math.pow(score, 2) * 0.00334709095418796 + \
                  math.pow(score, 3) * (-3.32988302362153E-05) + math.pow(score, 4) * (1.75712910819776E-07) + \
                  math.pow(score, 5) * (-5.59998691223273E-10) + math.pow(score, 6) * (1.1296711294933E-12) + \
                  math.pow(score, 7) * (-1.45218037113138e-15) + math.pow(score, 8) * (1.15333377080353e-18) + \
                  math.pow(score, 9) * (-5.15887481551927e-22) + math.pow(score, 10) * (9.94098428102335e-26)
        return round(boneAge, 2)
    elif sex == 'girl':
        boneAge = 5.81191794824917 + (-0.271546561737745) * score + \
                  math.pow(score, 2) * 0.00526301486340724 + math.pow(score, 3) * (-4.37797717401925E-05) + \
                  math.pow(score, 4) * (2.0858722025667E-07) + math.pow(score, 5) * (-6.21879866563429E-10) + \
                  math.pow(score, 6) * (1.19909931745368E-12) + math.pow(score, 7) * (-1.49462900826936E-15) + \
                  math.pow(score, 8) * (1.162435538672E-18) + math.pow(score, 9) * (-5.12713017846218E-22) + \
                  math.pow(score, 10) * (9.78989966891478E-26)
        return round(boneAge, 2)


def export(results, score, boneAge):
    report = """
    第一掌骨骺分级{}级，得{}分；第三掌骨骨骺分级{}级，得{}分；第五掌骨骨骺分级{}级，得{}分；
    第一近节指骨骨骺分级{}级，得{}分；第三近节指骨骨骺分级{}级，得{}分；第五近节指骨骨骺分级{}级，得{}分；
    第三中节指骨骨骺分级{}级，得{}分；第五中节指骨骨骺分级{}级，得{}分；
    第一远节指骨骨骺分级{}级，得{}分；第三远节指骨骨骺分级{}级，得{}分；第五远节指骨骨骺分级{}级，得{}分；
    尺骨分级{}级，得{}分；桡骨骨骺分级{}级，得{}分。

    RUS-CHN分级计分法，受检儿CHN总得分：{}分，骨龄约为{}岁。""".format(
        results['MCPFirst'][0], results['MCPFirst'][1],
        results['MCPThird'][0], results['MCPThird'][1],
        results['MCPFifth'][0], results['MCPFifth'][1],
        results['PIPFirst'][0], results['PIPFirst'][1],
        results['PIPThird'][0], results['PIPThird'][1],
        results['PIPFifth'][0], results['PIPFifth'][1],
        results['MIPThird'][0], results['MIPThird'][1],
        results['MIPFifth'][0], results['MIPFifth'][1],
        results['DIPFirst'][0], results['DIPFirst'][1],
        results['DIPThird'][0], results['DIPThird'][1],
        results['DIPFifth'][0], results['DIPFifth'][1],
        results['Ulna'][0], results['Ulna'][1],
        results['Radius'][0], results['Radius'][1],
        score, boneAge)
    return report


def detect(img_path, sex):
    # ___________________ 参数定义 ___________________

    SCORE = {
        'girl': {
            'Radius': [10, 15, 22, 25, 40, 59, 91, 125, 138, 178, 192, 199, 203, 210],
            'Ulna': [27, 31, 36, 50, 73, 95, 120, 157, 168, 176, 182, 189],
            'MCPFirst': [5, 7, 10, 16, 23, 28, 34, 41, 47, 53, 66],
            'MCPThird': [3, 5, 6, 9, 14, 21, 32, 40, 47, 51],
            'MCPFifth': [4, 5, 7, 10, 15, 22, 33, 43, 47, 51],
            'PIPFirst': [6, 7, 8, 11, 17, 26, 32, 38, 45, 53, 60, 67],
            'PIPThird': [3, 5, 7, 9, 15, 20, 25, 29, 35, 41, 46, 51],
            'PIPFifth': [4, 5, 7, 11, 18, 21, 25, 29, 34, 40, 45, 50],
            'MIPThird': [4, 5, 7, 10, 16, 21, 25, 29, 35, 43, 46, 51],
            'MIPFifth': [3, 5, 7, 12, 19, 23, 27, 32, 35, 39, 43, 49],
            'DIPFirst': [5, 6, 8, 10, 20, 31, 38, 44, 45, 52, 67],
            'DIPThird': [3, 5, 7, 10, 16, 24, 30, 33, 36, 39, 49],
            'DIPFifth': [5, 6, 7, 11, 18, 25, 29, 33, 35, 39, 49]},

        'boy': {
            'Radius': [8, 11, 15, 18, 31, 46, 76, 118, 135, 171, 188, 197, 201, 209],
            'Ulna': [25, 30, 35, 43, 61, 80, 116, 157, 168, 180, 187, 194],
            'MCPFirst': [4, 5, 8, 16, 22, 26, 34, 39, 45, 52, 66],
            'MCPThird': [3, 4, 5, 8, 13, 19, 30, 38, 44, 51],
            'MCPFifth': [3, 4, 6, 9, 14, 19, 31, 41, 46, 50],
            'PIPFirst': [4, 5, 7, 11, 17, 23, 29, 36, 44, 52, 59, 66],
            'PIPThird': [3, 4, 5, 8, 14, 19, 23, 28, 34, 40, 45, 50],
            'PIPFifth': [3, 4, 6, 10, 16, 19, 24, 28, 33, 40, 44, 50],
            'MIPThird': [3, 4, 5, 9, 14, 18, 23, 28, 35, 42, 45, 50],
            'MIPFifth': [3, 4, 6, 11, 17, 21, 26, 31, 36, 40, 43, 49],
            'DIPFirst': [4, 5, 6, 9, 19, 28, 36, 43, 46, 51, 67],
            'DIPThird': [3, 4, 5, 9, 15, 23, 29, 33, 37, 40, 49],
            'DIPFifth': [3, 4, 6, 11, 17, 23, 29, 32, 36, 40, 49]}
    }

    # 字典顺序要严格按照 finger_filter 返回的顺序进行设置
    # 关节评分标准
    scoring_criteria = ['DIP', 'DIP', 'DIPFirst',
                        'MCP', 'MCP',
                        'MCPFirst',
                        'MIP', 'MIP',
                        'PIP', 'PIP', 'PIPFirst',
                        'Radius',
                        'Ulna']

    # 字典顺序要严格按照 finger_filter 返回的顺序进行设置
    # 关节划分区域
    arthrosis_partition_area = ['DIPFifth', 'DIPThird', 'DIPFirst',
                                'MCPFifth', 'MCPThird',
                                'MCPFirst',
                                'MIPFifth', 'MIPThird',
                                'PIPFifth', 'PIPThird', 'PIPFirst',
                                'Radius',
                                'Ulna']

    # ___________________ yolov5 网络加载 ___________________

    model = torch.hub.load(repo_or_dir=r"D:\PycharmProjects\yolov5-master",
                           model="custom",
                           path=r"D:\PycharmProjects\yolov5-master\runs\train\exp3\weights\best.pt",
                           source="local")
    model.eval()
    model.conf = 0.45
    model.iou = 0.25

    # img_path = r"D:\PycharmProjects\ai_dataset\bone_age_voc\voc_to_yolo\images\1660.png"

    result = model(img_path)
    boxes = result.xyxy[0]  # 获取预测框
    det, status, err_msg = finger_filter(boxes)  # 调用手指关节过滤

    # ___________________ 调用 yolov5 原生功能框架将预测框画在图上 ___________________

    im0 = cv2.imread(img_path)
    names = model.names
    annotator = Annotator(im0, line_width=3, example=str(names))

    # 从右向左依次取数 cls conf 剩下的全部数据给 *xyxy
    for *xyxy, conf, cls in det:
        c = int(cls)  # integer class
        label = f'{names[c]} {conf:.2f}'
        annotator.box_label(xyxy, label, color=colors(c, True))

    im0 = annotator.result()
    # cv2.imwrite(r"D:\PycharmProjects\yolov5-master\zk_code\arthrosis_dataset.png", im0)

    # ___________________ 将 opencv 打开的格式图片转为 QT界面展示格式图片 ___________________

    # 转换BGR到RGB格式
    image_rgb = cv2.cvtColor(im0, cv2.COLOR_BGR2RGB)

    # 创建Qt图像
    height, width, channel = image_rgb.shape
    bytes_per_line = 3 * width
    q_image = QImage(image_rgb.data, width, height, bytes_per_line, QImage.Format_RGB888)

    # 将Qt图像转换为QPixmap
    im0_pixmap = QPixmap.fromImage(q_image)

    # ___________________ 处理手指关节过滤结果 ___________________

    if status != "ok":
        # print(err_msg)
        return err_msg, im0_pixmap

    if status == "ok":

        img = cv2.imread(img_path)

        dic = {}
        sum_score = 0

        for i in range(len(scoring_criteria)):
            # 获取预测框左上角右下角坐标
            x1 = int(det[i][0])
            y1 = int(det[i][1])
            x2 = int(det[i][2])
            y2 = int(det[i][3])
            img_corp = img[y1:y2, x1: x2]

            # ___________________ 将大网络裁剪的关节，传入关节等级分类小网络 ___________________

            # weight = fr"D:\PycharmProjects\yolov5-master\runs\yolov5s_train_cls\{scoring_criteria[i]}\weights\best.pt"
            weight = fr"D:\PycharmProjects\yolov5-master\runs\train-cls\{scoring_criteria[i]}\weights\best.pt"
            index = call_yolo_classify(weight, img_corp) - 1
            # cv2.imwrite(fr'D:\PycharmProjects\yolov5-master\zk_code\temp_img\{scoring_criteria[i]}_{i}_score_{index}.png', img_corp)

            # ___________________ 获取得分 ___________________

            score = SCORE[sex][arthrosis_partition_area[i]][index]
            sum_score += score
            dic[arthrosis_partition_area[i]] = [index + 1, score]

        # ___________________ 获取年龄信息 ___________________

        boneAge = calcBoneAge(sum_score, sex)
        score_msg = export(dic, sum_score, boneAge)

        return score_msg, im0_pixmap


if __name__ == '__main__':
    img_path = r"D:\PycharmProjects\ai_dataset\bone_age_voc\voc_to_yolo\images\1526.png"
    sex = "girl"

    score_msg, im0_pixmap = detect(img_path, sex)
    print(score_msg)
    print(im0_pixmap)
