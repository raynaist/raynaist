
import cv2
import numpy as np
import random

# 读取图像
image = cv2.imread(r"D:\PycharmProjects\ai_dataset\VOCdevkit\VOC2012\JPEGImages\000004.jpg")

# 生成随机旋转角度在+20度至-20度之间
angle = random.randint(-20, 20)

# 获取图像尺寸
height, width = image.shape[:2]

# 计算旋转中心
center = (width // 2, height // 2)

# 生成旋转矩阵
rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)

# 执行旋转
rotated_image = cv2.warpAffine(image, rotation_matrix, (width, height))

# 显示旋转后的图像
cv2.imshow('Rotated Image', rotated_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

