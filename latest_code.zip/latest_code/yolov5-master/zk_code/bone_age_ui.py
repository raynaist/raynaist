from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import (QCoreApplication, QMetaObject, QRect,
                          Qt)
from PyQt5.QtGui import (QFont)
from PyQt5.QtWidgets import (QGraphicsView, QHBoxLayout,
                             QLabel, QPushButton, QRadioButton, QVBoxLayout, QWidget, QTextBrowser)

from zk_code.bone_age_detect import detect


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(1400, 900)
        self.verticalLayoutWidget = QWidget(Form)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(0, 0, 1800, 60))
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(self.verticalLayoutWidget)
        self.label.setObjectName(u"label")
        font = QFont()
        font.setPointSize(18)
        self.label.setFont(font)
        self.label.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.label)

        self.horizontalLayoutWidget = QWidget(Form)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(0, 130, 1800, 700))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.graphicsView_2 = QGraphicsView(self.horizontalLayoutWidget)
        self.graphicsView_2.setObjectName(u"graphicsView_2")
        self.graphicsView_2.setEnabled(True)

        self.horizontalLayout.addWidget(self.graphicsView_2)

        self.graphicsView = QGraphicsView(self.horizontalLayoutWidget)
        self.graphicsView.setObjectName(u"graphicsView")

        self.horizontalLayout.addWidget(self.graphicsView)

        self.horizontalLayoutWidget_2 = QWidget(Form)
        self.horizontalLayoutWidget_2.setObjectName(u"horizontalLayoutWidget_2")
        self.horizontalLayoutWidget_2.setGeometry(QRect(0, 835, 1800, 150))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        # self.commandLinkButton = QCommandLinkButton(self.horizontalLayoutWidget_2)
        # self.commandLinkButton.setObjectName(u"commandLinkButton")
        #
        # self.horizontalLayout_2.addWidget(self.commandLinkButton)

        self.textBrowser = QTextBrowser(self.horizontalLayoutWidget_2)
        self.textBrowser.setObjectName(u"textBrowser")
        self.horizontalLayout_2.addWidget(self.textBrowser)
        self.textBrowser.setStyleSheet("font-size: 14px;")

        self.horizontalLayoutWidget_3 = QWidget(Form)
        self.horizontalLayoutWidget_3.setObjectName(u"horizontalLayoutWidget_3")
        self.horizontalLayoutWidget_3.setGeometry(QRect(0, 60, 1800, 70))
        self.horizontalLayout_3 = QHBoxLayout(self.horizontalLayoutWidget_3)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.pushButton_2 = QPushButton(self.horizontalLayoutWidget_3)
        self.pushButton_2.setObjectName(u"pushButton_2")

        self.horizontalLayout_3.addWidget(self.pushButton_2)

        self.pushButton = QPushButton(self.horizontalLayoutWidget_3)
        self.pushButton.setObjectName(u"pushButton")

        self.horizontalLayout_3.addWidget(self.pushButton)

        self.radioButton_2 = QRadioButton(self.horizontalLayoutWidget_3)
        self.radioButton_2.setObjectName(u"radioButton_2")
        self.radioButton_2.setChecked(True)  # 设置默认选中

        self.horizontalLayout_3.addWidget(self.radioButton_2)

        self.radioButton = QRadioButton(self.horizontalLayoutWidget_3)
        self.radioButton.setObjectName(u"radioButton")

        self.horizontalLayout_3.addWidget(self.radioButton)

        self.retranslateUi(Form)

        self.pushButton_2.clicked.connect(self.openImageDialog)
        self.pushButton.clicked.connect(self.showImageDialog)

        QMetaObject.connectSlotsByName(Form)

    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.label.setText(QCoreApplication.translate("Form", u"YOLOv5骨龄检测系统", None))
        # self.commandLinkButton.setText(QCoreApplication.translate("Form", u"CommandLinkButton", None))
        # if QT_CONFIG(tooltip)
        self.pushButton_2.setToolTip(QCoreApplication.translate("Form", u"<html><head/><body><p>上传图片jpg、png格式</p></body></html>", None))
        # endif // QT_CONFIG(tooltip)
        self.pushButton_2.setText(QCoreApplication.translate("Form", u"上传X光图片", None))
        # if QT_CONFIG(tooltip)
        self.pushButton.setToolTip(QCoreApplication.translate("Form", u"<html><head/><body><p>请等待检测结果返回</p></body></html>", None))
        # endif // QT_CONFIG(tooltip)
        self.pushButton.setText(QCoreApplication.translate("Form", u"开始检测", None))
        self.radioButton_2.setText(QCoreApplication.translate("Form", u"男孩", None))
        self.radioButton.setText(QCoreApplication.translate("Form", u"女孩", None))
        # retranslateUi

    def openImageDialog(self):
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(None, "选择图片", "", "Images (*.png *.jpg)")
        self.imagePath = file_path
        if file_path:
            pixmap = QtGui.QPixmap(file_path)
            pixmap_item = QtWidgets.QGraphicsPixmapItem(pixmap)
            scene = QtWidgets.QGraphicsScene()
            scene.addItem(pixmap_item)
            self.graphicsView_2.setScene(scene)
            self.graphicsView_2.fitInView(pixmap_item, QtCore.Qt.KeepAspectRatio)

    def showImageDialog(self):

        boyIsChecked = self.radioButton_2.isChecked()  # boy
        girlIsChecked = self.radioButton.isChecked()  # girl

        # print("boyIsChecked", boyIsChecked)
        # print("girlIsChecked", girlIsChecked)
        # print(self.imagePath)

        if boyIsChecked:
            sex = "boy"

        if girlIsChecked:
            sex = "girl"

        score_msg, im0_pixmap = detect(self.imagePath, sex)

        # pixmap = QtGui.QPixmap(self.imagePath)

        pixmap_item = QtWidgets.QGraphicsPixmapItem(im0_pixmap)
        scene = QtWidgets.QGraphicsScene()
        scene.addItem(pixmap_item)
        self.graphicsView.setScene(scene)
        self.graphicsView.fitInView(pixmap_item, QtCore.Qt.KeepAspectRatio)

        # 赋值给 QTextBrowser
        self.textBrowser.setPlainText(score_msg)
