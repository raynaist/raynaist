import os
import random
import shutil

import cv2


def image_rotate(cv_img, angle=30):
    """
    数据增强随机旋转
    :param cv_img: opencv打开的图片
    :param angle: 随机旋转的角度
    :return: 增强后的opencv图片
    """
    angle = random.randint(-angle, angle)
    height, width = cv_img.shape[:2]
    center = (width // 2, height // 2)
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated_image = cv2.warpAffine(cv_img, rotation_matrix, (width, height))
    return rotated_image


def data_processing():
    # ___________ 文件夹初始化 ___________

    if os.path.exists(OUT_PATH):
        print("数据删除中……")
        shutil.rmtree(OUT_PATH)
        print("数据已删除")
    os.makedirs(OUT_PATH)

    # 重建所有子文件夹，数据划分类别文件夹
    for folder in os.listdir(ORIGINAL_IMG_PATH):
        for file_category in FILE_CATEGORY:
            new_folder = os.path.join(OUT_PATH, file_category, folder)
            os.makedirs(new_folder)

    # ___________ 将原始数据增强增样至均衡化数量，放在输出目录下的 train 文件夹下 ___________

    for root, dirs, files in os.walk(ORIGINAL_IMG_PATH):
        if len(files) > 0:
            file_num = 0

            # 数量没有达到均衡化数量，再次对这个文件夹图片进行循环处理
            while file_num < EQUALIZATION_NUM:

                random.shuffle(files)
                for file in files:
                    file_name = os.path.join(root, file)
                    file_name_path = file_name.split(os.sep)
                    new_file_name = os.path.join(OUT_PATH, "train", file_name_path[-2], f"{file_num}_{file_name_path[-1]}")

                    cv_img = cv2.imread(file_name)
                    rotated_image = image_rotate(cv_img)
                    cv2.imwrite(new_file_name, rotated_image)

                    file_num = file_num + 1
                    if file_num > EQUALIZATION_NUM:
                        break

    # ___________ 从 train 文件夹下按设定比例划分到 test val 中 ___________

    for root, dirs, files in os.walk(OUT_PATH):
        if len(files) > 0:

            file_num = len(files)
            test_num = int(file_num * TEST_PERCENT)
            val_num = int(file_num * (TEST_PERCENT + VAL_PERCENT))

            move_num = 0
            random.shuffle(files)
            for file in files:
                file_name = os.path.join(root, file)

                if move_num < test_num:
                    new_file_name = file_name.replace("\\train\\", "\\test\\")
                    shutil.move(file_name, new_file_name)

                elif move_num < val_num:
                    new_file_name = file_name.replace("\\train\\", "\\val\\")
                    shutil.move(file_name, new_file_name)

                else:
                    break

                move_num = move_num + 1


if __name__ == '__main__':
    # ___________ 参数定义 ___________

    ORIGINAL_IMG_PATH = r"D:\PycharmProjects\ai_dataset\flower_photos\original_image"  # 原始图片路径
    OUT_PATH = r"D:\PycharmProjects\ai_dataset\flower_photos\flower_yolo"  # 数据输出文件夹总路径

    # 数据划分类别
    FILE_CATEGORY = ["train", "test", "val"]

    # VAL TEST 占总数据的百分比
    # train = 1 - VAL_PERCENT - TEST_PERCENT
    VAL_PERCENT = 0.10
    TEST_PERCENT = 0.05

    # 增样各个类别原始数据达到的数量，使各类别数据保持相对均衡
    EQUALIZATION_NUM = 2000

    # ___________ 数据处理 ___________
    data_processing()
