import os
import sys
from pathlib import Path

import cv2
import torch
import torch.nn.functional as F

FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

from models.common import DetectMultiBackend
from utils.augmentations import classify_transforms
from utils.torch_utils import select_device


def call_yolo_classify(weights, source, imgsz=(224, 224)):
    model = DetectMultiBackend(weights, device=select_device())
    names = model.names
    transforms = classify_transforms(imgsz[0])

    if isinstance(source, str) == True:
        im0 = cv2.imread(source)
    else:
        im0 = source

    im = transforms(im0)
    im = torch.Tensor(im).to(model.device)
    im = im.half() if model.fp16 else im.float()  # uint8 to fp16/32
    if len(im.shape) == 3:
        im = im[None]  # expand for batch dim
    results = model(im)
    pred = F.softmax(results, dim=1)  # probabilities
    max_idx = torch.argmax(pred, dim=1).item()
    classify = names[max_idx]
    return classify


if __name__ == '__main__':
    weights = r"D:\PycharmProjects\yolov5-master\runs\train-cls\flower\weights\best.pt"
    source = r"D:\PycharmProjects\ai_dataset\flower_photos\flower_yolo\train\dandelion\12_7193058132_36fd883048_m.jpg"

    classify = call_yolo_classify(weights, source)
    print(classify)
