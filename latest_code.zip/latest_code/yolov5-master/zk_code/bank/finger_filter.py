import torch

a = torch.tensor([[250.99670, 49.78845, 307.39569, 121.78577, 0.80789, 0.00000],
                  [388.44037, 244.67378, 452.27899, 319.63632, 0.80684, 0.00000],
                  [247.14871, 137.07098, 308.43600, 191.10410, 0.77994, 3.00000],
                  [142.50215, 251.37685, 190.39024, 312.21292, 0.76893, 4.00000],
                  # [313.89432, 158.17874, 374.80966, 211.82617, 0.76755, 3.00000],
                  [285.59995, 266.55334, 337.67862, 354.67749, 0.76074, 1.00000],
                  [183.50594, 160.79662, 240.41499, 212.88268, 0.75730, 3.00000],
                  [192.89893, 228.69923, 240.23648, 295.11334, 0.75696, 4.00000],
                  [240.20387, 209.12709, 291.80716, 280.70984, 0.75111, 4.00000],
                  [236.41400, 264.26428, 287.79865, 352.25629, 0.74907, 1.00000],
                  [294.14618, 214.43309, 350.79303, 287.13297, 0.74685, 4.00000],
                  [275.35724, 389.19827, 371.98248, 469.92429, 0.74276, 2.00000],
                  [119.38604, 206.30377, 171.79059, 252.48962, 0.73549, 3.00000],
                  [357.78888, 318.36346, 416.76154, 382.83075, 0.73413, 4.00000],
                  [151.07355, 462.97348, 211.58304, 564.95758, 0.72769, 6.00000],
                  [151.07355, 462.97348, 211.58304, 564.95758, 0.72769, 6.00000],
                  [151.07355, 462.97348, 211.58304, 564.95758, 0.72769, 6.00000],
                  # [192.64220, 455.87344, 288.52100, 575.88672, 0.71891, 5.00000],
                  # [196.09119, 277.21780, 241.62668, 356.67416, 0.71302, 1.00000],
                  [150.44481, 289.40012, 197.86784, 372.38199, 0.69116, 1.00000]])


def filter(box, index, finger):
    """
    各组建议框按照 x1 的值排序，然后进行排除食指、无名指
    :param box: 建议框
    :param index: 过滤关节
    :param finger: 手指
    :return:
    """
    box = box[torch.where(box[:, 5] == finger)]
    box = box[box[:, 0].argsort()][index]
    return box


def finger_filter(det, path=" "):
    """
    需要严格按照 mosaic 数据增强与 onehot 编码顺序进行传参设置
    "D:\PycharmProjects\yolov5-master\runs\train\exp3\train_batch1.jpg"
    "D:\PycharmProjects\yolov5-master\data\zk_bone_age_1016.yaml"
    :param path: 图片完整路径名称
    :param det: 原始预测框数据
    :return: 过滤组合后的新数据
    """

    # ___________ 判断21个关节，7类，及其对应数量，在原始数据 det 上统计 ___________
    # 5  0:DistalPhalanx
    # 4  1:MCP
    # 1  2:MCPFirst
    # 4  3:MiddlePhalanx
    # 5  4:ProximalPhalanx
    # 1  5:Radius
    # 1  6:Ulna

    status = "ok"
    err_msg = ""

    error_num = 0

    DistalPhalanx_0_num = len(det[torch.where(det[:, 5] == 0)])
    if DistalPhalanx_0_num != 5:
        err_msg = err_msg + f"【DistalPhalanx 关节数量错误，正确数量为 5，当前数量为 {DistalPhalanx_0_num};】"
        error_num = error_num + 1

    MCP_1_num = len(det[torch.where(det[:, 5] == 1)])
    if MCP_1_num != 4:
        err_msg = err_msg + f"【MCP 关节数量错误，正确数量为 4，当前数量为 {MCP_1_num};】"
        error_num = error_num + 1

    MCPFirst_2_num = len(det[torch.where(det[:, 5] == 2)])
    if MCPFirst_2_num != 1:
        err_msg = err_msg + f"【MCPFirst 关节数量错误，正确数量为 1，当前数量为 {MCPFirst_2_num};】"
        error_num = error_num + 1

    MiddlePhalanx_3_num = len(det[torch.where(det[:, 5] == 3)])
    if MiddlePhalanx_3_num != 4:
        err_msg = err_msg + f"【MiddlePhalanx 关节数量错误，正确数量为 4，当前数量为 {MiddlePhalanx_3_num};】"
        error_num = error_num + 1

    ProximalPhalanx_4_num = len(det[torch.where(det[:, 5] == 4)])
    if ProximalPhalanx_4_num != 5:
        err_msg = err_msg + f"【ProximalPhalanx 关节数量错误，正确数量为 5，当前数量为 {ProximalPhalanx_4_num};】"
        error_num = error_num + 1

    Radius_5_num = len(det[torch.where(det[:, 5] == 5)])
    if Radius_5_num != 1:
        err_msg = err_msg + f"【Radius 关节数量错误，正确数量为 1，当前数量为 {Radius_5_num};】"
        error_num = error_num + 1

    Ulna_6_num = len(det[torch.where(det[:, 5] == 6)])
    if Ulna_6_num != 1:
        err_msg = err_msg + f"【Ulna 关节数量错误，正确数量为 1，当前数量为 {Ulna_6_num};】"
        error_num = error_num + 1

    if error_num > 0:
        err_msg = err_msg + "关节数量错误，原数据返回;"
        status = "1001"
        return det, status, err_msg  # 关节数量错误，原数据返回

    # ___________ 手指过滤 ___________
    try:
        finger0 = filter(det, [0, 2, 4], 0)
        finger1 = filter(det, [0, 2], 1)
        finger2 = filter(det, [0], 2)
        finger3 = filter(det, [0, 2], 3)
        finger4 = filter(det, [0, 2, 4], 4)
        finger5 = filter(det, [0], 5)
        finger6 = filter(det, [0], 6)

        # ___________ 判断右手 ___________
        # 6:Ulna x1在 5:Radius x1的左边，则判定为左手，正常数据，反之为右手
        finger5_x1 = finger5[0][0]
        finger6_x1 = finger6[0][0]
        if finger6_x1 > finger5_x1:
            err_msg = "图片为右手错误数据，原数据返回"
            status = "1002"
            return det, status, err_msg  # 手指过滤错误，原数据返回

        # 校验通过，数据正确返回
        return torch.cat([finger0, finger1, finger2, finger3, finger4, finger5, finger6], dim=0), \
               status, \
               err_msg

    except Exception as e:
        status = "9999"
        err_msg = "手指过滤错误，原数据返回;" + str(e)
        return det, status, err_msg  # 手指过滤错误，原数据返回


if __name__ == '__main__':
    # print(a)
    # print(finger_filter(a, "pathhhhhh"))
    finger_filter(a)
