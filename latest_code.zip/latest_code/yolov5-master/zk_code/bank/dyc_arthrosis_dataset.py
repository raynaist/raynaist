import os
import random
from shutil import rmtree

import cv2
import numpy as np
from PIL import Image


# 缩放、居中粘贴
def resize_center(img_path, scale_size, save_path=None):
    # 传入的 img_path 为文件路径，则打开文件，否则按照 Image.open 结果处理
    if isinstance(img_path, str) == True:
        img = Image.open(img_path)  # 打开图片
    else:
        img = img_path

    w, h = img.size[0], img.size[1]  # 获取图片的宽高
    max_side = np.maximum(w, h)  # 获取wh中的最大值
    goal_img = Image.new('RGB', (max_side, max_side), color=(0, 0, 0))  # 创造一个黑板图片
    # 将图片贴到目标图片上  max_side==w  or  max_side==h  则有个点为0
    goal_img.paste(img, (int((max_side - w) / 2), int((max_side - h) / 2)))
    new_img = goal_img.resize((scale_size, scale_size))  # 改变图片大小

    if save_path is not None:
        new_img.save(save_path)
    else:
        return new_img


def image_enhancement(file_name, new_file_name):
    """
    调用cv2对图片使用自适应直方图均衡化，并保存到新路径下
    :param file_name: 原始图片路径
    :param new_file_name: 新图片路径
    :return:
    """
    cv_img = cv2.imread(file_name, cv2.IMREAD_GRAYSCALE)  # 灰度图读取
    clahe = cv2.createCLAHE(tileGridSize=(2, 2))  # 自适应直方图均衡化
    clahe_img = clahe.apply(cv_img)
    # cv2.imwrite(new_file_name, clahe_img)  # 保存到新路径下
    clahe_img = Image.fromarray(cv2.cvtColor(clahe_img, cv2.COLOR_BGR2RGB))
    resize_center(clahe_img, IMG_SIZE, new_file_name)


def img_rotate(file_name, img_num=5, angle=30):
    """
    将使用自适应直方图均衡化后的图片应用旋转数据增强
    :param file_name: 自适应直方图均衡化后的图片
    :param img_num: 旋转数据增强的数量
    :param angle: 旋转角度范围 +angle  -angle 之间
    :return:
    """
    img = Image.open(file_name)
    for i in range(img_num):
        rotate = random.randint(-angle, angle)
        new_img = img.rotate(rotate)
        new_file_name = file_name.replace(file_name.split(os.sep)[-1], f"rotate_{i}_{file_name.split(os.sep)[-1]}")
        resize_center(new_img, IMG_SIZE, new_file_name)


def save_data_partition_txt(txt_file_path, file_array):
    """
    保存数据划分txt， train.txt val.txt test.txt
    :param txt_file_path: txt保存路径
    :param file_array: 数据划分结果数组
    """
    with open(txt_file_path, 'w', encoding='utf-8') as f:
        for strs in file_array:
            f.writelines(strs)
            f.writelines("\n")
            f.flush()
    f.close()


def data_partition():
    """
    数据划分按照设置比例划分为 train val test
    """

    for file_foler in os.listdir(OUT_PATH):
        files_array = []
        for root, dirs, files in os.walk(os.path.join(OUT_PATH, file_foler)):
            for file in files:
                file_name = os.path.join(root, file)
                files_array.append(file_name)

        # 随机打乱原始数据
        random.shuffle(files_array)

        # 划分比例
        file_num = len(files_array)
        test_num = int(file_num * TEST_PERCENT)
        # val_num = int(file_num * (TEST_PERCENT + VAL_PERCENT))

        # 划分数据
        test_data = files_array[:test_num]
        # validation_data = files_array[test_num:(test_num + val_num)]
        # train_data = files_array[(test_num + val_num):]
        train_data = files_array[test_num:]

        test_txt_file_name = os.path.join(OUT_PATH, file_foler, "test.txt")
        save_data_partition_txt(test_txt_file_name, test_data)

        # val_txt_file_name = os.path.join(OUT_PATH, file_foler, "val.txt")
        # save_data_partition_txt(val_txt_file_name, validation_data)

        train_txt_file_name = os.path.join(OUT_PATH, file_foler, "train.txt")
        save_data_partition_txt(train_txt_file_name, train_data)


def data_processing():
    # ___________ 文件夹初始化 ___________
    if os.path.exists(OUT_PATH):
        print("数据删除中……")
        rmtree(OUT_PATH)
        print("数据已删除")
    os.makedirs(OUT_PATH)

    # 重建所有子文件夹，数据划分类别文件夹
    for folder in os.listdir(ORIGINAL_IMG_PATH):
        for sub_folder in os.listdir(os.path.join(ORIGINAL_IMG_PATH, folder)):
            new_folder = os.path.join(OUT_PATH, folder, sub_folder)
            os.makedirs(new_folder)

    # ___________ 旋转数据增强，自适应直方图均衡化 ___________

    for root, dirs, files in os.walk(ORIGINAL_IMG_PATH):
        for file in files:
            file_name = os.path.join(root, file)

            new_file_name = file_name.replace(ORIGINAL_IMG_PATH, OUT_PATH)

            # 调用cv2对图片使用自适应直方图均衡化，并保存到新路径下
            image_enhancement(file_name, new_file_name)

            # 调用旋转数据增强
            img_rotate(new_file_name)

    # 数据划分txt
    data_partition()


if __name__ == '__main__':
    # ___________ 参数定义 ___________

    # 原始图片路径
    ORIGINAL_IMG_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\arthrosis"

    # 数据输出文件夹总路径
    OUT_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dyc_dataset_yolo"

    # # 数据划分类别
    # FILE_CATEGORY = ["train", "test", "val"]

    # VAL TEST 占总数据的百分比
    # train = 1 - VAL_PERCENT - TEST_PERCENT
    # VAL_PERCENT = 0.0
    TEST_PERCENT = 0.1

    IMG_SIZE = 224

    # ___________ 数据处理 ___________
    data_processing()
