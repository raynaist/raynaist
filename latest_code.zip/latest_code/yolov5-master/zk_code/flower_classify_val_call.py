import subprocess

if __name__ == '__main__':
    DATASET_PATH = r"D:\PycharmProjects\ai_dataset\flower_photos\flower_yolo"
    val_py = r"D:\PycharmProjects\yolov5-master\classify\val.py"
    weights = r"D:\PycharmProjects\yolov5-master\runs\train-cls\flower\weights\best.pt"
    task = "train"

    train_command = f"python {val_py} --weights {weights} --data {DATASET_PATH} --name flower --exist-ok --task {task}"
    print("\n\n", train_command)

    process = subprocess.Popen(train_command, shell=True)
    process.wait()
