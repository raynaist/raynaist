import os
import subprocess

if __name__ == '__main__':

    # ___________ 训练数据集总路径设置 ___________
    # DATASET_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dataset_yolo"
    DATASET_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dataset_yolo_equalization"

    # ___________ 模型参数设置 ___________
    train_py = r"D:\PycharmProjects\yolov5-master\classify\train.py"
    model = r"D:\PycharmProjects\yolov5-master\yolov5s-cls.pt"
    epochs = 20

    for category in os.listdir(DATASET_PATH):

        # # 测试
        # if category != "DIPFirst":
        #     continue

        # '--exist-ok', action = 'store_true'  这是开关参数，传参为 True，否则默认为False
        data = os.path.join(DATASET_PATH, category)
        name = category

        train_command = f"python {train_py} --model {model} --data {data} --epochs {epochs} --name {name} --exist-ok"
        print("\n\n", train_command)

        process = subprocess.Popen(train_command, shell=True)
        process.wait()
