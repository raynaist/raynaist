import os
import subprocess

if __name__ == '__main__':

    # ___________ 训练数据集总路径设置 ___________
    # DATASET_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dataset_yolo"
    DATASET_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dataset_yolo_equalization"

    # ___________ 模型参数设置 ___________
    val_py = r"D:\PycharmProjects\yolov5-master\classify\val.py"

    for category in os.listdir(DATASET_PATH):
        data = os.path.join(DATASET_PATH, category)
        name = category
        weights = rf"D:\PycharmProjects\yolov5-master\runs\train-cls\{category}\weights\best.pt"
        task = "train"

        train_command = f"python {val_py} --weights {weights} --data {data} --name {name} --exist-ok --task {task}"
        print("\n\n", train_command)

        process = subprocess.Popen(train_command, shell=True)
        process.wait()
