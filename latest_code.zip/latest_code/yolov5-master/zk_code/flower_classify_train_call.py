import subprocess

if __name__ == '__main__':
    DATASET_PATH = r"D:\PycharmProjects\ai_dataset\flower_photos\flower_yolo"
    train_py = r"D:\PycharmProjects\yolov5-master\classify\train.py"
    epochs = 20

    model = r"D:\PycharmProjects\yolov5-master\yolov5s-cls.pt"
    # model = r"D:\PycharmProjects\yolov5-master\yolov5x-cls.pt"
    # model = r"D:\PycharmProjects\yolov5-master\runs\train-cls\flower\weights\best.pt"

    # train_command = f"python {train_py} --model {model} --data {DATASET_PATH} --epochs {epochs} --name flower --exist-ok --pretrained True"
    train_command = f"python {train_py} --model {model} --data {DATASET_PATH} --epochs {epochs} --name flower --exist-ok"
    print("\n\n", train_command)

    process = subprocess.Popen(train_command, shell=True)
    process.wait()
