import os
import random
from shutil import rmtree

from PIL import Image

from zk_code.finger_voc_to_yolo import image_enhancement


def img_rotate(file_name, img_num=5, angle=30):
    """
    将使用自适应直方图均衡化后的图片应用旋转数据增强
    :param file_name: 自适应直方图均衡化后的图片
    :param img_num: 旋转数据增强的数量
    :param angle: 旋转角度范围 +angle  -angle 之间
    :return:
    """
    img = Image.open(file_name)
    for i in range(img_num):
        rotate = random.randint(-angle, angle)
        new_img = img.rotate(rotate)
        new_file_name = file_name.replace(file_name.split(os.sep)[-1], f"rotate_{i}_{file_name.split(os.sep)[-1]}")
        new_img.save(new_file_name)


def data_processing():
    # ___________ 文件夹初始化 ___________
    if os.path.exists(OUT_PATH):
        print("数据删除中……")
        rmtree(OUT_PATH)
        print("数据已删除")
    os.makedirs(OUT_PATH)

    # 重建所有子文件夹，数据划分类别文件夹
    for folder in os.listdir(ORIGINAL_IMG_PATH):
        for _file_category in FILE_CATEGORY:
            for sub_folder in os.listdir(os.path.join(ORIGINAL_IMG_PATH, folder)):
                new_folder = os.path.join(OUT_PATH, folder, _file_category, sub_folder)
                os.makedirs(new_folder)

    # ___________ 数据划分 ___________

    for root, dirs, files in os.walk(ORIGINAL_IMG_PATH):

        file_num = len(files)
        test_num = max(int(file_num * TEST_PERCENT), 1)  # max控制文件夹中至少有一个文件
        val_num = max(int(file_num * (TEST_PERCENT + VAL_PERCENT)), 2)

        divide_num = 0

        random.shuffle(files)
        for file in files:
            file_name = os.path.join(root, file)
            file_name_path = file_name.split(os.sep)

            # 放入test
            if divide_num < test_num:
                new_file_name = os.path.join(OUT_PATH, file_name_path[-3], "test", file_name_path[-2], file_name_path[-1])

            # 放入val
            elif divide_num < val_num:
                new_file_name = os.path.join(OUT_PATH, file_name_path[-3], "val", file_name_path[-2], file_name_path[-1])

            # 放入train
            else:
                new_file_name = os.path.join(OUT_PATH, file_name_path[-3], "train", file_name_path[-2], file_name_path[-1])

            # 调用cv2对图片使用自适应直方图均衡化，并保存到新路径下
            image_enhancement(file_name, new_file_name, (1, 1))

            # 调用旋转数据增强
            img_rotate(new_file_name)

            divide_num = divide_num + 1


if __name__ == '__main__':
    # ___________ 参数定义 ___________

    # 原始图片路径
    ORIGINAL_IMG_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\arthrosis"

    # 数据输出文件夹总路径
    OUT_PATH = r"D:\PycharmProjects\ai_dataset\bone_age_arthrosis\dataset_yolo"

    # 数据划分类别
    FILE_CATEGORY = ["train", "test", "val"]

    # VAL TEST 占总数据的百分比
    # train = 1 - VAL_PERCENT - TEST_PERCENT
    VAL_PERCENT = 0.10
    TEST_PERCENT = 0.05

    # ___________ 数据处理 ___________
    data_processing()
