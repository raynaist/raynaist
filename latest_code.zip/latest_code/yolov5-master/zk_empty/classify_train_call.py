import subprocess

if __name__ == '__main__':
    py_exe = r"C:\Users\ghome\AppData\Local\Programs\Python\Python38\python.exe"
    py = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\classify\train.py"

    data = r"D:\zhangkun_20240407\all_dataset\empty\empty_store_yolo"
    project = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_empty\runs\train"
    epochs = 100
    name = "empty"

    model = r"D:\PycharmProjects\yolov5-master\yolov5l-cls.pt"
    # model = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_empty\runs\train\empty\weights\best.pt"

    train_command = f"{py_exe} {py} --model {model} --project {project} --data {data} --epochs {epochs} --name {name} --exist-ok"

    print("\n\n", train_command)
    process = subprocess.Popen(train_command, shell=True)
    process.wait()
