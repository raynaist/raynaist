import os
import time

import cv2

# ___________________ 切图查看 ___________________
from zk_empty.make_classify_dataset import rectangular_clipping
rectangular_clipping(r"D:\zhangkun_20240407\zk_temp\empty_original_data")
exit()

# ___________________ 标注 ___________________


img_path = r"D:\zhangkun_20240407\zk_temp\empty_original_data"
img_num = 0

# [[x1, y1], [x2, y2], [x3, y3]], [x4, y4]  顶点顺序是顺时针方向

for file_name in os.listdir(img_path):

    _file_name = os.path.join(img_path, file_name)
    if os.path.isdir(_file_name):
        continue

    print("Image name:", _file_name)

    image = cv2.imread(_file_name)
    cv2.namedWindow("win")
    clicked_point = ""
    clicked_num = 0


    def default_callbackFunc(event, x, y, flags, param):
        global clicked_point
        global clicked_num
        global img_num
        if event == cv2.EVENT_LBUTTONDOWN:
            clicked_point = f"{clicked_point} {x} {y}"
            print("(x,y)=({},{})".format(x, y))
            print("clicked_point", clicked_point)
            clicked_num = clicked_num + 1

            if clicked_num == 8:
                clicked_str = clicked_point.strip()
                clicked_str = clicked_str.replace(" ", "_")
                print("clicked_str", clicked_str)
                cv2.imwrite(os.path.join(img_path, f"{clicked_str}_{img_num}.jpg"), image)
                os.remove(_file_name)
                img_num = img_num + 1
                cv2.destroyWindow('win')


    cv2.setMouseCallback("win", default_callbackFunc)
    cv2.imshow("win", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    time.sleep(3)
