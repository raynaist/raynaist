import os
import random
import shutil

import cv2
import numpy as np
from PIL import Image
from tqdm import tqdm

from zk_zszn.voc_to_yolo_major_category_20240415 import load_xml, ImageAugment


def data_augmentation(folder_path):
    ia = ImageAugment()

    for file in tqdm(os.listdir(folder_path), desc=f"ImageAugment Processing {folder_path}"):
        image_path = os.path.join(folder_path, file)
        image = cv2.imread(image_path)

        _file_name = os.path.splitext(file)[0]
        _image_ext = os.path.splitext(file)[1]

        # ___________ 图片处理 ___________

        # 调整图像的亮度和对比度
        adjusted_image = ia.adjust_brightness_contrast(image)
        new_image_path = image_path.replace(_image_ext, "_adj.jpg")
        cv2.imwrite(new_image_path, adjusted_image)

        # # 图像水平翻转
        # flip_h_image = cv2.flip(image, 1)
        # new_image_path = image_path.replace(_image_ext, "_flh.jpg")
        # cv2.imwrite(new_image_path, flip_h_image)
        #
        # # 图像水平翻转 调整图像的亮度和对比度
        # flip_h_image = cv2.flip(adjusted_image, 1)
        # new_image_path = image_path.replace(_image_ext, "_fla.jpg")
        # cv2.imwrite(new_image_path, flip_h_image)

        # # 添加椒盐噪声
        # salt_image = ia.salt_and_pepper_noise(image)
        # new_image_path = image_path.replace(_image_ext, "_sal.jpg")
        # cv2.imwrite(new_image_path, salt_image)

        # 改变颜色
        color_distorted_image = ia.color_distortion(image)
        new_image_path = image_path.replace(_image_ext, "_col.jpg")
        cv2.imwrite(new_image_path, color_distorted_image)

        # 加强或者变暗 100
        enhance_image = ia.enhance_reduce(image, 100)
        new_image_path = image_path.replace(_image_ext, "_enh.jpg")
        cv2.imwrite(new_image_path, enhance_image)

        # 加强或者变暗 -100
        reduce_image = ia.enhance_reduce(image, -100)
        new_image_path = image_path.replace(_image_ext, "_red.jpg")
        cv2.imwrite(new_image_path, reduce_image)

        # 自适应直方图均衡化
        clahe_image = ia.clahe_image(image)
        new_image_path = image_path.replace(_image_ext, "_cla.jpg")
        cv2.imwrite(new_image_path, clahe_image)

        # 油画与非真实感渲染
        detailEnhance_image = ia.detailEnhance_image(image)
        new_image_path = image_path.replace(_image_ext, "_det.jpg")
        cv2.imwrite(new_image_path, detailEnhance_image)


def data_partition():
    # 重建所有子文件夹，数据划分类别文件夹
    for folder in os.listdir(os.path.join(OUT_PATH, "train")):
        for file_category in ["test", "val"]:
            new_folder = os.path.join(OUT_PATH, file_category, folder)
            os.makedirs(new_folder)

    # ___________ 从 train 文件夹下按设定比例划分到 test val 中 ___________

    for root, dirs, files in os.walk(OUT_PATH):
        if len(files) > 0:

            file_num = len(files)
            test_num = int(file_num * TEST_PERCENT)
            val_num = int(file_num * (TEST_PERCENT + VAL_PERCENT))

            move_num = 0
            random.shuffle(files)
            for file in files:
                file_name = os.path.join(root, file)

                if move_num < test_num:
                    new_file_name = file_name.replace("\\train\\", "\\test\\")
                    shutil.move(file_name, new_file_name)

                elif move_num < val_num:
                    new_file_name = file_name.replace("\\train\\", "\\val\\")
                    shutil.move(file_name, new_file_name)

                else:
                    break

                move_num = move_num + 1


def trapezoid(image, point):
    """
    矩形区域裁剪
    """

    img = image.copy()
    pts = np.array(point, np.int32)  # 定义梯形区域的四个顶点坐标
    pts = pts.reshape((-1, 1, 2))
    mask = np.zeros_like(img)  # 创建掩码
    cv2.fillPoly(mask, [pts], (255, 255, 255))
    result = cv2.bitwise_and(img, mask)  # 应用掩码到原始图片上
    x, y, w, h = cv2.boundingRect(pts)  # 获取裁剪区域的矩形边界
    cropped_result = result[y:y + h, x:x + w]  # 裁剪结果图片
    return cropped_result


def rectangular_clipping(folder_path):
    """
    [[x1, y1], [x2, y2], [x3, y3]], [x4, y4] 顶点顺序是顺时针方向

    Args:
        folder_path:

    Returns:

    """

    for file_name in tqdm(os.listdir(folder_path), desc=f"rectangular clipping {folder_path}"):
        # ____________ 从文件名中读取裁剪区域 ____________

        points = os.path.splitext(file_name)[0].split("_")
        points = points[:16]

        # 将字符串列表转换为整数列表
        points_list = [int(x) for x in points]

        # 分割整数列表成左右两个部分
        l_point = [[points_list[i], points_list[i + 1]] for i in range(0, int(len(points_list) / 2), 2)]
        r_point = [[points_list[i], points_list[i + 1]] for i in range(8, len(points_list), 2)]

        # ____________ 处理图片 ____________

        file_path = os.path.join(folder_path, file_name)

        # 读取原始图片
        image = cv2.imread(file_path)
        # im_h, im_w, im_c = image.shape

        l_result = trapezoid(image, l_point)
        r_result = trapezoid(image, r_point)

        # 确保两张图片的高度相同，可以根据需要调整大小
        height = min(l_result.shape[0], r_result.shape[0])
        l_result = l_result[:height]
        r_result = r_result[:height]

        # 水平拼接图片
        result = cv2.hconcat([l_result, r_result])

        # 覆盖原图
        cv2.imwrite(file_path, result)


def data_processing():
    # ___________ 文件夹初始化 ___________
    if os.path.exists(OUT_PATH):
        print("数据删除中……")
        shutil.rmtree(OUT_PATH)
        print("数据已删除")
    os.makedirs(OUT_PATH)
    os.makedirs(OUT_EMPTY_PATH)
    os.makedirs(OUT_NOT_EMPTY_PATH)

    # ___________ 加载xml循环处理图片，根据xml读取图片 ___________

    object_box, class_dir, all_class_dir = load_xml(ANNOTATIONS_PATH, ORIGINAL_IMG_PATH)

    if TEST_MOD == True:
        object_box = random.sample(object_box, TEST_NUM)

    original_data = os.listdir(EMPTY_ORIGINAL_DATA)

    n = 0

    for obj_str in object_box:
        try:

            obj_array = obj_str.split()
            file_name = obj_array[0]

            # 标签框处理
            box_str = obj_array[1:]
            box_array = [box_str[i:i + 5] for i in range(0, len(box_str), 5)]
            original_image = Image.open(file_name)

            _convert_box = []
            for box in box_array:
                # class_name = box[0]
                xmin = int(float(box[1]))
                ymin = int(float(box[2]))
                xmax = int(float(box[3]))
                ymax = int(float(box[4]))

                random.shuffle(original_data)
                _file_name = original_data[0]

                target_image = Image.open(os.path.join(EMPTY_ORIGINAL_DATA, _file_name))

                cropped_image = original_image.crop((xmin, ymin, xmax, ymax))

                # 随机缩放裁剪后的图片
                random_scale = random.uniform(RANDOM_SCALE_MIN, RANDOM_SCALE_MAX)  # 裁剪出来的图片缩放到目标图片的占比

                min_target_image = min(target_image.width, target_image.height) * random_scale

                scaled_width = int(min_target_image)
                scaled_height = int(min_target_image / cropped_image.width * cropped_image.height)

                scaled_image = cropped_image.resize((scaled_width, scaled_height))

                # --------------------------------------------

                points = os.path.splitext(_file_name)[0].split("_")
                points = points[:16]
                points_list = [int(x) for x in points]  # 将字符串列表转换为整数列表

                # 在目标图片上随机选择一个位置粘贴缩放后的图片

                # 将裁剪后的图片粘贴在左边
                if random.random() > 0.5:

                    point_x = [points_list[i] for i in range(0, int(len(points_list) / 2), 2)]
                    point_y = [points_list[i + 1] for i in range(0, int(len(points_list) / 2), 2)]

                    x1 = point_x[0]
                    x2 = point_x[1]
                    x3 = point_x[2]
                    x4 = point_x[3]

                    y1 = point_y[0]
                    y2 = point_y[1]
                    y3 = point_y[2]
                    y4 = point_y[3]

                    paste_x = random.randint(max(x1, x4), min(x2, x3))
                    paste_x = max((paste_x - scaled_image.width), max(x1, x4))

                    paste_y = random.randint(max(y1, y2), min(y3, y4))
                    paste_y = max((paste_y - scaled_image.height), max(y1, y2))

                # 将裁剪后的图片粘贴在右边
                else:

                    point_x = [points_list[i] for i in range(8, len(points_list), 2)]
                    point_y = [points_list[i + 1] for i in range(8, len(points_list), 2)]

                    x1 = point_x[0]
                    x2 = point_x[1]
                    x3 = point_x[2]
                    x4 = point_x[3]

                    y1 = point_y[0]
                    y2 = point_y[1]
                    y3 = point_y[2]
                    y4 = point_y[3]

                    paste_x = random.randint(max(x1, x4), min(x2, x3))
                    paste_x = max((paste_x - scaled_image.width), max(x1, x4))

                    paste_y = random.randint(max(y1, y2), min(y3, y4))
                    paste_y = max((paste_y - scaled_image.height), max(y1, y2))

                # --------------------------------------------

                target_image.paste(scaled_image, (paste_x, paste_y))
                target_image.save(os.path.join(OUT_NOT_EMPTY_PATH, f'{os.path.splitext(_file_name)[0]}_{n}.jpg'))

                # 复制原图
                shutil.copy2(os.path.join(EMPTY_ORIGINAL_DATA, _file_name), os.path.join(OUT_EMPTY_PATH, f'{os.path.splitext(_file_name)[0]}_{n}.jpg'))

                n = n + 1

        except FileNotFoundError as e:
            print(e)
            continue

    # 数据增强
    data_augmentation(OUT_EMPTY_PATH)
    data_augmentation(OUT_NOT_EMPTY_PATH)

    # 裁剪
    rectangular_clipping(OUT_EMPTY_PATH)
    rectangular_clipping(OUT_NOT_EMPTY_PATH)

    # 数据划分
    data_partition()


if __name__ == '__main__':
    # ___________ 文件夹路径 ___________

    ANNOTATIONS_PATH = r"D:\zhangkun_20240407\all_dataset\zk_arrange_voc\xml"  # 原始标注XML路径
    ORIGINAL_IMG_PATH = r"D:\zhangkun_20240407\all_dataset\zk_arrange_voc\images"  # 原始图片路径
    EMPTY_ORIGINAL_DATA = r"D:\zhangkun_20240407\all_dataset\empty\empty_original_data"

    # 数据输出文件夹总路径
    OUT_PATH = r"D:\zhangkun_20240407\all_dataset\empty\empty_store_yolo"
    OUT_EMPTY_PATH = os.path.join(OUT_PATH, "train", "empty")
    OUT_NOT_EMPTY_PATH = os.path.join(OUT_PATH, "train", "not_empty")

    # ___________ 参数设置 ___________

    TEST_MOD = True  # 是否打开测试模式，打开时只生成部分测试数据
    TEST_NUM = 500  # 测试数量
    FIXED_RANDOM = False  # 将随机数固定

    # VAL TEST 占总数据的百分比  train = 1 - VAL_PERCENT - TEST_PERCENT
    VAL_PERCENT = 0.10
    TEST_PERCENT = 0.15

    # 图片缩放占比
    RANDOM_SCALE_MIN = 0.15
    RANDOM_SCALE_MAX = 0.40

    if TEST_MOD and FIXED_RANDOM:
        random.seed(999)

    # ___________ 数据处理 ___________

    data_processing()
