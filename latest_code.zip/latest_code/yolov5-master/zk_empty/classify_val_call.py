import subprocess

if __name__ == '__main__':
    python_exe = r"C:\Users\ghome\AppData\Local\Programs\Python\Python38\python.exe"
    data = r"D:\zhangkun_20240407\all_dataset\empty\empty_store_yolo"
    val_py = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\classify\val.py"
    weights = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_empty\runs\train\empty\weights\best.pt"
    project = r"D:\zhangkun_20240407\pycharm_code_20240407\yolov5-master\zk_empty\runs\detect"
    task = "test"

    train_command = f"{python_exe} {val_py} --weights {weights} --data {data} --project {project} --name empty --exist-ok --task {task}"
    print("\n\n", train_command)

    process = subprocess.Popen(train_command, shell=True)
    process.wait()
