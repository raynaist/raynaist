import os
import random
xy_you={
    'array1':[3700,1150],
    'array2':[3700,638],
    'array3':[3700,125],
    'array4':[3280,1150],
    'array5':[3280,638],
    'array6':[3280,125]
}


xy_zuo={
    'array1':[2404,1150],
    'array2':[2404,638],
    'array3':[2404,125],
    'array4':[1969,1150],
    'array5':[1969,638],
    'array6':[1969,125]
}

xy_one={
    '101':[1221,125],
    '201':[1221,638],
    '301':[1221,1150]
}
dianwei = ['101','201','301']
i = random.choice(dianwei)
print(xy_one[i])