import json
import time
import requests

# 嗯传
Datajson = {"weight":"200","order_id":"7bfskch58796","goods_name":'废纸箱',"fault_tolerant":False}
Datajson = json.dumps(Datajson,sort_keys=False, indent=4, separators=(',', ': '))

start_time = time.time()
r = requests.post("http://127.0.0.1:8026/model/StorageDetection", data=Datajson)

data = r.json()
print('time:', (time.time() - start_time))
print(json.loads(r.text))
print(data)