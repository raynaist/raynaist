# import cv2
# import numpy as np

# left_camera_matrix = np.array([[885.43400, 0., 674.11756],
#                                [0., 887.57674, 517.38525],
#                                [0., 0., 1.]])
# left_distortion = np.array([[-0.38471, 0.12847, 0.00209, 0.00214, 0.00000]])

# right_camera_matrix = np.array([[888.35950, 0., 659.60319],
#                                 [0., 892.99743, 517.80199],
#                                 [0., 0., 1.]])
# right_distortion = np.array([[-0.37909, 0.12087, 0.00260, 0.00367, 0.00000]])

# om = np.array([-0.00009, 0.02300, -0.00372])
# R = cv2.Rodrigues(om)[0]
# T = np.array([-614.81702, 12.58066, 38.93339])

# size = (1280, 960)

# R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
#                                                                   right_camera_matrix, right_distortion, size, R,
#                                                                   T)

# left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
# right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)

import cv2
import numpy as np

left_camera_matrix = np.array([[259.9967951438725     ,0.249788539814231 ,165.25124832706365 ],
 [  0.                ,259.57990128600693  ,127.45705126413229 ],
 [  0.                  ,0.                  ,1.               ]])
left_distortion = np.array([[-0.018258167644757  ,0.113230405646237 ,-0.000220806072686,
   0.002071896564123  ,0.               ]])



right_camera_matrix = np.array([[260.5575167539941     ,0.126364680463788 ,160.8044903583893  ],
 [  0.                ,260.15883406439764  ,131.90701701478378 ],
 [  0.                  ,0.                  ,1.               ]])
right_distortion = np.array([[-0.021132132029894  ,0.099100937652974 ,-0.000790353264234
   ,0.001836357392985  ,0.               ]])





R = np.matrix([[ 0.999973651261206  ,0.000295485074426 ,-0.007253238718233],
 [-0.000230581719544  ,0.99995994467169   ,0.008947395389756],
 [ 0.007255592009168 ,-0.008945487172916  ,0.99993366512176 ]])

T = np.array([-56.312381609850334   ,0.195711087262715   ,0.237024786826931])

size = (320, 240) # 图像尺寸
#size = (1280, 960)

# 进行立体更正
R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(left_camera_matrix, left_distortion,
                                                                  right_camera_matrix, right_distortion, size, R,
                                                                  T)
# 计算更正map
left_map1, left_map2 = cv2.initUndistortRectifyMap(left_camera_matrix, left_distortion, R1, P1, size, cv2.CV_16SC2)
right_map1, right_map2 = cv2.initUndistortRectifyMap(right_camera_matrix, right_distortion, R2, P2, size, cv2.CV_16SC2)