import os
import cv2
import time
import random
import logging
import subprocess
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, Request, HTTPException, Depends
from PyCameraList.camera_device import list_video_devices

import xls
import xls_2 as xls2
import camera_config
from xy_map import *
from calculate_volume import calculate_volume_rate

############ 参数 ############
# 定义左边相机
desired_value = 'WN CAMERA1080 TB'

# 定义右边相机
desired_value1 = 'WN CAMERA1080 TB'

# 最大重新尝试
max_attempts = 4


############ output_log ############
def output_log():
    """
    自动生成日志文件
  
    """
    # 项目路径
    prj_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
    # 在项目路径下创建一个log文件夹, 拼接成路径格式
    log_path = os.path.join(prj_path, 'log')
    # 在log文件夹下再创建一个以当前日期命名的文件夹
    log_date_path = os.path.join(log_path, time.strftime('%Y_%m_%d', time.localtime(time.time())))
    current_time = time.strftime('%Y_%m_%d_%H_%M', time.localtime(time.time()))  # 返回当前时间
    # 在时间文件夹下创建一个文件，后缀是.log.
    log_name = os.path.join(log_date_path, current_time + '.log')
    isExists = os.path.exists(log_date_path)  # 判断该目录是否存在
    print(prj_path, log_path, log_date_path, log_name)
    # 创建一个logger(初始化logger)
    log1 = logging.getLogger()
    log1.setLevel(logging.DEBUG)
    if not isExists:
        os.makedirs(log_date_path)
        print(log_path + log_date_path + "目录创建成功")
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(log_path + "目录 %s 已存在" % log_date_path)
    try:
        # 创建一个handler，用于写入日志文件
        current_time = time.strftime('%Y_%m_%d_%H_%M', time.localtime(time.time()))  # 返回当前时间
        log_name = os.path.join(log_date_path, current_time + '.log')

        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.INFO)

        # 定义handler的输出格式
        formatter = logging.Formatter('[%(asctime)s] - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        # 给logger添加handler
        log1.addHandler(fh)
    except Exception as e:
        print("输出日志失败！ %s" % e)


############ output_img ############
def output_imgs(orderID, img):
    """
    保存图片函数，推理结束后按照需求保存图片，例如：imgs/年/月/orderID/time_1.jpg
  
    """
    signal = 'depth'
    # 项目路径
    prj_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
    # 在项目路径下创建一个log文件夹, 拼接成路径格式
    imgs_path = os.path.join(prj_path, 'imgs')
    # 在log文件夹下再创建一个以当前日期命名的文件夹
    year_path = os.path.join(imgs_path, time.strftime('%Y', time.localtime(time.time())))
    month_path = os.path.join(year_path, time.strftime('%m', time.localtime(time.time())))
    orderID_path = os.path.join(month_path, orderID)

    current_time = time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime(time.time()))  # 返回当前时间
    # 在时间文件夹下创建一个文件，后缀是.log.
    img_name = os.path.join(orderID_path, current_time + '_' + signal + '.jpg')
    isExists = os.path.exists(orderID_path)  # 判断该目录是否存在
    print(prj_path, orderID_path, img_name)
    if not isExists:
        os.makedirs(orderID_path)
        print(orderID_path + "目录创建成功")
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(orderID_path + "目录 %s 已存在" % orderID_path)
    try:
        # 创建一个handler，用于写入日志文件
        cv2.imwrite(img_name, img)
    except Exception as e:
        print("输出图片失败！ %s" % e)

    # 返回原图文件名和图片数据
    return img_name


def Binocular_camera(videoID, cap):
    ####处理双目图像
    _, frame = cap.read()
    frame_left = frame[0:480, 0:640]
    frame_right = frame[0:480, 640:1280]  # 分割双目图像
    # cap.release()
    imgL = cv2.cvtColor(frame_left, cv2.COLOR_BGR2GRAY)
    imgR = cv2.cvtColor(frame_right, cv2.COLOR_BGR2GRAY)

    if videoID == 'key1':
        img1_rectified = cv2.remap(imgL, xls.left_map1, xls.left_map2, cv2.INTER_LINEAR)
        img2_rectified = cv2.remap(imgR, xls.right_map1, xls.right_map2, cv2.INTER_LINEAR)  # 依据MATLAB测量数据重建无畸变图片
    else:
        img1_rectified = cv2.remap(imgL, xls2.left_map1, xls2.left_map2, cv2.INTER_LINEAR)
        img2_rectified = cv2.remap(imgR, xls2.right_map1, xls2.right_map2, cv2.INTER_LINEAR)  # 依据MATLAB测量数据重建无畸变图片

    stereo = cv2.StereoSGBM_create(minDisparity=0, numDisparities=numberOfDisparities, blockSize=5,
                                   P1=8 * 1 * 9 * 9, P2=32 * 1 * 9 * 9, disp12MaxDiff=200, uniquenessRatio=10,
                                   speckleWindowSize=60, speckleRange=2, mode=cv2.STEREO_SGBM_MODE_SGBM)

    disparity = stereo.compute(img1_rectified, img2_rectified)

    # disp = cv2.normalize(disparity, disparity, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)  #归一化函数算法

    # threeD = cv2.reprojectImageTo3D(disparity, camera_config.Q, handleMissingValues=True)
    # threeD = threeD * 16

    #### 滤波过程
    right_matcher = cv2.ximgproc.createRightMatcher(stereo)
    # right_matcher = stereo

    left_disp = disparity
    right_disp = right_matcher.compute(img2_rectified, img1_rectified)

    # 创建 WLS 滤波器
    wls_filter = cv2.ximgproc.createDisparityWLSFilter(stereo)
    # 设置参数
    wls_filter.setLambda(8000)
    wls_filter.setSigmaColor(1)

    # 应用 WLS 滤波器
    filtered_disparity = wls_filter.filter(disparity, img1_rectified, disparity_map_right=right_disp)
    disp22 = cv2.normalize(filtered_disparity, filtered_disparity, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX,
                           dtype=cv2.CV_8U)
    threeD_wls = cv2.reprojectImageTo3D(filtered_disparity, camera_config.Q, handleMissingValues=True)
    threeD_wls = threeD_wls * 16

    return threeD_wls, disp22, frame_left


# StereoSGBM参数
numberOfDisparities = ((640 // 8) + 15) & -16

print('正在加载相机，请稍后')

# 定义全局变量
app = FastAPI()
# 添加CORS中间件
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

cameras = list_video_devices()

# key1 you , key zuo
matching_keys = [key for key, value in dict(cameras).items() if value == desired_value]
# 输出匹配的键
for key in matching_keys:
    print(key)

matching_keys1 = [key for key, value in dict(cameras).items() if value == desired_value1]
# 输出匹配的键
for key1 in matching_keys1:
    print(key1)

# 加载右边相机
app.state.cap1 = cv2.VideoCapture(key1)
app.state.cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
app.state.cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
app.state.cap1.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))

# 加载左边相机
app.state.cap2 = cv2.VideoCapture(key)
app.state.cap2.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
app.state.cap2.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
app.state.cap2.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))

print('加载完毕')


# 定义路由
@app.route("/model/StorageDetection", methods=['POST', 'GET'])
async def get_frame(request: Request):
    output_log()
    # 使用nvidia-smi命令获取GPU信息
    gpu_result = subprocess.check_output(['nvidia-smi', '--query-gpu=utilization.gpu', '--format=csv,noheader,nounits'])
    # 将结果解码为字符串并删除换行符
    gpu_usage = gpu_result.decode('utf-8').strip()
    # 打印GPU使用率
    print(f"GPU Usage: {gpu_usage}%", type(gpu_usage))
    # 解析接收json
    data_json = await request.json()
    # 将收到的消息记录在log中
    logging.info(f"接收到新请求：{data_json}")
    # 收到的东西
    weight = data_json['weight']
    orderID = data_json['order_id']
    goods_name = data_json['goods_name']
    fault_tolerant = data_json['fault_tolerant']
    # 定义返回json框架
    resultdata = {"droppointx": None, "droppointy": None, "lift": None, "clear": False}

    for _ in range(max_attempts):
        try:
            cap1 = app.state.cap1
            # 定义右边摄像头ID
            videoID = 'key1'
            threeD_wls, disp, frame1 = Binocular_camera(videoID, app.state.cap1)
            # 误差修正
            threeD_wls = threeD_wls + 1100
            # 定义区域的左上角坐标、宽和高
            top_left_corner = (150, 120)
            region_width = 440
            region_height = 320
            # 计算容积率
            drop_point, drop_tai = calculate_volume_rate(threeD_wls, frame1, top_left_corner, region_width,
                                                         region_height)
            print("容积率:", drop_point)
            if drop_point != None:
                resultdata['droppointx'] = xy_you[drop_point][0]
                resultdata['droppointy'] = xy_you[drop_point][1]
            resultdata['lift'] = drop_tai
            # 保存图片
            orderID_path = output_imgs(orderID, frame1)
            results = {"code": 200, "msg": "OK", "Data": resultdata}
        except Exception as e:
            drop_point = None
            results = {"code": 5001, "msg": "右边相机连接不上", "Data": resultdata}
            logging.info(f"右边相机连接不上:{e}")

        if drop_point == None:
            try:
                cap2 = app.state.cap2
                # 定义左边摄像头ID
                videoID = 'key'
                threeD_wls, disp, frame1 = Binocular_camera(videoID, app.state.cap2)
                print('切换到第二台相机')
                # 误差修正
                threeD_wls = threeD_wls + 900
                # 定义区域的左上角坐标、宽和高
                top_left_corner = (160, 100)
                region_width = 440
                region_height = 330
                # 计算容积率
                drop_point, drop_tai = calculate_volume_rate(threeD_wls, frame1, top_left_corner, region_width,
                                                             region_height)
                print("容积率:", drop_point)
                if drop_point != None:
                    resultdata['droppointx'] = xy_zuo[drop_point][0]
                    resultdata['droppointy'] = xy_zuo[drop_point][1]
                resultdata['lift'] = drop_tai
                # 保存图片
                orderID_path = output_imgs(orderID, frame1)
                results = {"code": 200, "msg": "OK", "Data": resultdata}
            except Exception as e:
                results = {"code": 5001, "msg": "左边相机连接不上", "Data": resultdata}
                logging.info(f"左边相机连接不上:{e}")

        if drop_point != None:
            break

    # 如果投的是塑料瓶
    if goods_name == '塑料瓶' or goods_name == '易拉罐':
        dianwei = ['101', '201', '301']
        i = random.choice(dianwei)
        resultdata['droppointx'] = xy_one[i][0]
        resultdata['droppointy'] = xy_one[i][1]
        resultdata['lift'] = False
        results = {"code": 200, "msg": "OK", "Data": resultdata}

    # 如果投的是旧衣物
    if goods_name == '旧衣物':
        jiuyiwu_dianwei = [125, 125]
        resultdata['droppointx'] = jiuyiwu_dianwei[0]
        resultdata['droppointy'] = jiuyiwu_dianwei[1]
        resultdata['lift'] = False
        results = {"code": 200, "msg": "OK", "Data": resultdata}

    # 混合
    if fault_tolerant == True:
        # [101,1189]
        hunhe_dianwei = [125, 1150]
        resultdata['droppointx'] = hunhe_dianwei[0]
        resultdata['droppointy'] = hunhe_dianwei[1]
        resultdata['lift'] = False
        results = {"code": 200, "msg": "OK", "Data": resultdata}

    logging.info(f"返回结果如下:{results}")
    return JSONResponse(content=results)


def app_run():
    """
    启动服务
    """
    print('开始启动接口')
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8026)


if __name__ == "__main__":
    app_run()
