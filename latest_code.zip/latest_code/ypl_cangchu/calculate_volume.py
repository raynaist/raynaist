# 导入numpy库
import numpy as np
import cv2

# 定义一个函数，用来判断一个二维数组中大于1200的值的比例是否大于50%
def space_rate(array,Midpoint_value,full_value):
    total_count = array.size
    above_1200_count = np.count_nonzero(array >= Midpoint_value)
    between_900_1200_count = np.count_nonzero((array >= full_value) & (array < Midpoint_value))
    below_900_count = np.count_nonzero(array < full_value)

    above_1200_ratio = above_1200_count / total_count
    between_900_1200_ratio = between_900_1200_count / total_count
    below_900_ratio = below_900_count / total_count

    return [above_1200_ratio, between_900_1200_ratio, below_900_ratio]

# 绘制外接矩形框和标记
def draw_rectangle(image, rect, label):
    cv2.rectangle(image, (rect[0], rect[1]), (rect[0] + rect[2], rect[1] + rect[3]), (0, 0, 255), 2)
    cv2.putText(image, str(label), (rect[0] + rect[2] // 2, rect[1] + rect[3] // 2),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)

def draw_xy(depth_map,top_left,height,width):
    # 创建深拷贝以免修改原图
    image_with_rectangles = depth_map.copy()

    # 绘制数组1的外接矩形框和标记
    draw_rectangle(image_with_rectangles, (top_left[0], top_left[1] + int(1/2*height), int(1/3*width), int(1/2*height)), 1)

    # 绘制数组2的外接矩形框和标记
    draw_rectangle(image_with_rectangles, (top_left[0] + int(1/3*width), top_left[1] + int(1/2*height), int(1/3*width), int(1/2*height)), 2)

    # 绘制数组3的外接矩形框和标记
    draw_rectangle(image_with_rectangles, (top_left[0] + int(2/3*width), top_left[1] + int(1/2*height), int(1/3*width), int(1/2*height)), 3)

    # 绘制数组4的外接矩形框和标记
    draw_rectangle(image_with_rectangles, (top_left[0], top_left[1], int(1/3*width), int(1/2*height)), 4)

    # 绘制数组5的外接矩形框和标记
    draw_rectangle(image_with_rectangles, (top_left[0] + int(1/3*width), top_left[1], int(1/3*width), int(1/2*height)), 5)

    # 绘制数组6的外接矩形框和标记
    draw_rectangle(image_with_rectangles, (top_left[0] + int(2/3*width), top_left[1], int(1/3*width), int(1/2*height)), 6)

    # 显示图像
    cv2.imwrite('./1.jpg',image_with_rectangles)
    #cv2.imshow("Image with Rectangles", image_with_rectangles)
    #cv2.waitKey(0)
    #cv2.destroyAllWindows()

def calculate_volume_rate(depth_map,imgL, top_left, width, height, Midpoint_value=1200, full_value=900):

    # # 定义假数据
    # # 定义六个二维数组，使用numpy.array()函数
    # array1 = np.array([[800, 1100, 1200], [1200, 1400, 1500], [1600, 1700, 1800]])
    # array2 = np.array([[900, 950, 1000], [1050, 1100, 1150], [1200, 1250, 1300]])
    # array3 = np.array([[800, 850, 900], [950, 1000, 1050], [1100, 1150, 1200]])
    # #array4 = np.array([[700, 750, 800], [850, 900, 950], [1000, 1050, 1100]])
    # #array5 = np.array([[600, 650, 700], [750, 800, 850], [900, 950, 1000]])
    # #array6 = np.array([[500, 550, 600], [650, 700, 750], [800, 850, 900]])
    # array4 = np.random.randint(900, 1300, size=(3, 3))
    # array5 = np.random.randint(900, 1300, size=(3, 3))
    # array6 = np.random.randint(900, 1300, size=(3, 3))

    #array1 = depth_map[top_left[1]+int(2/3*height):top_left[1]+height, top_left[0]+int(width/2):top_left[0]+width, 2]
    #array2 = depth_map[top_left[1]+int(1/3*height):top_left[1]+int(2/3*height), top_left[0]+int(width/2):top_left[0]+width, 2]
    #array3 = depth_map[top_left[1]:top_left[1]+int(1/3*height), top_left[0]+int(width/2):top_left[0]+width, 2]
    #array4 = depth_map[top_left[1]+int(2/3*height):top_left[1]+height, top_left[0]:top_left[0]+int(width/2), 2]
    #array5 = depth_map[top_left[1]+int(1/3*height):top_left[1]+int(2/3*height), top_left[0]:top_left[0]+int(width/2), 2]
    #array6 = depth_map[top_left[1]:top_left[1]+int(1/3*height), top_left[0]:top_left[0]+int(width/2), 2]
    # 大区域
    # regionA = depth_map[top_left[1]:top_left[1]+height, top_left[0]+int(width/2):top_left[0]+width, 2]
    # regionB = depth_map[top_left[1]:top_left[1]+height, top_left[0]:top_left[0]+int(width/2), 2]

    array1 = depth_map[top_left[1]+int(1/2*height):top_left[1]+height, top_left[0]:top_left[0]+int(1/3*width), 2] 
    array2 = depth_map[top_left[1]+int(1/2*height):top_left[1]+height, top_left[0]+int(1/3*width):top_left[0]+int(2/3*width), 2]
    array3 = depth_map[top_left[1]+int(1/2*height):top_left[1]+height, top_left[0]+int(2/3*width):top_left[0]+width, 2]
    array4 = depth_map[top_left[1]:top_left[1]+int(1/2*height), top_left[0]:top_left[0]+int(1/3*width), 2]
    array5 = depth_map[top_left[1]:top_left[1]+int(1/2*height), top_left[0]+int(1/3*width):top_left[0]+int(2/3*width), 2]
    array6 = depth_map[top_left[1]:top_left[1]+int(1/2*height), top_left[0]+int(2/3*width):top_left[0]+width, 2]

    #print('检测区域尺寸',array1.shape,array2.shape,array3.shape,array4.shape,array5.shape,array6.shape)

    #画图
    draw_xy(imgL,top_left,height,width)

    array_all_origin = [array1,array2,array3,array4,array5,array6]


    array_all =  [array1,array4,array2,array5,array3,array6] 
    array_index = ['array1','array4','array2','array5','array3','array6']

    array_space_rate_origin = []
    for i in range(len(array_all_origin)):
        res = space_rate(array_all_origin[i],Midpoint_value,full_value)
        array_space_rate_origin.append(res)
        
    #1,2,3,6
    path_right = array_space_rate_origin[:3] + [array_space_rate_origin[-1]]
    #4,5,6
    path_left = array_space_rate_origin[3:]

    #print('右边路径',path_right)
    #print('左边路径',path_left)
    result_tai = None

    item_class_mapping = {
        'array1': (0, path_right),
        'array4': (0, path_left),
        'array2': (1, path_right),
        'array5': (1, path_left),
        'array3': (2, path_right),
        'array6': (2, path_left),
    }

    array_space_rate = []
    for i in range(len(array_all)):
        res = space_rate(array_all[i],Midpoint_value,full_value)
        array_space_rate.append(res)

    #line0:大于1200的。 line1:大于900，小于1200的。 line2:小于900的
    line0 = [row[0] for row in array_space_rate]
    line1 = [row[1] for row in array_space_rate]
    line2 = [row[2] for row in array_space_rate]
    #print('XXX',line0,line1,line2)

    result_drop=None
    #按照顺序输出最大值，如若两个值相等，则输出靠数组左端的一个
    for i in range(len(line0)):
        #print('目前检测的是高度低于800的',line0[i])
        if line0[i] >= 0.5:
            x,y = item_class_mapping[array_index[i]]
            for j in range(len(y[x:])):
                #print('自身及后续障碍物占比',y[x:][j][2])
                if y[x:][j][2]>0.2 :
                    result_drop=None
                    break
                if result_drop==None:
                    result_drop = array_index[i]
            if result_drop != None:
                break

    #print('第一轮跑完的结果',result_drop)

    if (result_drop==None):
        for i in range(len(line1)):
            #print('目前检测的是高度高于800的，小于1100的',line1[i])
            if line1[i] >= 0.5:
                x,y = item_class_mapping[array_index[i]]
                for j in range(len(y[x:])):
                    #print('自身及后续障碍物占比',y[x:][j][2])
                    if y[x:][j][2]>0.2 :
                        result_drop=None
                        break
                    if result_drop==None:
                        result_drop = array_index[i]
                        result_tai = True
                if result_drop != None:
                    break

    #print('第二轮跑完的结果',result_drop)

    return result_drop,result_tai

if __name__ == "__main__":
    # 定义区域的左上角坐标、宽和高
    threeD_wls= 1
    top_left_corner = (2007, 120)
    region_width = 60
    region_height = 1050
    #x = calculate_volume_rate(threeD_wls, top_left_corner, region_width, region_height)
    #print(x)