import numpy as np

def check_threshold(array, threshold):
    # 计算大于阈值的元素个数
    above_threshold_count = np.sum(array > threshold)

    # 计算数组总元素个数
    total_elements = array.size

    # 计算大于阈值的元素占比
    above_threshold_percentage = (above_threshold_count / total_elements) * 100

    # 判断是否超过百分之五十
    return above_threshold_percentage

# 示例
data_array = np.array([[1, 2, 3, 4, 6, 6, 7, 8, 9, 10],[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]])
#安全线阈值
threshold_value = 5

result = check_threshold(data_array, threshold_value)

print("大于阈值的元素的比例",result)
if result > 50:
    print('可以投')
else:
    print('不能投')

###测试最大值 和 最小值
max_value = np.max(data_array)
print("数值数组中的最大值为:", max_value)

min_value = np.min(data_array)
print("数值数组中的最小值为:", min_value)

while True:
    if min_value == 1:
        break

# ###尝试取一半
# list2 = [1,2,3,4,5,6]
# print(list2[0:len(list2)//2])
# print(list2[len(list2)//2:])

#######################投递
import numpy as np

def check_threshold(array):
    total_count = array.size
    above_1200_count = np.sum(array > 1200)
    between_900_1200_count = np.sum((array > 900) & (array <= 1200))
    below_900_count = np.sum(array < 900)

    above_1200_ratio = above_1200_count / total_count
    between_900_1200_ratio = between_900_1200_count / total_count
    below_900_ratio = below_900_count / total_count

    return above_1200_ratio, between_900_1200_ratio, below_900_ratio

def make_decision(arrays):
    max_above_1200_ratio = 0
    chosen_array = None

    for i, array in enumerate(arrays):
        above_1200_ratio, between_900_1200_ratio, below_900_ratio = check_threshold(array)
        print('XXX',i,above_1200_ratio, between_900_1200_ratio, below_900_ratio )
        if (
            above_1200_ratio > 0.5 and
            all(check_threshold(arr)[2] == 0 for arr in arrays[i+1:])
        ):
            return array

        if above_1200_ratio > max_above_1200_ratio:
            max_above_1200_ratio = above_1200_ratio
            chosen_array = array

    for i, array in enumerate(arrays):
        between_900_1200_ratio = check_threshold(array)[1]

        if (
            between_900_1200_ratio > 0.5 and
            all(check_threshold(arr)[2] == 0 for arr in arrays[i+1:])
        ):
            return array

    return chosen_array

# 生成三个示例数组
array1 = np.random.randint(1200, 1300, size=(3, 3))

array2 = np.array([[ 1440 ,1059  ,821],
                    [1148 ,1226 ,1205],
                    [ 1000 ,1109  ,935]])

array3 = np.random.randint(1200, 1300, size=(3, 3))
array4 = np.random.randint(900, 1300, size=(3, 3))
array5 = np.random.randint(900, 1300, size=(3, 3))
array6 = np.random.randint(900, 1300, size=(3, 3))

print(array1)
print(array2)
print(array3)

path_left = [array4, array5, array6]
path_right = [array1, array2, array3, array6]

result = make_decision([array1, array2, array3, array4, array5, array6])
if result is not None:
    print("选择的数组是：")
    print(result)
else:
    print("没有符合条件的数组")


my_list = [10, 20, 30, 50, 50]
# 使用max()函数找到列表中的最大值
max_value = max(my_list)
# 使用index()方法找到最大值在列表中的索引
max_index = my_list.index(max_value)
# 打印最大值和索引
print(f"最大值是{max_value}，索引是{max_index}")
