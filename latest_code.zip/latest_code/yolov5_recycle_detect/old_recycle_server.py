import logging
import os
import time

import cv2
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import cfg
from empty_detect import load_empty_model
from old_recycle_detect import load_major_model, load_classify_model, sub_category_detect
from zk_utils import output_log, CustomError, remove_oldest_file

# ___________________ FastAPI设置 ___________________

app = FastAPI()
# 添加CORS中间件
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 定义全局变量
app.state.capture = None


# ___________________ 摄像头处理 ___________________

def close_camera():
    try:
        app.state.capture.release()
        app.state.capture = None
    except AttributeError:
        pass


def open_camera():
    close_camera()
    app.state.capture = cv2.VideoCapture(cfg.RECYCLE_CAMERA_ID)


open_camera()  # 调用打开摄像头
output_log()  # 打开日志记录

# ___________________ 网络加载 ___________________

major_model = load_major_model(conf=cfg.MAJOR_CONF, iou=cfg.MAJOR_IOU)
empty_model = load_empty_model(cfg.EMPTY_WEIGHT_PATH)

sub_model = {}
sub_model["su_lsp"] = load_classify_model(cfg.WEIGHT_PATH_SU_LSP)

ITEM_CLASS_MAPPING = {
    '废纸箱': ('废纸箱', '单一，未折叠'),
    '废纸板': ('废纸箱', '单一，折叠'),
    '旧书报': ('旧书报', '单一'),
    '杂项纸': ('杂项纸', '单一'),
    '塑料水瓶': ('塑料瓶', '单一，未踩扁'),
    '塑料水瓶扁': ('塑料瓶', '单一，踩扁'),
    '袋装': (None, '混合'),
    '综合纸': ('综合纸', '单一'),
    '非饮用塑料瓶': ('塑料瓶', '单一，未踩扁'),
    '易拉罐': ('易拉罐', '单一，未踩扁'),
    '易拉罐扁': ('易拉罐', '单一，踩扁'),
    '旧衣物': ('旧衣物', '单一'),
}


# ___________________ 定义路由 ___________________

@app.route("/model/RecycleDetection", methods=['POST', 'GET'])
async def get_frame(request: Request):
    # ___________________ 调用仓储识别 ___________________
    try:
        stereo_camera_bat_path = os.path.join(os.path.dirname(cfg.PRJ_PATH), "Camera-Calibration-Reconstruct", "zk", "call_stereo_camera.bat")
        stereo_camera_folder_path = os.path.dirname(stereo_camera_bat_path)
        os.system(rf'cd /d "{stereo_camera_folder_path}" && start /B cmd /C "{stereo_camera_bat_path}"')
    except Exception as e:
        logging.error(f"调用仓储识别失败：{e}")

    def get_videocapture_frame():
        """
        读取全局变量中的摄像头视频流，获取一帧图片
        读取失败则尝试再次打开摄像头获取数据
        :return: frame
        """

        # 读取全局变量中的摄像头视频流
        try:
            ret, frame = app.state.capture.read()
            if not ret:
                logging.error('摄像头视频流读取失败 not ret')
                raise AttributeError
            return frame

        except AttributeError:
            # ___________________ 读取失败，尝试再次打开摄像头 ___________________

            logging.error('读取全局变量中的摄像头视频流失败，尝试再次打开摄像头')
            open_camera()

            # ____________ 等待时间处理，让摄像头自适应曝光调整 ____________
            # 直接使用time.sleep是不行的

            start_time = time.time()
            while True:
                ret, frame = app.state.capture.read()
                if not ret:
                    logging.error(f'再次尝试打开摄像头失败 not ret ，RECYCLE_CAMERA_ID：{cfg.RECYCLE_CAMERA_ID}')
                    raise CustomError(f'再次尝试打开摄像头失败 not ret ，RECYCLE_CAMERA_ID：{cfg.RECYCLE_CAMERA_ID}')

                time_diff = time.time() - start_time
                if time_diff >= cfg.CAMERA_WAIT_TIME:
                    break

            return frame

    # ___________________ 解析接收json ___________________
    data_json = await request.json()

    # 将收到的消息记录在log中
    logging.info(f"RecycleDetection接收到新请求：{data_json}")

    # 解析请求数据
    signal = data_json['type']
    order_id = data_json['order_id']
    # goods_name = data_json['goods_name']
    # xray = data_json['xray']

    # ___________________ 定义返回json框架 ___________________

    resultdata = {"Imgpath": None,
                  "ai_class": None,
                  "ai_quality": None,
                  "ai_score": 1,
                  "xraw_results": None,
                  "ai_size": None,
                  "ai_counting": 0,
                  "ai_check": True,
                  "Img_base64": None}

    # "Imgpath": None,
    # "Img_base64": None,
    # "ai_check": True
    # "ai_size": None,
    # "xraw_results": None,
    # "ai_class": None,
    # "ai_quality": False,
    # "ai_counting": None,

    # "ai_score": None,

    try:
        # ___________________ 重量变化，识别物品，摄像头画面处理 ___________________

        if signal == "weight":

            frame = get_videocapture_frame()

            ai_img_path, category_name_list, img_base64 = sub_category_detect(frame, order_id, major_model, sub_model)  # 画面处理开始，识别物品
            resultdata["Imgpath"] = ai_img_path
            resultdata["Img_base64"] = img_base64

            set_category_name_list = list(set(category_name_list))  # 去重

            _class = ""
            for ct in set_category_name_list:
                _class = f"{_class} {ct}"
            _class = _class.strip()
            _class = _class.replace(" ", ",")

            resultdata['ai_class'] = _class

            if len(set_category_name_list) == 1:
                resultdata['ai_quality'] = "单一"

                if category_name_list[0] == "易拉罐" or category_name_list[0] == "塑料水瓶":
                    resultdata['ai_counting'] = len(category_name_list)

            elif len(set_category_name_list) >= 2:
                resultdata['ai_quality'] = "混合"

        # ___________________ 检测是否已经卸货完成 ___________________
        if signal == "check1" or signal == "check2":
            frame = get_videocapture_frame()
            empty_classify = empty_model.detect(frame, cfg.POINT_RECTANGULAR, order_id)
            if empty_classify == cfg.NOT_EMPTY:
                resultdata["ai_check"] = False  # 未卸货
            else:
                resultdata["ai_check"] = True

        # ___________________ 请求返回数据 ___________________
        results = {"code": 200, "msg": "OK", "Data": resultdata}

    except CustomError as e:
        results = {"code": 5001, "msg": f"摄像头数据获取失败，默认参数返回，{e}", "Data": resultdata}

    except Exception as e:
        results = {"code": 5002, "msg": f"AI货物识别接口错误，{e}", "Data": resultdata}

    logging.info(f"返回结果如下:{str(results)[:500]}")
    remove_oldest_file(cfg.LOG_PATH)
    return JSONResponse(content=results)


def app_run():
    """
    启动服务
    """
    print("\n回收物识别_接口启动成功\n")
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8025)


if __name__ == "__main__":
    app_run()
