import datetime
import os
import random
from collections import Counter

import cv2
import torch
import torch.nn.functional as F

import cfg
from models.common import DetectMultiBackend
from utils.augmentations import classify_transforms
from utils.torch_utils import select_device
from zk_utils import draw_image_box, remove_oldest_file


class load_major_model:
    def __init__(self, weight_path=cfg.WEIGHT_PATH_MAJOR, conf=0.45, iou=0.25):
        self.weight_path = weight_path
        self.model = torch.hub.load(repo_or_dir=cfg.PRJ_PATH, model="custom", path=self.weight_path, source="local")
        self.model.eval()
        self.model.conf = conf
        self.model.iou = iou
        self.names = self.model.names

        _basename = os.path.basename(self.weight_path)
        print(f"YOLOv5目标检测主模型加载成功：{_basename}")

    def detect(self, image):
        result = self.model(image)
        boxes = result.xyxy[0]  # 获取预测框
        return boxes


class load_classify_model:
    def __init__(self, weight_path, imgsz=(224, 224)):
        self.weight_path = weight_path
        self.model = DetectMultiBackend(self.weight_path, device=select_device())
        self.model.eval()
        self.names = self.model.names
        self.transforms = classify_transforms(imgsz[0])

        _basename = os.path.basename(self.weight_path)
        _splitext = os.path.splitext(_basename)
        print(f"YOLOv5分类子模型加载成功：{cfg.ALL_CATEGORY_NAME[_splitext[0]]} {_basename}")

    def detect(self, im0):
        im = self.transforms(im0)
        im = torch.Tensor(im).to(self.model.device)
        im = im.half() if self.model.fp16 else im.float()  # uint8 to fp16/32
        if len(im.shape) == 3:
            im = im[None]  # expand for batch dim
        results = self.model(im)
        pred = F.softmax(results, dim=1)  # probabilities
        max_idx = torch.argmax(pred, dim=1).item()
        classify = self.names[max_idx]
        return classify


def sub_category_detect(image, order_id, major_model, sub_model):
    # ___________________ 主模型检测 ___________________
    boxes = major_model.detect(image)

    # ___________________ 将主模型检测结果传入子网络进行细分 ___________________
    category_box = []
    category_name_list = []
    for *xyxy, conf, cls in boxes:
        parent_classify = major_model.names[int(cls)]
        cropped_image = image[int(xyxy[1]):int(xyxy[3]), int(xyxy[0]):int(xyxy[2])]

        # TODO
        if cfg.TEST_MOD:
            # sub_classify = random.sample(list(cfg.SUB_CATEGORY_NAME[parent_classify].keys()), 1)[0]  # 在主类别中的子类别里面随机取一个子类返回
            sub_classify = parent_classify  # 直接返回主类别
        else:
            sub_classify = sub_model[parent_classify].detect(cropped_image)

        category_name_list.append(sub_classify)
        classify_chinese = cfg.SUB_CATEGORY_NAME[parent_classify][sub_classify][1]
        color_num = (int(cls) + 1) * (int(cls) + 1) + cfg.SUB_CATEGORY_NAME[parent_classify][sub_classify][0]
        category_box.append((int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3]), float(conf), classify_chinese, color_num))

    img_draw = draw_image_box(image, category_box)

    # ____________________ 类别数量计算 ____________________
    category_count = Counter(category_name_list)
    ai_class = {}
    for ct in category_count.items():
        ai_class[ct[0]] = ct[1]

    # ____________________ 保存日志图片 ____________________

    time_now = datetime.datetime.now()
    time_str = time_now.strftime("%Y%m%d%H%M%S")

    infer_img_name = os.path.join(cfg.ORDER_IMAGE_PATH, f"{order_id}_{time_str}_infer.jpg")
    cv2.imwrite(infer_img_name, img_draw)

    original_img_name = os.path.join(cfg.ORDER_IMAGE_PATH, f"{order_id}_{time_str}_original.jpg")
    cv2.imwrite(original_img_name, image)

    remove_oldest_file(cfg.ORDER_IMAGE_PATH)

    infer_img_name = infer_img_name.replace('\\', '/')
    return infer_img_name, ai_class


if __name__ == '__main__':
    image = cv2.imread(r"D:\zhangkun_20240407\zk_temp\Snipaste_2024-05-20_14-33-35.png")
    # image = cv2.imread(r"D:\zhangkun_20240407\all_dataset\zk_arrange_voc\images\2023_12_01_10_35_37_weight.jpg")
    major_model = load_major_model(conf=0.80, iou=0.40)
    # major_model = load_major_model()
    model_su_lsp = load_classify_model(cfg.WEIGHT_PATH_SU_LSP)
    model_fei_zb = load_classify_model(cfg.WEIGHT_PATH_SU_LSP)
    model_yi_lg = load_classify_model(cfg.WEIGHT_PATH_SU_LSP)

    sub_model = {}
    sub_model["su_lsp"] = model_su_lsp
    sub_model["fei_zb"] = model_fei_zb
    sub_model["yi_lg"] = model_yi_lg

    order_id = random.randint(100000, 999999)

    infer_img_name, ai_class = sub_category_detect(image, order_id, major_model, sub_model)
    print("infer_img_name", infer_img_name)
    print("ai_class", ai_class)
