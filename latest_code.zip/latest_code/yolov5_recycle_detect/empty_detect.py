import time

import cv2
import numpy as np
import torch
import torch.nn.functional as F

from models.common import DetectMultiBackend
from utils.augmentations import classify_transforms
from utils.torch_utils import select_device
import cfg
from zk_utils import save_image_hconcat


class load_empty_model:
    def __init__(self, weight_path, imgsz=(224, 224)):
        self.weight_path = weight_path
        self.model = DetectMultiBackend(self.weight_path, device=select_device())
        self.model.eval()
        self.names = self.model.names
        self.transforms = classify_transforms(imgsz[0])
        print("YOLOv5空仓识别分类模型加载成功")

    def trapezoid(self, image, point):
        """
        矩形区域裁剪
        """

        img = image.copy()
        pts = np.array(point, np.int32)  # 定义梯形区域的四个顶点坐标
        pts = pts.reshape((-1, 1, 2))
        mask = np.zeros_like(img)  # 创建掩码
        cv2.fillPoly(mask, [pts], (255, 255, 255))
        result = cv2.bitwise_and(img, mask)  # 应用掩码到原始图片上
        x, y, w, h = cv2.boundingRect(pts)  # 获取裁剪区域的矩形边界
        cropped_result = result[y:y + h, x:x + w]  # 裁剪结果图片
        return cropped_result

    def rectangular_clipping(self, image, point_rectangular):
        # ____________ 读取裁剪区域 ____________

        points = point_rectangular.split("_")
        points = points[:16]

        # 将字符串列表转换为整数列表
        points_list = [int(x) for x in points]

        # 分割整数列表成左右两个部分
        l_point = [[points_list[i], points_list[i + 1]] for i in range(0, int(len(points_list) / 2), 2)]
        r_point = [[points_list[i], points_list[i + 1]] for i in range(8, len(points_list), 2)]

        # ____________ 处理图片 ____________

        l_result = self.trapezoid(image, l_point)
        r_result = self.trapezoid(image, r_point)

        # 确保两张图片的高度相同，可以根据需要调整大小
        height = min(l_result.shape[0], r_result.shape[0])
        l_result = l_result[:height]
        r_result = r_result[:height]

        # 水平拼接图片
        result = cv2.hconcat([l_result, r_result])
        return result

    def detect(self, im0, point_rectangular, order_id):
        l_img = im0.copy()  # 裁切前保存为左图
        im0 = self.rectangular_clipping(im0, point_rectangular)
        r_img = im0.copy()  # 裁切后保存为右图
        im = self.transforms(im0)
        im = torch.Tensor(im).to(self.model.device)
        im = im.half() if self.model.fp16 else im.float()  # uint8 to fp16/32
        if len(im.shape) == 3:
            im = im[None]  # expand for batch dim
        results = self.model(im)
        pred = F.softmax(results, dim=1)  # probabilities
        max_idx = torch.argmax(pred, dim=1).item()
        classify = self.names[max_idx]
        save_image_hconcat(l_img, r_img, classify, order_id)  # 保存图片
        return classify


if __name__ == '__main__':
    # prj_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
    # image_path = os.path.join(prj_path, "data", "test_image.jpg")
    # image = cv2.imread(image_path)

    # image = cv2.imread(r"D:\zhangkun_20240407\all_dataset\empty\empty_original_data\75_126_149_155_186_405_72_471_519_142_595_114_592_467_481_410_3.jpg")
    image = cv2.imread(r"D:\zhangkun_20240407\zk_temp\ff\2024_05_07_21_36_03_check1.jpg")
    empty_model = load_empty_model(cfg.EMPTY_WEIGHT_PATH)

    # time.sleep(10)
    start_time = time.time()
    classify = empty_model.detect(image, cfg.POINT_RECTANGULAR)
    print('time:', round((time.time() - start_time) * 1000, 2), "ms")
    print(classify)

    # l_img = cv2.imread(r"D:\zhangkun_20240407\zk_temp\aa.png")
    # r_img = cv2.imread(r"D:\zhangkun_20240407\zk_temp\bb.png")
    # save_image_hconcat(l_img, r_img, "img_text")
