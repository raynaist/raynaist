import json
import random
import time

import requests

import cfg

order_id = random.randint(10000000, 90000000)
# order_id = 70866736

# data_json = {"signal": cfg.SIGNAL_OPEN_CAMERA, "order_id": order_id, "xray": None, "goods_name": None}
# data_json = {"signal": cfg.SIGNAL_CLOSE_CAMERA, "order_id": order_id, "xray": None, "goods_name": None}
data_json = {"signal": cfg.SIGNAL_CHECK_WEIGHT, "order_id": order_id, "xray": None, "goods_name": None}

# data_json = {"type": cfg.SIGNAL_CHECK_WEIGHT, "order_id": order_id, "xray": None, "goods_name": None}
# data_json = {"type": "check1", "order_id": order_id, "xray": None, "goods_name": None}

data_json = json.dumps(data_json, sort_keys=False, indent=4, separators=(',', ': '))

start_time = time.time()
response = requests.post("http://127.0.0.1:8025/model/RecycleDetection", data=data_json)
print('time:', round((time.time() - start_time) * 1000, 2), "ms")
print(json.loads(response.text))
