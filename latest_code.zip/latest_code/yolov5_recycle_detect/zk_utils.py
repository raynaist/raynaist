# -*-coding: utf-8 -*-
"""
    @Author : zhangkun
    @Version : 1.0
    @E-mail : stuberg@foxmail.com
    @Date   : 2024-5-14 11:04:34
"""

import base64
import datetime
import logging
import os
import time

import cv2
import numpy as np
from ultralytics.utils.plotting import Annotator, colors

import cfg


def output_log():
    """
    log日志
    :return:
    """

    # 在log文件夹下再创建一个以当前日期命名的文件夹
    log_date_path = os.path.join(cfg.LOG_PATH, time.strftime('%Y_%m_%d', time.localtime(time.time())))
    if not os.path.exists(log_date_path):
        os.makedirs(log_date_path)

    # 创建一个logger(初始化logger)
    log = logging.getLogger()

    # 检查并清除已有的处理器
    if log.hasHandlers():
        log.handlers.clear()

    log.setLevel(logging.DEBUG)

    try:
        # 创建一个handler，用于写入日志文件
        current_time = time.strftime('%Y_%m_%d_%H', time.localtime(time.time()))  # 返回当前时间
        log_name = os.path.join(log_date_path, current_time + '.log')

        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.DEBUG)

        # 定义handler的输出格式
        formatter = logging.Formatter('[%(asctime)s] - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        # 给logger添加handler
        log.addHandler(fh)

    except Exception as e:
        print("输出日志失败！", e)


def remove_oldest_file(file_path, save_file_num=None, save_file_time=cfg.LOG_FILE_TIME):
    """
    按文件最后修改时间排序，保留最近的，将其余的删除
    :param file_path:
    :param save_file_num: 文件保留数量
    :param save_file_time: 文件保留时间，单位：小时
    :return:
    """

    # ____________________ 文件信息 ____________________

    file_num = 0
    file_list = []
    for root, dirs, files in os.walk(file_path):
        file_num = file_num + len(files)
        for file in files:
            _file_name = os.path.join(root, file)
            file_list.append((_file_name,
                              os.path.getmtime(_file_name)))  # 文件最后修改时间

    # 按时间排序
    file_list.sort(key=lambda x: x[1], reverse=True)

    # ____________________ 按保留数量删除旧文件 ____________________
    if save_file_num is not None:
        if file_num > save_file_num:
            for i in range(save_file_num, file_num):
                os.remove(file_list[i][0])

    # ____________________ 按保留时间删除旧文件 ____________________
    if save_file_time is not None:
        save_file_time = save_file_time * 60 * 60  # 传入小时转换为秒
        time_now = time.time()

        for _fl in file_list:
            _file_name = _fl[0]
            _mtime = _fl[1]

            # 时间判断
            if time_now - _mtime > save_file_time:
                os.remove(_file_name)

    # ____________________ 删除空文件夹 ____________________
    # 文件删除后再次清理空文件夹
    # 删除空文件夹
    # 遍历当前文件夹中的所有子文件夹和文件
    for root, dirs, files in os.walk(file_path, topdown=False):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            if not os.listdir(dir_path):
                os.rmdir(dir_path)


class CustomError(Exception):
    """
    自定义异常信息
    """

    def __init__(self, message="自定义异常信息"):
        self.message = message
        super().__init__(self.message)


def draw_image_box(image, boxes):
    """
    调用yolov5原生工具画图
    :param image:
    :param boxes: list格式元组：x1 y1 x2 y2 conf class_name color_num
    :return: OpenCV格式图片
    """

    annotator = Annotator(image, pil=True, font="simhei.ttf")
    for box in boxes:
        x1 = box[0]
        y1 = box[1]
        x2 = box[2]
        y2 = box[3]
        conf = box[4]
        class_name = box[5]
        color_num = box[6]

        label = f'{class_name} {conf:.2f}'
        annotator.box_label((x1, y1, x2, y2), label, color=colors(color_num, True))

    return annotator.result()


def cv_image_to_base64(cv_image):
    """
    OpenCV格式转base64
    base64数据过大，不要记录在日志txt中
    :param cv_image:
    :return:
    """

    header_info = "image/jpeg"  # 根据图片类型选择适当的MIME类型
    # 将OpenCV格式的图像转换为字节序列
    _, buffer = cv2.imencode('.jpg', cv_image)
    # 将字节序列编码为Base64字符串
    base64_string = f"data:{header_info};base64," + base64.b64encode(buffer).decode("utf-8")
    return base64_string


def save_image_hconcat(l_img, r_img, img_text, order_id):
    """
    将图片左右水平拼接在一起，并添加文字
    :param l_img:
    :param r_img:
    :param img_text:
    :return:
    """

    # ____________________ 图片粘贴拼接处理 ____________________

    l_h, l_w, _ = l_img.shape
    r_h, r_w, _ = r_img.shape
    bg_w = l_w + r_w
    bg_h = max(l_h, r_h)
    # background = np.zeros((bg_h, bg_w, 3), dtype=np.uint8)  # 黑色背景
    background = np.full((bg_h, bg_w, 3), 128, dtype=np.uint8)  # 灰色背景
    background[0:l_h, 0:l_w] = l_img
    background[0:r_h, l_w:l_w + r_w] = r_img
    cv2.putText(background, str(img_text), (int(bg_w * 0.10), int(bg_h * 0.10)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2, cv2.LINE_AA)

    # ____________________ 保存日志图片 ____________________

    time_now = datetime.datetime.now()
    time_str = time_now.strftime("%Y%m%d%H%M%S")
    _img_name = os.path.join(cfg.TEMP_IMAGE_PATH, f"{order_id}_{time_str}_check.jpg")
    cv2.imwrite(_img_name, background)
    remove_oldest_file(cfg.TEMP_IMAGE_PATH)


if __name__ == '__main__':
    # remove_oldest_file(r"D:\zhangkun_20240407\zk_temp\del", save_file_num=2, save_file_time=48)
    remove_oldest_file(cfg.TEMP_IMAGE_PATH)
