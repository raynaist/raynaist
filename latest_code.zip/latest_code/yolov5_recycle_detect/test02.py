import logging

# 获取日志记录器
logger = logging.getLogger('my_logger')

# 检查并清除已有的处理器
if logger.hasHandlers():
    logger.handlers.clear()

# 设置日志级别和格式
logger.setLevel(logging.DEBUG)

# 创建处理器
console_handler = logging.StreamHandler()
file_handler = logging.FileHandler('app.log')

# 设置处理器的日志级别
console_handler.setLevel(logging.DEBUG)
file_handler.setLevel(logging.INFO)

# 创建格式器
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# 将处理器添加到日志记录器
logger.addHandler(console_handler)
logger.addHandler(file_handler)

# 记录日志
logger.debug('这是调试信息')
logger.info('这是信息')
logger.warning('这是警告')
logger.error('这是错误')
logger.critical('这是严重错误')
