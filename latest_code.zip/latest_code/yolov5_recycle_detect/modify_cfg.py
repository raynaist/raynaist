import codecs
import shutil
import sys

file_cfg = "cfg.py"
var_str = "SEPARATE_CFG_SELECT"

# _____________________ 获取参数列表 _____________________

args = sys.argv

# 第一个参数是脚本名称，第二个参数是输入的值
if len(args) >= 2:
    input_value = args[1]
    print("输入的参数是：", input_value)
else:
    print("请输入参数")
    exit()

# _____________________ 修改 cfg.py 变量 _____________________

with codecs.open(file_cfg, 'r', encoding='utf-8') as f:
    lines = f.readlines()

with codecs.open('temp_file.tmp', 'w', encoding='utf-8') as f:
    for line in lines:

        if line.startswith(var_str):
            f.write(f"{var_str} = '{input_value}'\n")
        else:
            f.write(line)

# Replace original file with temporary file
shutil.move('temp_file.tmp', file_cfg)
print("cfg.py 变量修改完毕")
