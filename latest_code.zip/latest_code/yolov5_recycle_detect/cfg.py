import os

import random
from PyCameraList.camera_device import list_video_devices

# gjsq  jld  jmgj  jcsc  qsmj
SEPARATE_CFG_SELECT = 'qsmj'

# TODO
TEST_MOD = True  # 是否打开测试模式

CAMERA_WAIT_TIME = 3  # 单位：秒，重新打开摄像头的等待时间，让摄像头自适应曝光调整

MAJOR_CONF = 0.20  # 主模型置信度
MAJOR_IOU = 0.40  # 主模型IOU

LOG_FILE_TIME = 7 * 24  # 日志文件保留时间

# __________________ 文件夹设置 __________________


PRJ_PATH = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）

LOG_PATH = os.path.join(PRJ_PATH, "data", "log")  # 在项目路径下创建一个log文件夹, 拼接成路径格式
if not os.path.exists(LOG_PATH):
    os.makedirs(LOG_PATH)

ORDER_IMAGE_PATH = os.path.join(PRJ_PATH, "data", "order_image")
if not os.path.exists(ORDER_IMAGE_PATH):
    os.makedirs(ORDER_IMAGE_PATH)

SIGNAL_OPEN_CAMERA = "open_camera"
SIGNAL_CLOSE_CAMERA = "close_camera"
SIGNAL_CHECK_WEIGHT = "weight"
SIGNAL_CHECK_XRAY = "xray"
SIGNAL_CHECK_UNLOAD = "check"

SUB_CATEGORY_NAME = {
    "su_lsp": {
        "su_lsp": (0, "塑料水瓶"),
        "su_lspb": (1, "塑料水瓶扁"),
        "fei_yyslsp": (2, "非饮用塑料水瓶")
    },
    "fei_zb": {
        "fei_zb": (0, "废纸板"),
        "zong_hz": (1, "综合纸"),
        "za_xz": (2, "杂项纸"),
        "jiu_sb": (3, "旧书报"),
        "fei_zx": (4, "废纸箱")
    },
    "yi_lg": {
        "yi_lg": (0, "易拉罐"),
        "yi_lgb": (1, "易拉罐扁"),
    },
    "jiu_yw": {
        "jiu_yw": (0, "旧衣物")
    }
}

ALL_CATEGORY_NAME = {
    "su_lsp": "塑料水瓶",
    "fei_zb": "废纸板",
    "yi_lg": "易拉罐",
    "zong_hz": "综合纸",
    "za_xz": "杂项纸",
    "fei_yyslsp": "非饮用塑料水瓶",
    "jiu_sb": "旧书报",
    # "zha_d": "扎带",
    # "dai_z": "袋装",
    "su_lspb": "塑料水瓶扁",
    "fei_zx": "废纸箱",
    "jiu_yw": "旧衣物",
    "yi_lgb": "易拉罐扁"}

# ___________________ 权重路径设置 ___________________

WEIGHT_PATH_MAJOR = os.path.join(os.path.dirname(PRJ_PATH), "recycle_detect_all_weight", "major_category.pt")
WEIGHT_PATH_SU_LSP = os.path.join(os.path.dirname(PRJ_PATH), "recycle_detect_all_weight", "su_lsp.pt")

# ___________________ 吊舱内摄像头ID设置 ___________________

device_value_recycle = "LRCP 500W"
# device_value_recycle = 0
cameras = list_video_devices()
matching_keys_recycle = [key for key, value in dict(cameras).items() if value == device_value_recycle]
try:
    # 判断是参数是直接写的相机ID还是写的相机名称
    if isinstance(device_value_recycle, int):
        RECYCLE_CAMERA_ID = device_value_recycle
    else:
        RECYCLE_CAMERA_ID = matching_keys_recycle[0]
except IndexError:
    RECYCLE_CAMERA_ID = "error"  # 相机掉线报错处理

# __________________ 空仓识别相关设置 __________________

EMPTY_WEIGHT_PATH = os.path.join(os.path.dirname(PRJ_PATH), "recycle_detect_all_weight", "empty.pt")
TEMP_IMAGE_PATH = os.path.join(PRJ_PATH, "data", "unload_image")
if not os.path.exists(TEMP_IMAGE_PATH):
    os.makedirs(TEMP_IMAGE_PATH)

"""
POINT_RECTANGULAR 16个点的含义解释：
    左边右边两个矩形区域的4+4个点xy坐标
    顶点顺序是左上角起顺时针方向1234个点
    数据依次为：左x1_左y1_左x2_左y2_左x3_左y3_左x4_左y4_右x1_右y1_右x2_右y2_右x3_右y3_右x4_右y4
"""

# __________________ qsmj __________________
qsmj = {}
qsmj["POINT_RECTANGULAR"] = '109_148_156_163_180_427_113_468_532_155_582_134_582_472_508_433'

# __________________ gjsq __________________
gjsq = {}
gjsq["POINT_RECTANGULAR"] = '57_128_143_146_174_417_53_470_515_145_608_119_607_471_486_414'

# __________________ jld __________________
jld = {}
jld["POINT_RECTANGULAR"] = '74_100_150_129_190_386_70_462_524_144_593_116_588_467_477_402'

# __________________ jmgj __________________
jmgj = {}
jmgj["POINT_RECTANGULAR"] = '65_121_147_143_184_408_66_465_521_138_592_110_593_467_483_410'

# __________________ 项目参数选择 __________________
separate_cfg = eval(SEPARATE_CFG_SELECT)
POINT_RECTANGULAR = separate_cfg["POINT_RECTANGULAR"]

EMPTY = "empty"  # 空
NOT_EMPTY = "not_empty"  # 非空

if __name__ == '__main__':
    # print(PRJ_PATH)
    print("RECYCLE_CAMERA_ID", RECYCLE_CAMERA_ID)

    print(random.sample(list(SUB_CATEGORY_NAME.keys()), 1))
