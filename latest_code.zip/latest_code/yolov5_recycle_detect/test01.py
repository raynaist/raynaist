import os

import cv2
import torch
from ultralytics.utils.plotting import Annotator, colors

PRJ_PATH = os.path.dirname(os.path.abspath(__file__))

model = torch.hub.load(repo_or_dir=os.path.dirname(PRJ_PATH),
                       model="custom",
                       path=os.path.join(PRJ_PATH, "data", "major_category.pt"),
                       source="local")
model.eval()
# model.conf = 0.45
# model.iou = 0.25

image = cv2.imread(r"D:\zhangkun_20240407\all_dataset\zk_arrange_voc\images\2023_12_01_15_48_24_weight.jpg")
result = model(image)
boxes = result.xyxy[0]  # 获取预测框
names = model.names
annotator = Annotator(image, example=str(names), pil=True, font="simhei.ttf")

print("boxes", boxes)

# 从右向左依次取数 cls conf 剩下的全部数据给 *xyxy
for *xyxy, conf, cls in boxes:
    c = int(cls)  # integer class
    label = f'{names[c]} 呵呵 {conf:.2f}'
    annotator.box_label(xyxy, label, color=colors(c, True))

image = annotator.result()
cv2.imshow("imshow", image)
cv2.waitKey()
cv2.destroyAllWindows()
