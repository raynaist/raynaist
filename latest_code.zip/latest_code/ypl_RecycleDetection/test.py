# #my_set = {'a', 'b'}  # 示例集合，其中一个元素未知

# # 通过集合差集操作获取未知元素
# #unknown_element = (my_set - {'a'}).pop()

# # 输出未知元素
# #print("Unknown Element:", unknown_element,type(unknown_element))



# # my_list = ['塑料水瓶','塑料水瓶','塑料水瓶','塑料水瓶']
# # element_to_count = '塑料水瓶'
# # result = my_list.count(element_to_count)
# # print(f"{element_to_count} 出现的次数是：{result}",type(result))

# # set_resultclass = {'c', 'c', 'c'}
# # i='sas'
# # if i =='sas'and (('a' in set_resultclass) or ('b' in set_resultclass)):
# #     print('bbbbb')

# # import time
# # start_time = time.time()
# # print('time:',time, (time.time() - start_time))

####################测量拍摄面积
# import math
# # 角度转弧度
# horizontal_fov_degrees = 80
# vertical_fov_degrees = 40
# horizontal_fov = math.radians(horizontal_fov_degrees)
# vertical_fov = math.radians(vertical_fov_degrees)

# # 深度范围
# distance = 1.0 # 1 米

# # 计算拍摄区域大小
# horizontal_coverage = 2 * distance * math.tan(horizontal_fov / 2)
# vertical_coverage = 2 * distance * math.tan(vertical_fov / 2)

# print("水平方向拍摄区域大小：", horizontal_coverage, "平方米")
# print("垂直方向拍摄区域大小：", vertical_coverage, "平方米")


# #####元祖取值
# data = [(27.40234375, 59.44097900390625), (78.74945068359375, 282.53485107421875), (635.7353820800781, 459.5684509277344),(1211,323),(192,3242)]

# max_first = max(item[0] for item in data)
# max_second = max(item[1] for item in data)

# print(max_first, max_second)


# #####测试多个摄像头
# #!/usr/bin/env python
# # coding=utf-8
# import time
# from PyCameraList.camera_device import test_list_cameras, list_video_devices, list_audio_devices
 
# cameras = list_video_devices()
# print(cameras,dict(cameras))
# #return: {0: 'Intel(R) RealSense(TM) 3D Camera (Front F200) RGB', 1: 'NewTek NDI Video', 2: 'Intel(R) RealSense(TM) 3D Camera Virtual Driver', 3: 'Intel(R) RealSense(TM) 3D Camera (Front F200) Depth', 4: 'OBS-Camera', 5: 'OBS-Camera2', 6: 'OBS-Camera3', 7: 'OBS-Camera4', 8: 'OBS Virtual Camera'}

# # 寻找值等于 'VT-UA580C2-T' 的键
# ###双目摄像头
# desired_value = 'VT-UA580C2-T'
# matching_keys = [key for key, value in dict(cameras).items() if value == desired_value]

# # 输出匹配的键
# for key in matching_keys:
#     print(key)



# audios = list_audio_devices()
# print(dict(audios))
# #return:  {0: '麦克风阵列 (Creative VF0800)', 1: 'OBS-Audio', 2: '线路 (NewTek NDI Audio)'}
 

# # current_time = time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime(time.time()))  # 返回当前时间
# # print(current_time)

# set_resultclass = ['塑料水瓶']
# item_class_results = []
# resultdata = {"Imgpath":None,"ai_class":None,"ai_quality":None,"ai_score":None,"xraw_results":None,"ai_size":None,"ai_counting":None}

# item_class_mapping = {
#     '废纸箱': ('废纸箱', '单一，未折叠'),
#     '废纸板': ('废纸箱', '单一，折叠'),
#     '旧书报': ('旧书报', '单一'),
#     '杂项纸': ('杂项纸', '单一'),
#     '塑料水瓶': ('塑料瓶', '单一，未踩扁'),
#     '塑料水瓶扁': ('塑料瓶', '单一，踩扁'),
#     '袋装': ('袋装', '混合'),
# }

# for item in set_resultclass:
#     if item in item_class_mapping:
#         item_class, item_quality = item_class_mapping[item]
#         item_class_results.append(item_class)
#         resultdata['ai_class'] = item_class_results
#         resultdata['ai_quality'] = item_quality
#         break
# print(resultdata)

# import cv2

# cap = cv2.VideoCapture(0)
# cv2.namedWindow('shuangmu',cv2.WINDOW_NORMAL)
# while(cap.isOpened()):
#     ret,frame = cap.read()
#     cv2.imshow('shuangmu',frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break
#     cv2.release()
#     cv2.destoryAllWindow()

# x = (12,23,34,45)
# x1,x2,x3,x4 = x
# print(x1,x2,x3,x4)

# 定义一个数字变量和一个字符串变量
num = 123
str_val = 'hello'

# 使用type()函数判断类型
if type(num) == int:
    print("num是一个整数")
if type(str_val) == str:
    print("str_val是一个字符串")

# 使用isinstance()函数判断类型
if isinstance(num, int):
    print("num是一个整数")
if isinstance(str_val, str):
    print("str_val是一个字符串")


