import cv2
import numpy as np

'''
单位mm
actual_object_width =  # 实际物体宽度
image_object_width =   # 图片中物体宽度
actual_base_width =    # 实际底板宽度
image_base_width =     # 图片中底板宽度

actual_object_height =  # 实际物体高度
image_object_height =   # 图片中物体高度
actual_base_height =    # 实际底板高度
image_base_height =     # 图片中底板高度

right_base_x = 图片中底板靠近反射板那一侧的坐标
width_side_reflectors = 侧板到反射板的距离
'''
actual_base_width = 840
actual_base_height = 720
width_side_reflectors = 95

image_base_width = 530 #需要更改 40--570 left--right
image_base_height = 410 #需要更改 70--480 top--bottom
right_base_x = 570 #需要更改 570

def Calculate_Height(xraw_path, height_xraw, width_dis2bottle, width_xraw):
    '''
    #xraw_path:x射线图片存储位置
    #height_xraw：实际x摄像头的高度，已知条件
    #width_dis2bottle：实际物体距离背板的距离，通过ai识别计算出
    #width_xraw：实际x摄像头距离背板的距离，已知条件
    '''
    ##x射线图片参数，xraw width:615 , height:640
    img = cv2.imread(xraw_path, 0)  # 读取图像
    img = cv2.GaussianBlur(img, (7, 7), sigmaX=1)  # 高斯模糊图像
    
    img_bin = cv2.Canny(img, 50, 100)  # 得到二值图像
     
    lines = cv2.HoughLinesP(img_bin, 1, np.pi / 180, threshold=10)  # Hough 变换
    img2 = img.copy()
    for line in lines:
        x1, y1, x2, y2 = line[0]  # 提取线段
        cv2.line(img, (x1, y1), (x2, y2), (0, 0, 255), 1)  # 在原图上绘制线段

    height_line = []

    for line in lines:
        x1, y1, x2, y2 = line[0]  # 提取线段
        if (x1>=65)&(x2>=65)&(y1<=240)&(y2<=240)&(y1>=7)&(y2>=7):
            cv2.line(img2, (x1, y1), (x2, y2), (0, 0, 255), 1)  # 在原图上绘制线段
            height_line.append(line[0].tolist())

    sorted_data_y1 = sorted(height_line, key=lambda x: x[1])
    print('最小的y1',sorted_data_y1[0])

    sorted_data_y2 = sorted(height_line, key=lambda x: x[3])
    print('最小的y2',sorted_data_y2[0])

    #勉强定义背景板和地面的分界线在240mm尺寸左右
    height_background = 240

    #height_xraw：实际x摄像头的高度，已知条件
    #width_dis2bottle：实际物体距离背板的距离，通过ai识别计算出
    #width_xraw：实际x摄像头距离背板的距离，已知条件

    actual_width_dis2bottle = (actual_base_width * abs(right_base_x - width_dis2bottle)/image_base_width) + width_side_reflectors

    #求出x光图中的物体阴影在背景板上的高度
    height = (height_background - (sorted_data_y1[0][1] if sorted_data_y1[0][1] < sorted_data_y2[0][3] else sorted_data_y2[0][3]))
    #求出背景板上的高度映射到实际场景中的高度
    height = height_xraw *(height/height_background)
    #计算出实际物体中，物品高度和投影高度的高度差
    height_Difference = (actual_width_dis2bottle *(height_xraw - height))/width_xraw
    #计算实际物品的高度
    height_item = height + height_Difference

    # cv2.imshow('Canny', img_bin)  # 显示 Canny 检测的图像
    # cv2.imshow('img', img)
    # cv2.imshow('img2', img2)
    # cv2.waitKey()
    # cv2.destroyAllWindows()
    return height_item

def Calculate_wid(image_object_width, image_object_height):
    '''
    actual_object_width =  # 实际物体宽度
    image_object_width =   # 图片中物体宽度
    actual_base_width =    # 实际底板宽度
    image_base_width =     # 图片中底板宽度

    actual_object_height =  # 实际物体高度
    image_object_height =   # 图片中物体高度
    actual_base_height =    # 实际底板高度
    image_base_height =     # 图片中底板高度

    '''
    actual_object_width = actual_base_width * image_object_width/image_base_width
    actual_object_height = actual_base_height * image_object_height/image_base_height

    return actual_object_width,actual_object_height

if __name__ == '__main__':
    xraw_path = './123.png'
    height_item = Calculate_Height(xraw_path,469,295,1256)
    print('实际物品的高度',height_item)
