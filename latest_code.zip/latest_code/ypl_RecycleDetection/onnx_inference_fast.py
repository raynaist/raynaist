import base64
import logging
import os
import subprocess
import time

import cv2
import numpy as np
import onnxruntime
from PIL import Image, ImageDraw, ImageFont
from PyCameraList.camera_device import list_video_devices
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from Measuring_Volume import Calculate_Height, Calculate_wid
#
from class_mapping import *
############ 参数 ############
from zk import cfg
from zk.predict import load_classify_model

CLASSES = ["废纸箱", "废纸板", "旧书报", "杂项纸", "袋装", "扎带", "塑料水瓶", "塑料水瓶扁", "综合纸", "非饮用塑料瓶", "易拉罐", "易拉罐扁", "旧衣物"]
desired_value = 'LRCP 500W'
# 定义读取模型路径
onnx_path = 'weights/best0116.onnx'

check1_img = './temp/2024_01_31_17_01_20_check1.jpg'
# 定义ROI的位置
xywh1 = (580, 80, 40, 350)

check2_img = './temp/2024_01_05_15_54_12_check_infer.jpg'
# 定义ROI的位置
xywh2 = (616, 338, 20, 120)


############ output_log ############
def output_log():
    """
    自动生成日志文件
  
    """
    # 项目路径
    prj_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
    # 在项目路径下创建一个log文件夹, 拼接成路径格式
    log_path = os.path.join(prj_path, 'log')
    # 在log文件夹下再创建一个以当前日期命名的文件夹
    log_date_path = os.path.join(log_path, time.strftime('%Y_%m_%d', time.localtime(time.time())))
    current_time = time.strftime('%Y_%m_%d_%H_%M', time.localtime(time.time()))  # 返回当前时间
    # 在时间文件夹下创建一个文件，后缀是.log.
    log_name = os.path.join(log_date_path, current_time + '.log')
    isExists = os.path.exists(log_date_path)  # 判断该目录是否存在
    # 创建一个logger(初始化logger)
    log1 = logging.getLogger()
    log1.setLevel(logging.DEBUG)
    if not isExists:
        os.makedirs(log_date_path)
        print(log_path + log_date_path + "目录创建成功")
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(log_path + "目录 %s 已存在" % log_date_path)
    try:
        # 创建一个handler，用于写入日志文件
        current_time = time.strftime('%Y_%m_%d_%H_%M', time.localtime(time.time()))  # 返回当前时间
        log_name = os.path.join(log_date_path, current_time + '.log')

        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.INFO)

        # 定义handler的输出格式
        formatter = logging.Formatter('[%(asctime)s] - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        # 给logger添加handler
        log1.addHandler(fh)
    except Exception as e:
        print("输出日志失败！ %s" % e)


############ output_img ############
def output_imgs(orderID, signal, img, inference_img):
    """
    保存图片函数，推理结束后按照需求保存图片，例如：imgs/年/月/orderID/time_1.jpg
  
    """
    # 项目路径
    prj_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
    # 在项目路径下创建一个log文件夹, 拼接成路径格式
    imgs_path = os.path.join(prj_path, 'imgs')
    # 在log文件夹下再创建一个以当前日期命名的文件夹
    year_path = os.path.join(imgs_path, time.strftime('%Y', time.localtime(time.time())))
    month_path = os.path.join(year_path, time.strftime('%m', time.localtime(time.time())))
    orderID_path = os.path.join(month_path, orderID)

    current_time = time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime(time.time()))  # 返回当前时间
    # 在时间文件夹下创建一个文件，后缀是.log.
    img_name = os.path.join(orderID_path, current_time + '_' + signal + '.jpg')
    inference_img_name = os.path.join(orderID_path, current_time + '_' + signal + '_infer' + '.jpg')
    isExists = os.path.exists(orderID_path)  # 判断该目录是否存在
    print(prj_path, orderID_path, img_name)
    if not isExists:
        os.makedirs(orderID_path)
        print(orderID_path + "目录创建成功")
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(orderID_path + "目录 %s 已存在" % orderID_path)
    try:
        # 创建一个handler，用于写入日志文件
        cv2.imwrite(img_name, img)
        cv2.imwrite(inference_img_name, inference_img)
    except Exception as e:
        print("输出图片失败！ %s" % e)

    # 返回原图文件名和图片数据
    return img_name, img, inference_img_name, inference_img


class YOLOV5():
    """
    YOLOv5框架主题类
  
    """

    def __init__(self, onnxpath):
        self.device = "cuda"
        self.providers = ['CUDAExecutionProvider'] if self.device != 'cpu' else ['CPUExecutionProvider']
        self.onnx_session = onnxruntime.InferenceSession(onnxpath, providers=self.providers)
        self.input_name = self.get_input_name()
        self.output_name = self.get_output_name()

    # -------------------------------------------------------
    #   获取输入输出的名字
    # -------------------------------------------------------
    def get_input_name(self):
        input_name = []
        for node in self.onnx_session.get_inputs():
            input_name.append(node.name)
        return input_name

    def get_output_name(self):
        output_name = []
        for node in self.onnx_session.get_outputs():
            output_name.append(node.name)
        return output_name

    # -------------------------------------------------------
    #   输入图像
    # -------------------------------------------------------
    def get_input_feed(self, img_tensor):
        input_feed = {}
        for name in self.input_name:
            input_feed[name] = img_tensor
        return input_feed

    # -------------------------------------------------------
    #   1.cv2读取图像并resize
    #   2.图像转BGR2RGB和HWC2CHW
    #   3.图像归一化
    #   4.图像增加维度
    #   5.onnx_session 推理
    # -------------------------------------------------------
    def inference(self, img):
        img_o = img.copy()
        or_img = cv2.resize(img, (640, 640))
        img = or_img[:, :, ::-1].transpose(2, 0, 1)  # BGR2RGB和HWC2CHW
        img = img.astype(dtype=np.float32)
        img /= 255.0
        img = np.expand_dims(img, axis=0)
        input_feed = self.get_input_feed(img)
        pred = self.onnx_session.run(None, input_feed)[0]
        return pred, img_o


# dets:  array [x,6] 6个值分别为x1,y1,x2,y2,score,class
# thresh: 阈值
def nms(dets, thresh):
    """
    NMS算法
  
    """
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    # -------------------------------------------------------
    #   计算框的面积
    #   置信度从大到小排序
    # -------------------------------------------------------
    areas = (y2 - y1 + 1) * (x2 - x1 + 1)
    scores = dets[:, 4]
    keep = []
    index = scores.argsort()[::-1]

    while index.size > 0:
        i = index[0]
        keep.append(i)
        # -------------------------------------------------------
        #   计算相交面积
        #   1.相交
        #   2.不相交
        # -------------------------------------------------------
        x11 = np.maximum(x1[i], x1[index[1:]])
        y11 = np.maximum(y1[i], y1[index[1:]])
        x22 = np.minimum(x2[i], x2[index[1:]])
        y22 = np.minimum(y2[i], y2[index[1:]])

        w = np.maximum(0, x22 - x11 + 1)
        h = np.maximum(0, y22 - y11 + 1)

        overlaps = w * h
        # -------------------------------------------------------
        #   计算该框与其它框的IOU，去除掉重复的框，即IOU值大的框
        #   IOU小于thresh的框保留下来
        # -------------------------------------------------------
        ious = overlaps / (areas[i] + areas[index[1:]] - overlaps)
        idx = np.where(ious <= thresh)[0]
        index = index[idx + 1]
    return keep


def xywh2xyxy(x):
    # [x, y, w, h] to [x1, y1, x2, y2]
    y = np.copy(x)
    y[:, 0] = x[:, 0] - x[:, 2] / 2
    y[:, 1] = x[:, 1] - x[:, 3] / 2
    y[:, 2] = x[:, 0] + x[:, 2] / 2
    y[:, 3] = x[:, 1] + x[:, 3] / 2
    return y


def filter_box(org_box, conf_thres, iou_thres):  # 过滤掉无用的框
    # -------------------------------------------------------
    #   删除为1的维度
    #   删除置信度小于conf_thres的BOX
    # -------------------------------------------------------
    org_box = np.squeeze(org_box)
    conf = org_box[..., 4] > conf_thres
    box = org_box[conf == True]
    # -------------------------------------------------------
    #   通过argmax获取置信度最大的类别
    # -------------------------------------------------------
    cls_cinf = box[..., 5:]
    cls = []
    for i in range(len(cls_cinf)):
        cls.append(int(np.argmax(cls_cinf[i])))
    all_cls = list(set(cls))
    # -------------------------------------------------------
    #   分别对每个类别进行过滤
    #   1.将第6列元素替换为类别下标
    #   2.xywh2xyxy 坐标转换
    #   3.经过非极大抑制后输出的BOX下标
    #   4.利用下标取出非极大抑制后的BOX
    # -------------------------------------------------------
    output = []
    for i in range(len(all_cls)):
        curr_cls = all_cls[i]
        curr_cls_box = []
        curr_out_box = []
        for j in range(len(cls)):
            if cls[j] == curr_cls:
                box[j][5] = curr_cls
                curr_cls_box.append(box[j][:6])
        curr_cls_box = np.array(curr_cls_box)
        # curr_cls_box_old = np.copy(curr_cls_box)
        curr_cls_box = xywh2xyxy(curr_cls_box)
        curr_out_box = nms(curr_cls_box, iou_thres)
        for k in curr_out_box:
            output.append(curr_cls_box[k])
    output = np.array(output)
    return output


def cv2ImgAddText(img, text, left, top, textColor=(0, 255, 0), textSize=20):
    """
    图片上添加文本函数
  
    """
    if (isinstance(img, np.ndarray)):  # 判断是否OpenCV图片类型
        img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    # 创建一个可以在给定图像上绘图的对象
    draw = ImageDraw.Draw(img)
    # 字体的格式
    fontStyle = ImageFont.truetype(
        "stsong.ttf", textSize, encoding="utf-8")
    # 绘制文本
    draw.text((left, top), text, textColor, font=fontStyle)
    # 转换回OpenCV格式
    return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)


def countingitem(itemlist, item):
    result = itemlist.count(item)
    return result


def draw(image, box_data, resultclass, resultscore):
    # -------------------------------------------------------
    #   取整，方便画框
    # -------------------------------------------------------
    boxes = box_data[..., :4].astype(np.int32)
    scores = box_data[..., 4]
    classes = box_data[..., 5].astype(np.int32)

    img_height_o = image.shape[0]
    img_width_o = image.shape[1]
    x_ratio = img_width_o / 640
    y_ratio = img_height_o / 640

    for box, score, cl in zip(boxes, scores, classes):
        top, left, right, bottom = box
        # print('class: {}, score: {}'.format(CLASSES[cl], score))
        # print('box coordinate left,top,right,down: [{}, {}, {}, {}]'.format(top, left, right, bottom))
        resultclass.append(CLASSES[cl])
        resultscore.append(score)

        # 单独开一个参数返回计数塑料水瓶以及扁平塑料水瓶
        countbottle = countingitem(classes.tolist(), 6) + countingitem(classes.tolist(), 7) + countingitem(classes.tolist(), 9)
        countyilaguan = countingitem(classes.tolist(), 10) + countingitem(classes.tolist(), 11)

        top = int(top * x_ratio)
        right = int(right * x_ratio)
        left = int(left * y_ratio)
        bottom = int(bottom * y_ratio)

        cv2.rectangle(image, (top, left), (right, bottom), (255, 0, 0), 2)
        image = cv2ImgAddText(image, '{0} {1:.2f}'.format(CLASSES[cl], score), top, left, (205, 255, 50), 20)
        # cv2.putText(image, '{0} {1:.2f}'.format(CLASSES[cl], score),
        # (top, left),
        # cv2.FONT_HERSHEY_SIMPLEX,
        # 0.6, (0, 0, 255), 2)
    return image, countbottle, countyilaguan


def cv_image_to_base64(cv_image):
    header_info = "image/jpeg"  # 根据图片类型选择适当的MIME类型
    # 将OpenCV格式的图像转换为字节序列
    _, buffer = cv2.imencode('.jpg', cv_image)
    # 将字节序列编码为Base64字符串
    base64_string = f"data:{header_info};base64," + base64.b64encode(buffer).decode("utf-8")
    return base64_string


def calculate_area(thresh):
    # 查找轮廓
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # 计算总面积
    total_area = 0
    for contour in contours:
        total_area += cv2.contourArea(contour)

    return total_area


# 预加载模型
model = YOLOV5(onnx_path)  # 模型的输出85组成：x、y、w、h、前景得分、8个类别
# 预加载cuda，处理fake数据
first_image = cv2.imread('temp/345.png')
_, _ = model.inference(first_image)

# ___________________ zhangkun ___________________
classify_model = load_classify_model(cfg.EMPTY_WEIGHT_PATH)

# 读取占用摄像头流
cameras = list_video_devices()
matching_keys = [key for key, value in dict(cameras).items() if value == desired_value]

# 输出匹配的键
for key in matching_keys:
    print(key)

cap = cv2.VideoCapture(key)
if not cap.isOpened():
    exit()

app = FastAPI()
# 添加CORS中间件
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 定义全局变量
app.state.resultclass = []
app.state.resultscore = []
app.state.resultbox = []
app.state.Imgpath = []
app.state.Img_base64 = []


# 定义路由
@app.route("/model/RecycleDetection", methods=['POST', 'GET'])
async def get_frame(request: Request):
    output_log()

    # logging.info("**********************************************************")
    # 使用nvidia-smi命令获取GPU信息
    gpu_result = subprocess.check_output(['nvidia-smi', '--query-gpu=utilization.gpu', '--format=csv,noheader,nounits'])
    # 将结果解码为字符串并删除换行符
    gpu_usage = gpu_result.decode('utf-8').strip()
    # 输出GPU使用率到日志
    # logging.info(f"GPU 目前的使用量为: {gpu_usage}%")
    # 解析接收json
    data_json = await request.json()
    # 将收到的消息记录在log中
    # logging.info(f"接收到新请求：{data_json}")
    # 解析传来的json中的Data value
    ##signal:现在业务状态信号，orderID：订单号
    signal = data_json['type']
    orderID = data_json['order_id']
    goods = data_json['goods_name']

    # 定义返回json框架
    resultdata = {"Imgpath": None, "Img_base64": None, "ai_class": None, "ai_quality": False, "ai_score": None, "xraw_results": None, "ai_size": None, "ai_counting": None,
                  "ai_check": False}

    # if (signal == "weight"):
    # 取单张图片
    try:
        for i in range(1, 4):
            ret, frame = cap.read()
            if not ret:
                logging.error('读取流失败，未连接摄像头')
                logging.error('正在重复读取')
            else:
                break

        original_img = frame
        output, or_img = model.inference(original_img)
        # outbox的点的规则为: [left,top,right,bottom],为每个框的坐标点输出
        outbox = filter_box(output, 0.45, 0.4)
        if outbox.tolist() != []:
            for i in range(len(outbox.tolist())):
                app.state.resultbox.append(outbox.tolist()[i])

        try:
            after_img, countbottle, countyilaguan = draw(or_img, outbox, app.state.resultclass, app.state.resultscore)
            orderID_path, ori_img, infered_path, infered_img = output_imgs(orderID, signal, original_img, after_img)
            logging.info(f"水瓶数量:{countbottle}")
            resultdata['ai_counting'] = countbottle
            if goods == "易拉罐":
                logging.info(f"易拉罐数量:{countyilaguan}")
                resultdata['ai_counting'] = countyilaguan
        except Exception as e:
            # logging.info("图中未检测到物体")
            orderID_path, ori_img, infered_path, infered_img = output_imgs(orderID, signal, original_img, or_img)
        # 将路径中双斜杆替换为单斜杠
        orderID_path = orderID_path.replace('\\', '/')
        # 原图片
        # resultdata['Imgpath'] = orderID_path
        resultdata['Imgpath'] = infered_path

        # base64_data = cv_image_to_base64(ori_img)
        base64_data = cv_image_to_base64(infered_img)
        resultdata['Img_base64'] = base64_data

        app.state.Imgpath.append(orderID_path)
        app.state.Img_base64.append(base64_data)

        # 最终ai输出结果判别,目前考虑了袋装情况····
        # 通过逻辑要求输出类别以及类别综合
        # 通过求所有标签score的平均值求得此次类别总和的score
        # print('resultclass + allscore + allbox',app.config['resultclass'],app.config['resultscore'],app.config['resultbox'])

        # 推理出的结果
        logging.info(f"目前推理出的结果为: {app.state.resultclass, app.state.resultscore}%")
        # 将输出类别统一成集合
        set_resultclass = set(app.state.resultclass)

        if (len(set(app.state.resultscore)) != 0):
            # 求所有积分的平均值
            resultdata['ai_score'] = round((sum(app.state.resultscore) / len(app.state.resultscore)), 2)

        if (len(set_resultclass) == 1) and ('扎带' not in set_resultclass):
            '''
            假如只出现一个物品，考虑了出现袋装的情况
            '''
            item_class_results = []
            for item in set_resultclass:
                if item in item_class_mapping:
                    item_class, item_quality = item_class_mapping[item]
                    item_class_results.append(item_class)
                    unique_item_class_results = list(set(item_class_results))
                    resultdata['ai_class'] = unique_item_class_results
                    resultdata['ai_quality'] = item_quality
                    break

        elif ('扎带' in set_resultclass) and (len(set_resultclass) == 2) and ('袋装' not in set_resultclass):
            '''
            假如只出现一个物品，配一个扎带的情况，不出现袋装的情况
            '''
            item_class_results = []
            for item in set_resultclass:
                if item in item_class_mapping_ties:
                    item_class, item_quality = item_class_mapping_ties[item]
                    item_class_results.append(item_class)
                    unique_item_class_results = list(set(item_class_results))
                    resultdata['ai_class'] = unique_item_class_results
                    resultdata['ai_quality'] = item_quality
                    break

        elif (len(set_resultclass) >= 2):
            # 定义括号里面的详细内容
            detail = ''
            item_class_results = []
            # 判断混合类别的条件
            if ('塑料水瓶' in set_resultclass) or ('塑料水瓶扁' in set_resultclass) or ('袋装' in set_resultclass):

                # 发生如果有两种水瓶都存在的情况，视为只存在一个未踩扁的塑料瓶
                if ('塑料水瓶' in set_resultclass) and ('塑料水瓶扁' in set_resultclass) and (len(set_resultclass) == 2):
                    str_results = '单一，未踩扁'
                    item_class_results.append('塑料瓶')
                else:
                    str_results = '混合'
                    for i in set_resultclass:
                        if (i == '塑料水瓶') or (i == '塑料水瓶扁'):
                            item_class_results.append('塑料水瓶')
                        elif (i == '废纸板'):
                            item_class_results.append('废纸箱')
                        else:
                            item_class_results.append(i)

            elif ('废纸板' in set_resultclass) or ('废纸箱' in set_resultclass):
                str_results = '综合类'
                for i in set_resultclass:
                    if (i == '废纸板'):
                        item_class_results.append('废纸箱')
                    else:
                        item_class_results.append(i)

            else:
                str_results = '综合类'
                for i in set_resultclass:
                    item_class_results.append(i)

            # 将结果输出到返回的json中
            unique_item_class_results = list(set(item_class_results))
            resultdata['ai_class'] = unique_item_class_results
            if None in unique_item_class_results:
                unique_item_class_results = unique_item_class_results.remove(None)
            resultdata['ai_quality'] = str_results

        ###x光流程
        if (signal == "xray"):
            try:
                xraw_path = data_json['xray']
                dif_wid_height = app.state.resultbox
                # 提取前四位坐标
                points = [(item[0], item[1]) for item in dif_wid_height] + [(item[2], item[3]) for item in dif_wid_height]
                # 计算最小外接矩形
                minx, miny, maxw, maxh = cv2.boundingRect(np.array(points).astype(int))
                # 输出结果
                print(f"最小外接矩形的左上角坐标: ({minx}, {miny})")
                print(f"最小外接矩形的宽度和高度: {maxw}, {maxh}")
                # 映射长宽
                actual_object_width, actual_object_height = Calculate_wid(maxw, maxh)

                # 最右边这个坐标点横轴：minx + maxw
                max_right_point = minx + maxw
                height_item = Calculate_Height(xraw_path, 469, max_right_point, 1256)
                object_size = (actual_object_width, actual_object_height, height_item)
                resultdata['ai_size'] = object_size

            except Exception as e:
                logging.error(f"未收到x光图片的信息: {e}%")

            # 最后重置总框,#可取可不取x光图片
            app.state.resultclass = []
            app.state.resultscore = []
            app.state.resultbox = []
            app.state.Imgpath = []
            app.state.Img_base64 = []

        ###检查有无卸空流程
        if (signal == "check1"):

            # ___________________ zhangkun ___________________
            resultdata["ai_check"] = True  # 默认已经卸空 True

            ret, frame = cap.read()
            if not ret:
                logging.error('读取流失败，未连接摄像头')
            else:
                classify = classify_model.detect(frame, cfg.POINT_RECTANGULAR)
                if classify == cfg.NOT_EMPTY:
                    resultdata["ai_check"] = False
            # ___________________ zhangkun ___________________

            # 最后重置总框,#可取可不取x光图片
            app.state.resultclass = []
            app.state.resultscore = []
            app.state.resultbox = []
            app.state.Imgpath = []
            app.state.Img_base64 = []

        ###检查有无卸空流程
        if (signal == "check2"):

            # ___________________ zhangkun ___________________
            resultdata["ai_check"] = True  # 默认已经卸空 True

            ret, frame = cap.read()
            if not ret:
                logging.error('读取流失败，未连接摄像头')
            else:
                classify = classify_model.detect(frame, cfg.POINT_RECTANGULAR)
                if classify == cfg.NOT_EMPTY:
                    resultdata["ai_check"] = False
            # ___________________ zhangkun ___________________

            # 最后重置总框,#可取可不取x光图片
            app.state.resultclass = []
            app.state.resultscore = []
            app.state.resultbox = []
            app.state.Imgpath = []
            app.state.Img_base64 = []

        # 汇总回传，此回传json格式为所有json统一回传，所有回传都统一一个格式，只是参数中是否有对应信息。
        results = {"code": 200, "msg": "OK", "Data": resultdata}
        # result_all = json.dumps(results,ensure_ascii=False,sort_keys=False, indent=4, separators=(',', ': '))
        # logging.info(f"返回结果如下:{result_all}")
        # logging.info("**********************************************************")
    except Exception as e:
        results = {"code": 5001, "msg": "相机无法连接，无法正常获取画面", "Data": resultdata}
        logging.error(f"相机无法连接: {e}%")
    return JSONResponse(content=results)


def app_run():
    """
    启动服务
    """
    import uvicorn
    print('模型加载完毕、CUDA初始化成功')
    print('开始启动接口')
    uvicorn.run(app, host="127.0.0.1", port=8025)


if __name__ == "__main__":
    app_run()
