import datetime
import os
import time

import cv2
import numpy as np
import torch
import torch.nn.functional as F

from models.common import DetectMultiBackend
from utils.augmentations import classify_transforms
from utils.torch_utils import select_device
from zk import cfg


def remove_oldest_file(file_path, save_file_num):
    """
    按文件创建时间排序，保留时间最近的，将其余的删除
    """

    file_num = 0
    for root, dirs, files in os.walk(file_path):
        file_num = file_num + len(files)

    if file_num <= save_file_num:
        return

    file_list = []
    for root, dirs, files in os.walk(file_path):
        for file in files:
            _file_name = os.path.join(root, file)
            file_list.append((_file_name,
                              os.path.getctime(_file_name)))

    # 按创建时间排序
    file_list.sort(key=lambda x: x[1], reverse=True)

    for i in range(save_file_num, len(file_list)):
        os.remove(file_list[i][0])

    # 文件删除后再次清理空文件夹
    # 删除空文件夹
    # 遍历当前文件夹中的所有子文件夹和文件
    for root, dirs, files in os.walk(file_path, topdown=False):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            if not os.listdir(dir_path):
                os.rmdir(dir_path)


def save_image_hconcat(l_img, r_img, img_text):
    # ____________________ 图片粘贴拼接处理 ____________________

    l_h, l_w, _ = l_img.shape
    r_h, r_w, _ = r_img.shape
    bg_w = l_w + r_w
    bg_h = max(l_h, r_h)
    # background = np.zeros((bg_h, bg_w, 3), dtype=np.uint8)  # 黑色背景
    background = np.full((bg_h, bg_w, 3), 128, dtype=np.uint8)  # 灰色背景
    background[0:l_h, 0:l_w] = l_img
    background[0:r_h, l_w:l_w + r_w] = r_img
    cv2.putText(background, str(img_text), (int(bg_w * 0.10), int(bg_h * 0.10)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2, cv2.LINE_AA)

    # ____________________ 保存日志图片 ____________________

    time_now = datetime.datetime.now()
    time_str = time_now.strftime("%Y%m%d%H%M%S")
    _img_name = os.path.join(cfg.TEMP_IMAGE_PATH, f"img_{time_str}.png")
    cv2.imwrite(_img_name, background)
    remove_oldest_file(cfg.TEMP_IMAGE_PATH, cfg.TEMP_IMAGE_NUM)


class load_classify_model:
    def __init__(self, weight_path, imgsz=(224, 224)):
        self.weight_path = weight_path
        self.model = DetectMultiBackend(self.weight_path, device=select_device())
        self.model.eval()
        self.names = self.model.names
        self.transforms = classify_transforms(imgsz[0])
        print("YOLOv5空仓识别分类模型加载成功")

    def trapezoid(self, image, point):
        """
        矩形区域裁剪
        """

        img = image.copy()
        pts = np.array(point, np.int32)  # 定义梯形区域的四个顶点坐标
        pts = pts.reshape((-1, 1, 2))
        mask = np.zeros_like(img)  # 创建掩码
        cv2.fillPoly(mask, [pts], (255, 255, 255))
        result = cv2.bitwise_and(img, mask)  # 应用掩码到原始图片上
        x, y, w, h = cv2.boundingRect(pts)  # 获取裁剪区域的矩形边界
        cropped_result = result[y:y + h, x:x + w]  # 裁剪结果图片
        return cropped_result

    def rectangular_clipping(self, image, point_rectangular):
        # ____________ 读取裁剪区域 ____________

        points = point_rectangular.split("_")
        points = points[:16]

        # 将字符串列表转换为整数列表
        points_list = [int(x) for x in points]

        # 分割整数列表成左右两个部分
        l_point = [[points_list[i], points_list[i + 1]] for i in range(0, int(len(points_list) / 2), 2)]
        r_point = [[points_list[i], points_list[i + 1]] for i in range(8, len(points_list), 2)]

        # ____________ 处理图片 ____________

        l_result = self.trapezoid(image, l_point)
        r_result = self.trapezoid(image, r_point)

        # 确保两张图片的高度相同，可以根据需要调整大小
        height = min(l_result.shape[0], r_result.shape[0])
        l_result = l_result[:height]
        r_result = r_result[:height]

        # 水平拼接图片
        result = cv2.hconcat([l_result, r_result])
        return result

    def detect(self, im0, point_rectangular):
        l_img = im0.copy()  # 裁切前保存为左图
        im0 = self.rectangular_clipping(im0, point_rectangular)
        r_img = im0.copy()  # 裁切后保存为右图
        im = self.transforms(im0)
        im = torch.Tensor(im).to(self.model.device)
        im = im.half() if self.model.fp16 else im.float()  # uint8 to fp16/32
        if len(im.shape) == 3:
            im = im[None]  # expand for batch dim
        results = self.model(im)
        pred = F.softmax(results, dim=1)  # probabilities
        max_idx = torch.argmax(pred, dim=1).item()
        classify = self.names[max_idx]
        save_image_hconcat(l_img, r_img, classify)  # 保存图片
        return classify


if __name__ == '__main__':
    # prj_path = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
    # image_path = os.path.join(prj_path, "data", "test_image.jpg")
    # image = cv2.imread(image_path)

    # image = cv2.imread(r"D:\zhangkun_20240407\all_dataset\empty\empty_original_data\75_126_149_155_186_405_72_471_519_142_595_114_592_467_481_410_3.jpg")
    image = cv2.imread(r"D:\zhangkun_20240407\zk_temp\ff\2024_05_07_21_36_03_check1.jpg")
    classify_model = load_classify_model(cfg.EMPTY_WEIGHT_PATH)

    # time.sleep(10)
    start_time = time.time()
    classify = classify_model.detect(image, cfg.POINT_RECTANGULAR)
    print('time:', round((time.time() - start_time) * 1000, 2), "ms")
    print(classify)

    # l_img = cv2.imread(r"D:\zhangkun_20240407\zk_temp\aa.png")
    # r_img = cv2.imread(r"D:\zhangkun_20240407\zk_temp\bb.png")
    # save_image_hconcat(l_img, r_img, "img_text")
