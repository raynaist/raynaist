import os

PRJ_PATH = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）

EMPTY_WEIGHT_PATH = os.path.join(PRJ_PATH, "data", "empty_best.pt")
TEMP_IMAGE_PATH = os.path.join(PRJ_PATH, "data", "temp_image")
if not os.path.exists(TEMP_IMAGE_PATH):
    os.makedirs(TEMP_IMAGE_PATH)

TEMP_IMAGE_NUM = 200

# gjsq  jld  jmgj  jcsc  qsmj
SEPARATE_CFG_SELECT = 'gjsq'

"""
POINT_RECTANGULAR 16个点的含义解释：
    左边右边两个矩形区域的4+4个点xy坐标
    顶点顺序是左上角起顺时针方向1234个点
    数据依次为：左x1_左y1_左x2_左y2_左x3_左y3_左x4_左y4_右x1_右y1_右x2_右y2_右x3_右y3_右x4_右y4
"""

# # __________________ qsmj __________________
# qsmj = {}
# qsmj["POINT_RECTANGULAR"] = '000000'


# __________________ gjsq __________________
gjsq = {}
gjsq["POINT_RECTANGULAR"] = '76_96_142_117_179_393_70_468_530_124_584_107_577_467_477_398'

# __________________ jld __________________
jld = {}
jld["POINT_RECTANGULAR"] = '74_100_150_129_190_386_70_462_524_144_593_116_588_467_477_402'

# __________________ jmgj __________________
jmgj = {}
jmgj["POINT_RECTANGULAR"] = '65_121_147_143_184_408_66_465_521_138_592_110_593_467_483_410'

# __________________ 项目参数选择 __________________
separate_cfg = eval(SEPARATE_CFG_SELECT)
POINT_RECTANGULAR = separate_cfg["POINT_RECTANGULAR"]

EMPTY = "empty"  # 空
NOT_EMPTY = "not_empty"  # 非空

if __name__ == '__main__':
    print(EMPTY_WEIGHT_PATH)
    print(POINT_RECTANGULAR)
