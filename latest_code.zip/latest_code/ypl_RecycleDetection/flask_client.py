import json
import time
import requests

# 嗯传
Datajson = {"type":"xray","order_id":"7bfskch58796","xray":'./temp/123.png',"goods_name":"废纸箱"}
Datajson = json.dumps(Datajson,sort_keys=False, indent=4, separators=(',', ': '))

start_time = time.time()
r = requests.post("http://127.0.0.1:8025/model/RecycleDetection", data=Datajson)

data = r.json()
print('time:', (time.time() - start_time))
print(json.loads(r.text))
print(data)