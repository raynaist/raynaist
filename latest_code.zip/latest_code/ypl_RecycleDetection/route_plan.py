import heapq

# 定义移动方向
#上下左右
directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

# 启发函数（估计从当前点到终点的距离）
def heuristic(node,end):
    return abs(node[0] - end[0]) + abs(node[1] - end[1])

# A*算法
def astar(rows,cols,start,end,obstacles):
    # # 定义网格大小
    # rows, cols = 3, 3

    # # 定义起点和终点
    # start = (0, 0)
    # end = (2, 2)

    # # 定义障碍位置
    # obstacles = [(1, 1),(0, 1),(1,0)]
    open_list = [(0, start)]
    came_from = {}
    g_score = {pos: float('inf') for pos in [(r, c) for r in range(rows) for c in range(cols)]}
    g_score[start] = 0

    while open_list:
        _, current = heapq.heappop(open_list)

        if current == end:
            path = []
            while current in came_from:
                path.insert(0, current)
                current = came_from[current]
            path.insert(0, start)
            return path

        for dr, dc in directions:
            neighbor = (current[0] + dr, current[1] + dc)

            if neighbor[0] < 0 or neighbor[0] >= rows or neighbor[1] < 0 or neighbor[1] >= cols:
                continue

            if neighbor in obstacles:
                continue

            tentative_g_score = g_score[current] + 1

            if tentative_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g_score
                f_score = tentative_g_score + heuristic(neighbor,end)
                heapq.heappush(open_list, (f_score, neighbor))

    return None

def compress_path(path):
    #压缩直线路径
    if len(path) < 3:
        return path

    compressed_path = [path[0]]
    current_direction = (path[1][0] - path[0][0], path[1][1] - path[0][1])

    for i in range(2, len(path)):
        direction = (path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1])

        if direction == current_direction:
            continue  # 如果当前方向不变，保持前进
        else:
            compressed_path.append(path[i - 1])  # 如果方向变化，加入路径

        current_direction = direction
    
    compressed_path.append(path[-1])  # 加入最后一个点
    return compressed_path

if __name__ == '__main__':

    #astar(rows,cols,start,end,obstacles)
    path = astar(4, 4,(0, 0),(3, 3),[(0, 3),(2,2)])
    path1 = compress_path(path)
    
    if path:
        print("路径：", path)
        print("压缩之后的简便路径：", path1)
    else:
        print("遭堵死完了")