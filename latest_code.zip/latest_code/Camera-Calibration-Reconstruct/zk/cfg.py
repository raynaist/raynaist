import json
import os

from PyCameraList.camera_device import list_video_devices

# _______________________________________________________________________
# __________________________ 以下为单独配置项 ______________________________
# _______________________________________________________________________

# gjsq  jld  jmgj  jcsc  qsmj
SEPARATE_CFG_SELECT = 'qsmj'

# __________________ gjsq __________________

gjsq = {}

gjsq["device_value_left"] = 'WN CAMERA1080 TB'
gjsq["device_value_right"] = '789'

gjsq["LEFT_X1"] = 120
gjsq["LEFT_Y1"] = 110
gjsq["LEFT_X2"] = 520
gjsq["LEFT_Y2"] = 370

gjsq["RIGHT_X1"] = 140
gjsq["RIGHT_Y1"] = 140
gjsq["RIGHT_X2"] = 470
gjsq["RIGHT_Y2"] = 360

gjsq["REAL_POINT_DATA"] = ' [\
    {"name": "101", "x": 1221, "y": 125},\
    {"name": "102", "x": 1969, "y": 125},\
    {"name": "103", "x": 2404, "y": 125},\
    {"name": "104", "x": 3280, "y": 125},\
    {"name": "105", "x": 3700, "y": 125},\
    {"name": "201", "x": 1221, "y": 638},\
    {"name": "202", "x": 1969, "y": 638},\
    {"name": "203", "x": 2404, "y": 638},\
    {"name": "204", "x": 3280, "y": 638},\
    {"name": "205", "x": 3700, "y": 638},\
    {"name": "301", "x": 1221, "y": 1150},\
    {"name": "302", "x": 1969, "y": 1150},\
    {"name": "303", "x": 2404, "y": 1150},\
    {"name": "304", "x": 3280, "y": 1150},\
    {"name": "305", "x": 3700, "y": 1150},\
    {"name": "000", "x": 125, "y": 125},\
    {"name": "300", "x": 106, "y": 1100}\
    ]'

gjsq["LEFT_STORE_FULL"] = 1100  # 仓储已满
gjsq["LEFT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱
gjsq["RIGHT_STORE_FULL"] = 1100  # 仓储已满
gjsq["RIGHT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱

# __________________ qsmj __________________

qsmj = {}

qsmj["device_value_left"] = 'WN CAMERA1080 TB'
qsmj["device_value_right"] = '789'

qsmj["LEFT_X1"] = 150
qsmj["LEFT_Y1"] = 140
qsmj["LEFT_X2"] = 490
qsmj["LEFT_Y2"] = 390

qsmj["RIGHT_X1"] = 120
qsmj["RIGHT_Y1"] = 130
qsmj["RIGHT_X2"] = 490
qsmj["RIGHT_Y2"] = 370

qsmj["REAL_POINT_DATA"] = ' [\
    {"name": "101", "x": 1221, "y": 125},\
    {"name": "102", "x": 1969, "y": 125},\
    {"name": "103", "x": 2404, "y": 125},\
    {"name": "104", "x": 3280, "y": 125},\
    {"name": "105", "x": 3700, "y": 125},\
    {"name": "201", "x": 1221, "y": 638},\
    {"name": "202", "x": 1969, "y": 638},\
    {"name": "203", "x": 2404, "y": 638},\
    {"name": "204", "x": 3280, "y": 638},\
    {"name": "205", "x": 3700, "y": 638},\
    {"name": "301", "x": 1221, "y": 1150},\
    {"name": "302", "x": 1969, "y": 1150},\
    {"name": "303", "x": 2404, "y": 1150},\
    {"name": "304", "x": 3280, "y": 1150},\
    {"name": "305", "x": 3700, "y": 1150},\
    {"name": "000", "x": 125, "y": 125},\
    {"name": "300", "x": 113, "y": 1182}\
    ]'

qsmj["LEFT_STORE_FULL"] = 1100  # 仓储已满
qsmj["LEFT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱
qsmj["RIGHT_STORE_FULL"] = 1100  # 仓储已满
qsmj["RIGHT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱

# __________________ qsmj __________________

qsmj = {}

qsmj["device_value_left"] = 'WN CAMERA1080 TB'
qsmj["device_value_right"] = '789'

qsmj["LEFT_X1"] = 150
qsmj["LEFT_Y1"] = 140
qsmj["LEFT_X2"] = 490
qsmj["LEFT_Y2"] = 390

qsmj["RIGHT_X1"] = 120
qsmj["RIGHT_Y1"] = 130
qsmj["RIGHT_X2"] = 490
qsmj["RIGHT_Y2"] = 370

qsmj["REAL_POINT_DATA"] = ' [\
    {"name": "101", "x": 1221, "y": 125},\
    {"name": "102", "x": 1969, "y": 125},\
    {"name": "103", "x": 2404, "y": 125},\
    {"name": "104", "x": 3280, "y": 125},\
    {"name": "105", "x": 3700, "y": 125},\
    {"name": "201", "x": 1221, "y": 638},\
    {"name": "202", "x": 1969, "y": 638},\
    {"name": "203", "x": 2404, "y": 638},\
    {"name": "204", "x": 3280, "y": 638},\
    {"name": "205", "x": 3700, "y": 638},\
    {"name": "301", "x": 1221, "y": 1150},\
    {"name": "302", "x": 1969, "y": 1150},\
    {"name": "303", "x": 2404, "y": 1150},\
    {"name": "304", "x": 3280, "y": 1150},\
    {"name": "305", "x": 3700, "y": 1150},\
    {"name": "000", "x": 125, "y": 125},\
    {"name": "300", "x": 113, "y": 1182}\
    ]'

qsmj["LEFT_STORE_FULL"] = 1100  # 仓储已满
qsmj["LEFT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱
qsmj["RIGHT_STORE_FULL"] = 1100  # 仓储已满
qsmj["RIGHT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱

# __________________ jcsc __________________

jcsc = {}

jcsc["device_value_left"] = 'WN CAMERA1080 TB'
jcsc["device_value_right"] = 'USB Video Device'

jcsc["LEFT_X1"] = 260
jcsc["LEFT_Y1"] = 150
jcsc["LEFT_X2"] = 525
jcsc["LEFT_Y2"] = 380

jcsc["RIGHT_X1"] = 150
jcsc["RIGHT_Y1"] = 130
jcsc["RIGHT_X2"] = 500
jcsc["RIGHT_Y2"] = 390

jcsc["REAL_POINT_DATA"] = ' [\
    {"name": "101", "x": 1221, "y": 125},\
    {"name": "102", "x": 1969, "y": 125},\
    {"name": "103", "x": 2404, "y": 125},\
    {"name": "104", "x": 3280, "y": 125},\
    {"name": "105", "x": 3700, "y": 125},\
    {"name": "201", "x": 1221, "y": 638},\
    {"name": "202", "x": 1969, "y": 638},\
    {"name": "203", "x": 2404, "y": 638},\
    {"name": "204", "x": 3280, "y": 638},\
    {"name": "205", "x": 3700, "y": 638},\
    {"name": "301", "x": 1221, "y": 1150},\
    {"name": "302", "x": 1969, "y": 1150},\
    {"name": "303", "x": 2404, "y": 1150},\
    {"name": "304", "x": 3280, "y": 1150},\
    {"name": "305", "x": 3700, "y": 1150},\
    {"name": "000", "x": 125, "y": 125},\
    {"name": "300", "x": 113, "y": 1182}\
    ]'

jcsc["LEFT_STORE_FULL"] = 1100  # 仓储已满
jcsc["LEFT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱
jcsc["RIGHT_STORE_FULL"] = 1100  # 仓储已满
jcsc["RIGHT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱

# __________________ jld __________________

jld = {}

jld["device_value_left"] = 'WN CAMERA1080 TB'
jld["device_value_right"] = '789'

jld["LEFT_X1"] = 135
jld["LEFT_Y1"] = 120
jld["LEFT_X2"] = 540
jld["LEFT_Y2"] = 380

jld["RIGHT_X1"] = 150
jld["RIGHT_Y1"] = 130
jld["RIGHT_X2"] = 500
jld["RIGHT_Y2"] = 390

jld["REAL_POINT_DATA"] = '  [\
    {"name": "101", "x": 1221, "y": 125},\
    {"name": "102", "x": 1969, "y": 125},\
    {"name": "103", "x": 2404, "y": 125},\
    {"name": "104", "x": 3280, "y": 125},\
    {"name": "105", "x": 3700, "y": 125},\
    {"name": "201", "x": 1221, "y": 638},\
    {"name": "202", "x": 1969, "y": 638},\
    {"name": "203", "x": 2404, "y": 638},\
    {"name": "204", "x": 3280, "y": 638},\
    {"name": "205", "x": 3700, "y": 638},\
    {"name": "301", "x": 1221, "y": 1150},\
    {"name": "302", "x": 1969, "y": 1150},\
    {"name": "303", "x": 2404, "y": 1150},\
    {"name": "304", "x": 3280, "y": 1150},\
    {"name": "305", "x": 3700, "y": 1150},\
    {"name": "000", "x": 125, "y": 125},\
    {"name": "300", "x": 97, "y": 1000}\
    ]'

jld["LEFT_STORE_FULL"] = 1100  # 仓储已满
jld["LEFT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱
jld["RIGHT_STORE_FULL"] = 1100  # 仓储已满
jld["RIGHT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱

# __________________ jmgj __________________

jmgj = {}

jmgj["device_value_left"] = '789'
jmgj["device_value_right"] = 'WN CAMERA1080 TB'

jmgj["LEFT_X1"] = 150
jmgj["LEFT_Y1"] = 130
jmgj["LEFT_X2"] = 500
jmgj["LEFT_Y2"] = 390

jmgj["RIGHT_X1"] = 150
jmgj["RIGHT_Y1"] = 130
jmgj["RIGHT_X2"] = 500
jmgj["RIGHT_Y2"] = 390

jmgj["REAL_POINT_DATA"] = ' [\
    {"name": "101", "x": 1221, "y": 125},\
    {"name": "102", "x": 1969, "y": 125},\
    {"name": "103", "x": 2404, "y": 125},\
    {"name": "104", "x": 3280, "y": 125},\
    {"name": "105", "x": 3700, "y": 125},\
    {"name": "201", "x": 1221, "y": 638},\
    {"name": "202", "x": 1969, "y": 638},\
    {"name": "203", "x": 2404, "y": 638},\
    {"name": "204", "x": 3280, "y": 638},\
    {"name": "205", "x": 3700, "y": 638},\
    {"name": "301", "x": 1221, "y": 1150},\
    {"name": "302", "x": 1969, "y": 1150},\
    {"name": "303", "x": 2404, "y": 1150},\
    {"name": "304", "x": 3280, "y": 1150},\
    {"name": "305", "x": 3700, "y": 1150},\
    {"name": "000", "x": 125, "y": 125},\
    {"name": "300", "x": 101, "y": 1000}\
    ] '

jmgj["LEFT_STORE_FULL"] = 1100  # 仓储已满
jmgj["LEFT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱
jmgj["RIGHT_STORE_FULL"] = 1100  # 仓储已满
jmgj["RIGHT_LIFT_NACELLE"] = 1500  # 需要抬升吊舱

# __________________ 项目参数选择 __________________
separate_cfg = eval(SEPARATE_CFG_SELECT)

device_value_left = separate_cfg["device_value_left"]
device_value_right = separate_cfg["device_value_right"]
LEFT_X1 = separate_cfg["LEFT_X1"]
LEFT_Y1 = separate_cfg["LEFT_Y1"]
LEFT_X2 = separate_cfg["LEFT_X2"]
LEFT_Y2 = separate_cfg["LEFT_Y2"]
RIGHT_X1 = separate_cfg["RIGHT_X1"]
RIGHT_Y1 = separate_cfg["RIGHT_Y1"]
RIGHT_X2 = separate_cfg["RIGHT_X2"]
RIGHT_Y2 = separate_cfg["RIGHT_Y2"]
REAL_POINT_DATA = separate_cfg["REAL_POINT_DATA"]
LEFT_STORE_FULL = separate_cfg["LEFT_STORE_FULL"]
LEFT_LIFT_NACELLE = separate_cfg["LEFT_LIFT_NACELLE"]
RIGHT_STORE_FULL = separate_cfg["RIGHT_STORE_FULL"]
RIGHT_LIFT_NACELLE = separate_cfg["RIGHT_LIFT_NACELLE"]

# _______________________________________________________________________
# __________________________ 以下为通用配置项 ______________________________
# _______________________________________________________________________


SMALL_RECT_ROW = 2
SMALL_RECT_COL = 3

# 每隔 5 帧抽一张图片用于计算，一共抽30张
FRAME_SAMPLE_TOTAL = 30  # 抽帧图片总数
FRAME_SAMPLE_TIME_INTERVAL = 5  # 抽帧图片时间间隔

IMG_WIDTH = 640
IMG_HEIGHT = 480

LOG_FILE_TIME = 7 * 24  # 日志文件保留时间

# __________________ 输出路径设置 __________________

PRJ_PATH = os.path.dirname(os.path.abspath(__file__))  # 当前文件的上一级的上一级目录（增加一级）
LOG_PATH = os.path.join(PRJ_PATH, "data", "log")  # 在项目路径下创建一个log文件夹, 拼接成路径格式

HCONCAT_IMG_PATH = os.path.join(PRJ_PATH, "data", "order_depth_img")

if not os.path.exists(LOG_PATH):
    os.makedirs(LOG_PATH)

if not os.path.exists(HCONCAT_IMG_PATH):
    os.makedirs(HCONCAT_IMG_PATH)

# 侦测出来的路径信息保存位置
STORE_POSITION_TXT = os.path.join(PRJ_PATH, "data", "store_position.txt")
STORE_POSITION_TIME_STAMP_TXT = os.path.join(PRJ_PATH, "data", "store_position_time_stamp.txt")

# 单位：秒，仓储信息有效时间，避免短时间多次重复检测导致相机占用打开失败
STORE_POSITION_EXPIRATION_TIME = 60 * 2

# __________________ 相机编号设置 __________________

cameras = list_video_devices()

matching_keys_left = [key for key, value in dict(cameras).items() if value == device_value_left]
matching_keys_right = [key for key, value in dict(cameras).items() if value == device_value_right]

try:
    # 判断是参数是直接写的相机ID还是写的相机名称
    if isinstance(device_value_left, int):
        LEFT_CAMERA_ID = device_value_left
    else:
        LEFT_CAMERA_ID = matching_keys_left[0]
except IndexError:
    LEFT_CAMERA_ID = "error"  # 相机掉线报错处理

try:
    # 判断是参数是直接写的相机ID还是写的相机名称
    if isinstance(device_value_right, int):
        RIGHT_CAMERA_ID = device_value_right
    else:
        RIGHT_CAMERA_ID = matching_keys_right[0]
except IndexError:
    RIGHT_CAMERA_ID = "error"  # 相机掉线报错处理

LEFT_CAMERA_CALIBRATION = os.path.join(PRJ_PATH, "stereo_cam_left.yml")
RIGHT_CAMERA_CALIBRATION = os.path.join(PRJ_PATH, "stereo_cam_right.yml")

# __________________ 实际点位对应关系设置 __________________

_real_point_data = json.loads(REAL_POINT_DATA)
_point_position = {}
for _point in _real_point_data:
    name = _point['name']
    x = _point['x']
    y = _point['y']
    _point_position[name] = (x, y)

LEFT_POINT_CORRESPONDING = {}
LEFT_POINT_CORRESPONDING[1] = _point_position['302']
LEFT_POINT_CORRESPONDING[3] = _point_position['102']

LEFT_POINT_CORRESPONDING[4] = _point_position['303']
LEFT_POINT_CORRESPONDING[6] = _point_position['103']

LEFT_POINT_CORRESPONDING[2] = _point_position['202']
LEFT_POINT_CORRESPONDING[5] = _point_position['203']

RIGHT_POINT_CORRESPONDING = {}
RIGHT_POINT_CORRESPONDING[1] = _point_position['304']
RIGHT_POINT_CORRESPONDING[3] = _point_position['104']

RIGHT_POINT_CORRESPONDING[4] = _point_position['305']
RIGHT_POINT_CORRESPONDING[6] = _point_position['105']

RIGHT_POINT_CORRESPONDING[2] = _point_position['204']
RIGHT_POINT_CORRESPONDING[5] = _point_position['205']

# 避障优先级计算顺序
OBSTACLE_AVOIDANCE = [
    ("right_avg_result.loc[4, 'average_value']", "cfg.RIGHT_STORE_FULL", "right", 4, "cfg.RIGHT_POINT_CORRESPONDING"),
    ("right_avg_result.loc[1, 'average_value']", "cfg.RIGHT_STORE_FULL", "right", 1, "cfg.RIGHT_POINT_CORRESPONDING"),
    ("right_avg_result.loc[5, 'average_value']", "cfg.RIGHT_STORE_FULL", "right", 5, "cfg.RIGHT_POINT_CORRESPONDING"),
    ("right_avg_result.loc[2, 'average_value']", "cfg.RIGHT_STORE_FULL", "right", 2, "cfg.RIGHT_POINT_CORRESPONDING"),
    ("right_avg_result.loc[6, 'average_value']", "cfg.RIGHT_STORE_FULL", "right", 6, "cfg.RIGHT_POINT_CORRESPONDING"),
    ("right_avg_result.loc[3, 'average_value']", "cfg.RIGHT_STORE_FULL", "right", 3, "cfg.RIGHT_POINT_CORRESPONDING"),

    ("left_avg_result.loc[4, 'average_value']", "cfg.LEFT_STORE_FULL", "left", 4, "cfg.LEFT_POINT_CORRESPONDING"),
    ("left_avg_result.loc[1, 'average_value']", "cfg.LEFT_STORE_FULL", "left", 1, "cfg.LEFT_POINT_CORRESPONDING"),
    ("left_avg_result.loc[5, 'average_value']", "cfg.LEFT_STORE_FULL", "left", 5, "cfg.LEFT_POINT_CORRESPONDING"),
    ("left_avg_result.loc[2, 'average_value']", "cfg.LEFT_STORE_FULL", "left", 2, "cfg.LEFT_POINT_CORRESPONDING"),
    ("left_avg_result.loc[6, 'average_value']", "cfg.LEFT_STORE_FULL", "left", 6, "cfg.LEFT_POINT_CORRESPONDING"),
    ("left_avg_result.loc[3, 'average_value']", "cfg.LEFT_STORE_FULL", "left", 3, "cfg.LEFT_POINT_CORRESPONDING")]

# 仓储已满 index 报错码
FULL_INDEX = 9999

if __name__ == '__main__':
    print(RIGHT_POINT_CORRESPONDING)
    print(_point_position)
