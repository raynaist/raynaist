try:
    # TODO 在识别模型中调用
    # 调用仓储识别脚本
    import os

    os.system(r'start /B cmd /C "D:\zhangkun_20240407\pycharm_code_20240407\Camera-Calibration-Reconstruct\zk\call_stereo_camera.bat"')
except Exception as e:
    # print(e)
    pass
