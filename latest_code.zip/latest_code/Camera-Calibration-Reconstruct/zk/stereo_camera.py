import cv2
import datetime
import logging
import numpy as np
import os
import pandas as pd
import time
from datetime import datetime as dt

import cfg
from core import camera_params, stereo_matcher
from core.utils import image_utils


def output_log():
    """
    log日志
    :return:
    """

    # 在log文件夹下再创建一个以当前日期命名的文件夹
    log_date_path = os.path.join(cfg.LOG_PATH, time.strftime('%Y_%m_%d', time.localtime(time.time())))
    if not os.path.exists(log_date_path):
        os.makedirs(log_date_path)

    # 创建一个logger(初始化logger)
    log = logging.getLogger()

    # 检查并清除已有的处理器
    if log.hasHandlers():
        log.handlers.clear()

    log.setLevel(logging.DEBUG)

    try:
        # 创建一个handler，用于写入日志文件
        current_time = time.strftime('%Y_%m_%d_%H', time.localtime(time.time()))  # 返回当前时间
        log_name = os.path.join(log_date_path, current_time + '.log')

        fh = logging.FileHandler(log_name)
        fh.setLevel(logging.DEBUG)

        # 定义handler的输出格式
        formatter = logging.Formatter('[%(asctime)s] - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        # 给logger添加handler
        log.addHandler(fh)

    except Exception as e:
        print("输出日志失败！", e)


def remove_oldest_file(file_path, save_file_num=None, save_file_time=cfg.LOG_FILE_TIME):
    """
    按文件最后修改时间排序，保留最近的，将其余的删除
    :param file_path:
    :param save_file_num: 文件保留数量
    :param save_file_time: 文件保留时间，单位：小时
    :return:
    """

    # ____________________ 文件信息 ____________________

    file_num = 0
    file_list = []
    for root, dirs, files in os.walk(file_path):
        file_num = file_num + len(files)
        for file in files:
            _file_name = os.path.join(root, file)
            file_list.append((_file_name,
                              os.path.getmtime(_file_name)))  # 文件最后修改时间

    # 按时间排序
    file_list.sort(key=lambda x: x[1], reverse=True)

    # ____________________ 按保留数量删除旧文件 ____________________
    if save_file_num is not None:
        if file_num > save_file_num:
            for i in range(save_file_num, file_num):
                os.remove(file_list[i][0])

    # ____________________ 按保留时间删除旧文件 ____________________
    if save_file_time is not None:
        save_file_time = save_file_time * 60 * 60  # 传入小时转换为秒
        time_now = time.time()

        for _fl in file_list:
            _file_name = _fl[0]
            _mtime = _fl[1]

            # 时间判断
            if time_now - _mtime > save_file_time:
                os.remove(_file_name)

    # ____________________ 删除空文件夹 ____________________
    # 文件删除后再次清理空文件夹
    # 删除空文件夹
    # 遍历当前文件夹中的所有子文件夹和文件
    for root, dirs, files in os.walk(file_path, topdown=False):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            if not os.listdir(dir_path):
                os.rmdir(dir_path)


def small_rect(video, x1=50, y1=80, x2=200, y2=300, img=None, small_rect_row=cfg.SMALL_RECT_ROW, small_rect_col=cfg.SMALL_RECT_COL, depth=None):
    """
    将大图片在指定区域内划分小格子，几行几列
    并添加文字
    """

    # 计算小矩形的大小和位置
    rect_width = int((x2 - x1) // small_rect_col)
    rect_height = int((y2 - y1) // small_rect_row)

    start_x1 = x1
    start_y1 = y1

    # 画出小矩形
    all_rect = []
    average_value = None
    storage_idx = 1
    for i in range(small_rect_row):
        for j in range(small_rect_col):
            x1 = start_x1 + j * rect_width
            y1 = start_y1 + i * rect_height
            x2 = x1 + rect_width
            y2 = y1 + rect_height

            if img is not None:
                cv2.rectangle(img, (x1, y1), (x2, y2), (255, 255, 255), 2)
                cv2.putText(img, str(storage_idx), ((x1 + rect_width // 2), (y1 + rect_height // 2)), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 3, cv2.LINE_AA)
                cv2.putText(img, str(video), (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 3, cv2.LINE_AA)

            if depth is not None:
                roi = depth[y1:y2, x1:x2]  # 提取矩形内的数据
                valid_data = roi[np.isfinite(roi)]  # 过滤掉非数字值
                average_value = np.mean(valid_data)  # 计算提取数据的平均值
                cv2.putText(img, str(average_value), (int(x1 + rect_width * 0.4), int(y1 + rect_height * 0.7)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)

            all_rect.append([x1, y1, x2, y2, storage_idx, average_value])
            storage_idx = storage_idx + 1

    return all_rect, img


class ZsznStereoDepth(object):
    """双目测距"""

    def __init__(self, stereo_file, width=640, height=480, wsl_filter=True):
        """
        :param stereo_file: 双目相机内外参数配置文件
        :param width: 相机分辨率width
        :param height:相机分辨率height
        :param wsl_filter: 是否使用WLS滤波器对视差图进行滤波
        :param use_open3d: 是否使用open3d显示点云
        :param use_pcl: 是否使用PCL显示点云
        """
        self.count = 0
        self.wsl_filter = wsl_filter
        self.camera_config = camera_params.get_stereo_coefficients(stereo_file)

        assert (width, height) == self.camera_config["size"], Exception("Error:{}".format(self.camera_config["size"]))

    def capture_stereo(self, position, video, x1, y1, x2, y2, save_hconcat=False):
        """
        用于采集单USB连接线的双目摄像头(左右摄像头被拼接在同一个视频中显示)
        :param video:int or str,视频路径或者摄像头ID
        :param save_dir: str,保存左右图片的路径
        """
        cap = image_utils.get_video_capture(video, width=cfg.IMG_WIDTH * 2, height=cfg.IMG_HEIGHT)

        width, height, numFrames, fps = image_utils.get_video_info(cap)

        frame_num = 1
        avg_depth = []
        frameL = None
        depth_colormap = None

        while True:
            success, frame = cap.read()
            if not success:
                break

            # 高家社区单独配置，右边镜头相反
            if cfg.SEPARATE_CFG_SELECT == "gjsq" and position == "right":
                frame = cv2.flip(frame, -1)

            if frame_num % cfg.FRAME_SAMPLE_TIME_INTERVAL == 0:
                frameL = frame[:, :int(width / 2), :]
                frameR = frame[:, int(width / 2):, :]
                all_rect, depth_colormap = self.task((video if len(str(video)) <= 3 else len(str(video))),
                                                     frameL, frameR, x1, y1, x2, y2)

                avg_depth.append(all_rect)

                if len(avg_depth) >= cfg.FRAME_SAMPLE_TOTAL:
                    break

            frame_num = frame_num + 1

        if save_hconcat and frameL is not None and depth_colormap is not None:
            hconcat_img = cv2.hconcat([frameL, depth_colormap])

            time_now = datetime.datetime.now()
            time_str = time_now.strftime("%Y%m%d%H%M%S")

            # 判断 video 是用相机ID 0 1 2 传参还是 使用的视频路径传参
            if len(str(video)) <= 3:
                hconcat_img_name = os.path.join(cfg.HCONCAT_IMG_PATH, f"depth_{video}_{time_str}.jpg")
            else:
                hconcat_img_name = os.path.join(cfg.HCONCAT_IMG_PATH, f"depth_{len(str(video))}_{time_str}.jpg")

            cv2.imwrite(hconcat_img_name, hconcat_img)

            remove_oldest_file(cfg.HCONCAT_IMG_PATH)

        cap.release()

        return avg_depth

    def get_rectify_image(self, imgL, imgR):
        """
        畸变校正和立体校正
        根据更正map对图片进行重构
        获取用于畸变校正和立体校正的映射矩阵以及用于计算像素空间坐标的重投影矩阵
        :param imgL:
        :param imgR:
        :return:
        """
        # camera_params.get_rectify_transform(K1, D1, K2, D2, R, T, image_size)
        left_map_x, left_map_y = self.camera_config["left_map_x"], self.camera_config["left_map_y"]
        right_map_x, right_map_y = self.camera_config["right_map_x"], self.camera_config["right_map_y"]
        rectifiedL = cv2.remap(imgL, left_map_x, left_map_y, cv2.INTER_LINEAR, borderValue=cv2.BORDER_CONSTANT)
        rectifiedR = cv2.remap(imgR, right_map_x, right_map_y, cv2.INTER_LINEAR, borderValue=cv2.BORDER_CONSTANT)
        return rectifiedL, rectifiedR

    def get_3dpoints(self, disparity, Q, scale=1.0):
        """
        计算像素点的3D坐标（左相机坐标系下）
        reprojectImageTo3D(disparity, Q),输入的Q,单位必须是毫米(mm)
        :param disparity: 视差图
        :param Q: 重投影矩阵Q=[[1, 0, 0, -cx]
                           [0, 1, 0, -cy]
                           [0, 0, 0,  f]
                           [1, 0, -1/Tx, (cx-cx`)/Tx]]
            其中f为焦距，Tx相当于平移向量T的第一个参数
        :param scale: 单位变换尺度,默认scale=1.0,单位为毫米
        :return points_3d:ndarray(np.float32),返回三维坐标points_3d，三个通道分布表示(X,Y,Z)
                    其中Z是深度图depth, 即距离,单位是毫米(mm)
        """
        # 返回三维坐标points_3d，三个通道分布表示(X,Y,Z)
        # depth = stereo_matcher.get_depth(disparity, Q, scale=1.0)
        points_3d = cv2.reprojectImageTo3D(disparity, Q)
        # x, y, depth = cv2.split(points_3d)
        # baseline = abs(camera_config["T"][0])
        # baseline = 1 / Q[3, 2]  # 基线也可以由T[0]计算
        # fx = abs(Q[2, 3])
        # depth = (fx * baseline) / disparity
        points_3d = points_3d * scale
        points_3d = np.asarray(points_3d, dtype=np.float32)
        return points_3d

    def get_disparity(self, imgL, imgR, use_wls=True):
        """
        :param imgL: 畸变校正和立体校正后的左视图
        :param imgR：畸变校正和立体校正后的右视图
        :param use_wls：是否使用WLS滤波器对视差图进行滤波
        :return dispL:ndarray(np.float32),返回视差图
        """
        dispL = stereo_matcher.get_filter_disparity(imgL, imgR, use_wls=use_wls)
        # dispL = disparity.get_simple_disparity(imgL, imgR)
        return dispL

    def task(self, video, frameL, frameR, x1, y1, x2, y2):
        """
        :param frameL: 左路视频帧图像(BGR)
        :param frameR: 右路视频帧图像(BGR)
        """

        # 畸变校正和立体校正
        rectifiedL, rectifiedR = self.get_rectify_image(imgL=frameL, imgR=frameR)

        # We need grayscale for disparity map.
        grayL = cv2.cvtColor(rectifiedL, cv2.COLOR_BGR2GRAY)
        grayR = cv2.cvtColor(rectifiedR, cv2.COLOR_BGR2GRAY)
        # Get the disparity map
        dispL = self.get_disparity(grayL, grayR, self.wsl_filter)
        points_3d = self.get_3dpoints(disparity=dispL, Q=self.camera_config["Q"])

        x, y, depth = cv2.split(points_3d)  # depth = points_3d[:, :, 2]
        depth_colormap = stereo_matcher.get_visual_depth(depth)
        all_rect, depth_colormap = small_rect(video=video, x1=x1, y1=y1, x2=x2, y2=y2, img=depth_colormap, depth=depth)
        return all_rect, depth_colormap


def get_depth(position, camera_id, camera_calibration, x1, y1, x2, y2):
    stereo_depth = ZsznStereoDepth(camera_calibration)
    all_depth = stereo_depth.capture_stereo(position, camera_id, x1, y1, x2, y2, save_hconcat=True)

    # x1, y1, x2, y2, storage_idx, average_value

    depth_list = []
    for _depth in all_depth:
        for _de in _depth:
            _x1 = _de[0]
            _y1 = _de[1]
            _x2 = _de[2]
            _y2 = _de[3]
            _storage_idx = _de[4]
            _average_value = _de[5]

            depth_list.append([_x1, _y1, _x2, _y2, _storage_idx, _average_value])

    # 转换为DataFrame
    df = pd.DataFrame(depth_list, columns=['x1', 'y1', 'x2', 'y2', 'storage_idx', 'average_value'])

    # 按照第一列进行分组并求平均值
    avg_result = df.groupby('storage_idx').mean()
    avg_result = avg_result.sort_values(by='average_value', ascending=False)

    return avg_result


def check_camera(camera_id):
    try:
        capture = cv2.VideoCapture(camera_id)
        if not capture.isOpened():
            return False

        ret, frame = capture.read()
        if not ret:
            return False

        capture.release()
        return True

    except Exception:
        return False


def calculate_real_position():
    # ___________________________ 仓储信息有效时间判断处理，避免短时间多次重复检测导致相机占用打开失败 ___________________________

    try:
        # 读取已经保存的仓储信息
        with open(cfg.STORE_POSITION_TIME_STAMP_TXT, 'r') as f:
            store_position = eval(f.readline())
            f.close()

        # 读取已有的仓储信息，如果在有效期内，则直接使用，否则继续向下执行，更新信息
        time_stamp = store_position["time_stamp"]
        txt_time = dt.strptime(time_stamp, "%Y%m%d%H%M%S")
        current_time = dt.now()  # 获取当前时间
        time_diff = current_time - txt_time  # 计算时间差
        seconds_diff = time_diff.total_seconds()  # 将时间差转换为秒数

        # 仓储信息在有效期内，退出主程序
        if seconds_diff < cfg.STORE_POSITION_EXPIRATION_TIME:
            exit()

    except Exception as e:
        # 不存在已有的仓储信息，继续向下执行更新仓储
        pass

    # _________________ 先将时间戳保存，告诉其他任务，仓储识别流程已经在执行中 _________________

    time_result = {}
    time_now = datetime.datetime.now()
    time_str = time_now.strftime("%Y%m%d%H%M%S")
    time_result["time_stamp"] = time_str
    with open(cfg.STORE_POSITION_TIME_STAMP_TXT, 'w', encoding="utf-8") as f:
        f.writelines(str(time_result))
        f.flush()
        f.close()

    # ___________________________ 相机检查 ___________________________
    # 处理相机在线但是被占用无法打开的情况

    left_camera_status = check_camera(cfg.LEFT_CAMERA_ID)
    right_camera_status = check_camera(cfg.RIGHT_CAMERA_ID)

    if left_camera_status == False and right_camera_status == False:
        logging.info(f"两个相机都无法打开，清空之前存储的位置信息，LEFT_CAMERA_ID：{cfg.LEFT_CAMERA_ID}，RIGHT_CAMERA_ID：{cfg.RIGHT_CAMERA_ID}")

        # 清空位置txt
        with open(cfg.STORE_POSITION_TXT, 'w', encoding="utf-8") as f:
            f.truncate(0)
            f.flush()
            f.close()

        # 清空时间戳txt
        with open(cfg.STORE_POSITION_TIME_STAMP_TXT, 'w', encoding="utf-8") as f:
            f.truncate(0)
            f.flush()
            f.close()

        exit()

    elif left_camera_status == False:
        logging.info(f"左边相机无法打开，LEFT_CAMERA_ID：{cfg.LEFT_CAMERA_ID}")

    elif right_camera_status == False:
        logging.info(f"右边相机无法打开，RIGHT_CAMERA_ID：{cfg.RIGHT_CAMERA_ID}")

    # ___________________________ 开始打开摄像头计算数据 ___________________________
    # 一个相机掉线，则单相机运行

    if left_camera_status:
        left_avg_result = get_depth("left",
                                    cfg.LEFT_CAMERA_ID,
                                    cfg.LEFT_CAMERA_CALIBRATION,
                                    cfg.LEFT_X1,
                                    cfg.LEFT_Y1,
                                    cfg.LEFT_X2,
                                    cfg.LEFT_Y2)

    if right_camera_status:
        right_avg_result = get_depth("right",
                                     cfg.RIGHT_CAMERA_ID,
                                     cfg.RIGHT_CAMERA_CALIBRATION,
                                     cfg.RIGHT_X1,
                                     cfg.RIGHT_Y1,
                                     cfg.RIGHT_X2,
                                     cfg.RIGHT_Y2)

    # ___________________________ 处理计算结果，全仓避障逻辑 ___________________________

    store_result = {}
    store_result["index"] = cfg.FULL_INDEX  # 报错仓储已满
    store_result["time_stamp"] = time_str

    # 两个相机都在线
    if left_camera_status and right_camera_status:
        for obs_avo in cfg.OBSTACLE_AVOIDANCE:
            if eval(obs_avo[0]) > eval(obs_avo[1]):
                store_result["store"] = obs_avo[2]
                store_result["index"] = obs_avo[3]
                store_result["depth"] = eval(obs_avo[0])

                _position = eval(obs_avo[4])
                store_result["position"] = _position[obs_avo[3]]
                break

    elif left_camera_status:
        for obs_avo in cfg.OBSTACLE_AVOIDANCE:
            if obs_avo[2] == "left":  # 只取一边的数据处理
                if eval(obs_avo[0]) > eval(obs_avo[1]):
                    store_result["store"] = obs_avo[2]
                    store_result["index"] = obs_avo[3]
                    store_result["depth"] = eval(obs_avo[0])

                    _position = eval(obs_avo[4])
                    store_result["position"] = _position[obs_avo[3]]
                    break

    elif right_camera_status:
        for obs_avo in cfg.OBSTACLE_AVOIDANCE:
            if obs_avo[2] == "right":  # 只取一边的数据处理
                if eval(obs_avo[0]) > eval(obs_avo[1]):
                    store_result["store"] = obs_avo[2]
                    store_result["index"] = obs_avo[3]
                    store_result["depth"] = eval(obs_avo[0])

                    _position = eval(obs_avo[4])
                    store_result["position"] = _position[obs_avo[3]]
                    break

    # ___________________________ 将找到的位置与实际位置对应，保存最终结果 ___________________________

    with open(cfg.STORE_POSITION_TXT, 'w', encoding="utf-8") as f:
        f.writelines(str(store_result))
        f.flush()
        f.close()


if __name__ == '__main__':
    output_log()  # 打开日志记录
    calculate_real_position()  # 调用仓储识别
    remove_oldest_file(cfg.LOG_PATH)
