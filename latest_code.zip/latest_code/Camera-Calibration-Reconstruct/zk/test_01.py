import os
import shutil

begin_str = "jmgj"

# file_left = "stereo_cam_left.yml"
# file_right = "stereo_cam_right.yml"
#
# os.remove(file_left)
# os.remove(file_right)
#
# shutil.copy2(f"./all_cfg/{begin_str}_stereo_cam_left.yml", file_left)
# shutil.copy2(f"./all_cfg/{begin_str}_stereo_cam_right.yml", file_right)

import codecs

file_path = 'test_03.py'
temp_file_path = 'temp_file.tmp'

with codecs.open(file_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

with codecs.open(temp_file_path, 'w', encoding='utf-8') as f:
    for line in lines:

        if line.startswith('SEPARATE_CFG_SELECT'):
            f.write("SEPARATE_CFG_SELECT = 'zkzkzkzkzkzzk'\n")
        else:
            f.write(line)

# Replace original file with temporary file
import shutil

shutil.move(temp_file_path, file_path)
