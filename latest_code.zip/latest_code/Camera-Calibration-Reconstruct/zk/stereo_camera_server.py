import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import cfg
from stereo_camera import output_log

app = FastAPI()
# 添加CORS中间件
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

output_log()  # 打开日志记录


# 定义路由
@app.route("/model/StorageDetection", methods=['POST', 'GET'])
async def get_frame(request: Request):
    # 解析接收json
    data_json = await request.json()

    # 将收到的消息记录在log中
    logging.info(f"StorageDetection接收到新请求：{data_json}")

    # 解析请求数据
    # weight = data_json['weight']
    # orderID = data_json['order_id']
    # goods_name = data_json['goods_name']
    # fault_tolerant = data_json['fault_tolerant']

    # 定义返回json框架
    resultdata = {"droppointx": None, "droppointy": None, "lift": None, "clear": False}

    try:
        # 读取已经保存的仓储信息
        with open(cfg.STORE_POSITION_TXT, 'r') as f:
            store_position = eval(f.readline())
            f.close()

        # 仓储已满
        if store_position["index"] == cfg.FULL_INDEX:
            resultdata['droppointx'] = None
            resultdata['droppointy'] = None
            resultdata['lift'] = None
            logging.info(f'仓储已满 store_position：{store_position["index"]}')

        else:
            resultdata['droppointx'] = store_position["position"][0]
            resultdata['droppointy'] = store_position["position"][1]
            direction = store_position["store"]

            if direction == "left":
                lift_nacelle = cfg.LEFT_LIFT_NACELLE
            elif direction == "right":
                lift_nacelle = cfg.RIGHT_LIFT_NACELLE

            # 需要抬升吊舱
            if store_position["depth"] < lift_nacelle:
                resultdata['lift'] = True

    except Exception as e:
        logging.info(f"读取仓储信息TXT报错，按仓储已满返回数据：{e}")

    results = {"code": 200, "msg": "OK", "Data": resultdata}
    logging.info(f"返回结果如下:{results}")
    return JSONResponse(content=results)


def app_run():
    """
    启动服务
    """
    print("\n仓储识别_接口启动成功\n")
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8026)


if __name__ == "__main__":
    app_run()
