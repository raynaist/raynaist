import cv2
from PyCameraList.camera_device import list_video_devices


def show_camera(matching_keys, keys_str):
    if len(matching_keys) > 0:
        for _key in matching_keys:
            capture = cv2.VideoCapture(_key)
            if not capture.isOpened():
                print("Error opening video file.")
                exit()

            while True:
                ret, frame = capture.read()
                if not ret:
                    break

                cv2.putText(frame, str(f"{keys_str}_{_key}"), (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2, cv2.LINE_AA)
                cv2.imshow('Demo', frame)
                if cv2.waitKey(1) & 0xFF == 27:  # ESC键退出
                    break

            capture.release()
            cv2.destroyAllWindows()


if __name__ == '__main__':

    # ______________________ 查看指定名称摄像头画面情况 ______________________

    # device_value_left = 'WN CAMERA1080 TB'  # TODO
    # device_value_right = '789'

    cameras = list_video_devices()
    # matching_keys_left = [key for key, value in dict(cameras).items() if value == device_value_left]
    # matching_keys_right = [key for key, value in dict(cameras).items() if value == device_value_right]
    #
    # print("device_value_left:", device_value_left, "       matching_keys_left:", matching_keys_left)
    # print("device_value_right:", device_value_right, "       matching_keys_right:", matching_keys_right)
    #
    # show_camera(matching_keys_left, f"left_{device_value_left}")
    # show_camera(matching_keys_right, f"right_{device_value_right}")

    # ______________________ 查看全部摄像头画面情况 ______________________

    matching_keys_all = [[[key], value] for key, value in dict(cameras).items()]
    print("matching_keys_all", matching_keys_all)

    for matching in matching_keys_all:
        show_camera(matching[0], f"all_{matching[1]}")
