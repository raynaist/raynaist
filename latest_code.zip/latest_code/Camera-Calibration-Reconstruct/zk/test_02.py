import pandas as pd

# 创建示例 DataFrame
data = {'Category': ['A', 'B', 'A', 'B', 'A', 'B'],
        'Value': [10, 20, 30, 40, 50, 60]}
df = pd.DataFrame(data)

# 按照 'Category' 列分组，并计算每个组的平均值
summary = df.groupby('Category').mean()

print(summary)
value_of_A = summary.loc['A', 'Value']
print(value_of_A)
